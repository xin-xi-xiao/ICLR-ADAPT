* mock-topology-preserving-rescue-v3; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt NOR GND VDD VIN1 VIN2 VOUT
M0 VOUT VIN1 GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M1 VOUT VIN2 GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M3 VOUT VIN1 NET14 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.26e-06 nfin=6
M2 NET14 VIN2 VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.26e-06 nfin=6
.ends NOR

.subckt NETLIST_COMPARATOR CLK GND Q QB VDD VINN VINP
M2 OUT OUTP NET021 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=3 w=2.1e-06 nfin=10
M4 OUTP OUT NET020 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=3 w=2.1e-06 nfin=10
M3 NET023 CLK VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=6.3e-07 nfin=3
XI1 GND VDD OUT Q QB NOR
XI0 GND VDD OUTP QB Q NOR
M0 NET020 VINP NET023 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
M1 NET021 VINN NET023 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
M12 NET021 CLK GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M11 NET020 CLK GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M10 NET020 CLK NET021 GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M9 OUT CLK GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M6 OUT OUTP GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M7 OUTP OUT GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M8 OUTP CLK GND GND sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
.ends NETLIST_COMPARATOR
