* mock-mos-intake-v1; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt DFCND4BWP_LVT_STUPID D CP Q QN VDD VSS
MX0 NET175 NET149 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX1 Q NET149 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX2 QN NET175 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX3 QN NET175 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MXMI43 NET12 NET145 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX4 NET95 NET11 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MXMI6 NET9 D NET1 VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX5 QN NET175 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX6 QN NET175 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX7 NET11 CP VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX8 Q NET149 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX9 NET149 CDN VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MXMI44 NET12 CDN VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MXMI17 NET175 NET95 NET24 VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX10 NET149 NET24 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX11 NET145 NET9 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX12 Q NET149 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MXMI16 NET145 NET11 NET24 VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX13 NET149 NET24 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX14 NET149 CDN VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MXMI45 NET9 NET11 NET12 VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX15 Q NET149 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MXMI7 NET1 NET95 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX16 QN NET175 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX17 Q NET149 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX18 QN NET175 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX19 NET169 CDN VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MXMI4 NET128 NET11 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX20 QN NET175 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MXMI18 NET175 NET11 NET24 VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX21 NET145 NET9 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX22 NET149 NET24 NET169 VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MXMI15 NET145 NET95 NET24 VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX23 NET175 NET149 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX24 Q NET149 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX25 NET95 NET11 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX26 NET149 NET24 NET132 VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MXMI5 NET9 D NET128 VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX27 NET11 CP VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MXMI49 NET112 CDN VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX28 NET132 CDN VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MXMI48 NET96 NET145 NET112 VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
MX29 Q NET149 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX30 QN NET175 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX31 Q NET149 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MXMI47 NET9 NET95 NET96 VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
.ends DFCND4BWP_LVT_STUPID

.subckt NR2D8BWP_LVT A1 A2 ZN VDD VSS
MX0 NET13 A2 VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=6.72e-06
MX1 ZN A1 NET13 VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=6.72e-06
MX2 ZN A2 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=5.04e-06
MX3 ZN A1 VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=5.04e-06
.ends NR2D8BWP_LVT

.subckt SR_LATCH_LVT Q QB R S VDD VSS
XI1 R QB Q VDD VSS NR2D8BWP_LVT
XI0 S Q QB VDD VSS NR2D8BWP_LVT
.ends SR_LATCH_LVT

.subckt INVD4BWP_LVT I ZN VDD VSS
MX0 ZN I VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX1 ZN I VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX2 ZN I VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX3 ZN I VSS VSS sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
MX4 ZN I VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX5 ZN I VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX6 ZN I VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
MX7 ZN I VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
.ends INVD4BWP_LVT

.subckt RRR1 NET046 SYS_CLKB VDD DO NET038 GND NET025 NET028 NET020 SYS_CLK
XI12 NET046 SYS_CLKB DO NET038 VDD GND DFCND4BWP_LVT_STUPID
XI6 NET046 NET025 NET028 NET020 VDD GND SR_LATCH_LVT
XI4 SYS_CLK SYS_CLKB VDD GND INVD4BWP_LVT
.ends RRR1
