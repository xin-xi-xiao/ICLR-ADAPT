* mock-mos-intake-v1; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt CASCODE_CURRENT_MIRROR_OTA ID VBIASN VBIASND VBIASP VINN VINP VOUTP VSS VDD
M25 VOUTP VBIASN NET034 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=2.52e-06 nfin=12
M24 VBIASND VBIASN NET033 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=2.52e-06 nfin=12
M17 NET16 VINN NET24 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=4 m=1 w=1.68e-06 nfin=8
M16 NET24 ID VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M15 NET27 VINP NET24 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=4 m=1 w=1.68e-06 nfin=8
M14 ID ID VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M11 NET033 VBIASND VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=4 m=1 w=1.68e-06 nfin=8
M10 NET034 VBIASND VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=4 m=1 w=1.68e-06 nfin=8
M1NUP VBIASN VBIASN NET9B VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=4.2e-07 nfin=2
M1NDOWN NET9B NET9B VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=6.3e-07 nfin=3
M1PUP NET8B NET8B VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=6.3e-07 nfin=3
M1PDOWN VBIASP VBIASP NET8B VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=6.3e-07 nfin=3
M27 NET27 VBIASP NET021 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=6 m=1 w=2.1e-06 nfin=10
M26 NET16 VBIASP NET015 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=6 m=1 w=2.1e-06 nfin=10
M23 VOUTP VBIASP NET024 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=10 m=1 w=2.52e-06 nfin=12
M22 VBIASND VBIASP NET06 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=10 m=1 w=2.52e-06 nfin=12
M21 NET015 NET16 VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=6.3e-07 nfin=3
M20 NET06 NET16 VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.05e-06 nfin=5
M19 NET021 NET27 VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=6.3e-07 nfin=3
M18 NET024 NET27 VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.05e-06 nfin=5
.ends CASCODE_CURRENT_MIRROR_OTA
