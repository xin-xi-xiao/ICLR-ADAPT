* Deterministic source input adaptation; original topology retained; synthetic sizing is not electrical equivalence.
.subckt SINGLE_ENDED_CURRENT_MIRROR VBIASN VINN VINP VOUTN GND! VDD!
MM8 NET9 NET9 GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM7 VOUTN NET9 GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM3 NET20 VINP NET16 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM0 NET11 VINN NET16 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM4 NET16 VBIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM6 NET9 NET11 VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM5 VOUTN NET20 VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM1 NET20 NET20 VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM2 NET11 NET11 VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends SINGLE_ENDED_CURRENT_MIRROR
.subckt LG_NPMOS BIASN VBIASN VBIASP GND! VDD!
MM4 VBIASP VBIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM2 VBIASN VBIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM10 NETA BIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM3 VBIASP VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM1 VBIASN NETA VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM0 NETA NETA VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends LG_NPMOS
.subckt CR4_2 VBIASN VBIASP GND! VDD!
MM11 NET023 NET024 VBIASN GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM8 NET025 NET010 NET023 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM9 NET024 NET024 NET023 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM7 NET010 NET010 NET025 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM2 VBIASN VBIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM0 VBIASP NET025 GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM10 NET024 VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM4 NET010 VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM3 VBIASN VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM1 VBIASP VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends CR4_2
.subckt SINGLE_ENDED_CURRENT_MIRROR_LG_NPMOS_CR4_2 VINN VINP VOUTN LG_VBIASP VBIASP GND! VDD!
XIOTA LG_VBIASN VINN VINP VOUTN GND! VDD! SINGLE_ENDED_CURRENT_MIRROR
XILG_NPMOS BIASN LG_VBIASN LG_VBIASP GND! VDD! LG_NPMOS
XIBCR4_2 BIASN VBIASP GND! VDD! CR4_2
.ends SINGLE_ENDED_CURRENT_MIRROR_LG_NPMOS_CR4_2
