* mock-mos-intake-v1; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt N_STACK_4 D G S B
MI1 D G INET1 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI2 INET1 G INET2 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI3 INET2 G INET3 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI4 INET3 G S B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends N_STACK_4

.subckt N_STACK_2 D G S B
MI1 D G INET1 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI2 INET1 G S B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends N_STACK_2

.subckt N_STACK_2__AE5F996EF D G S B
MI1 D G INET1 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI2 INET1 G S B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends N_STACK_2__AE5F996EF

.subckt N_STACK_4__A54B24D15 D G S B
MI1 D G INET1 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI2 INET1 G INET2 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI3 INET2 G INET3 B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI4 INET3 G S B sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends N_STACK_4__A54B24D15

.subckt P_STACK_4 D G S B
MI4 INET3 G S B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI3 INET2 G INET3 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI2 INET1 G INET2 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI1 D G INET1 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends P_STACK_4

.subckt P_STACK_2 D G S B
MI2 INET1 G S B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI1 D G INET1 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends P_STACK_2

.subckt P_STACK_4__A4BEF57F0 D G S B
MI4 INET3 G S B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI3 INET2 G INET3 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI2 INET1 G INET2 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI1 D G INET1 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends P_STACK_4__A4BEF57F0

.subckt P_STACK_2__A9132F5D0 D G S B
MI2 INET1 G S B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MI1 D G INET1 B sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends P_STACK_2__A9132F5D0

.subckt UNITY_GAIN_BUFFERS VBIAS_AN VCC VO_HS VO_LS VREF_HS VREF_LS VSS
XMN1 V_P1 V_P2 VSS VSS N_STACK_4
XMN0 V_P2 V_P2 VSS VSS N_STACK_4
XMN43 VO_LS V_P1 VSS VSS N_STACK_2
XMN22 V_N1 VO_HS VCOM_N VSS N_STACK_2__AE5F996EF
XMN23 V_N2 VREF_HS VCOM_N VSS N_STACK_2__AE5F996EF
XMN41 VBIAS4 VBIAS_AN VSS VSS N_STACK_4__A54B24D15
XMN3 VSS VBIAS_AN VSS VSS N_STACK_4__A54B24D15
XMN2 VCOM_N VBIAS_AN VSS VSS N_STACK_4
MMN42 VBIAS_M VBIAS_M VBIAS4 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=16 w=8.4e-07 nfin=4
MMP33 VBIAS_M VBIAS_M VBIAS_N1 VCC sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=16 w=8.4e-07 nfin=4
XMP10 VCOM_P VBIAS_N1 VCC VCC P_STACK_4
XMP8 V_P2 VO_LS VCOM_P VCC P_STACK_2
XMP22 V_N2 V_N1 VCC VCC P_STACK_4__A4BEF57F0
XMP28 V_N1 V_N1 VCC VCC P_STACK_4__A4BEF57F0
XMP7 VO_HS V_N2 VCC VCC P_STACK_2__A9132F5D0
XMP34 VBIAS_N1 VBIAS_N1 VCC VCC P_STACK_4
XMP9 V_P1 VREF_LS VCOM_P VCC P_STACK_2
.ends UNITY_GAIN_BUFFERS
