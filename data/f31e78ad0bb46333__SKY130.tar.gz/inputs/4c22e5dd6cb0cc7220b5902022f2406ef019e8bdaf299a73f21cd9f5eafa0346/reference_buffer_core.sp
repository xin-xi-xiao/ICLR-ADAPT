* mock-mos-intake-v1; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt REFERENCE_OTA GND VBIAS VDD VMIR VOUT VREF_IN
M2 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=8 m=1 w=8.190000000000001e-06
M0 VOUT NET8 VDD VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=2 m=1 w=2.1e-06
M5 NET8 NET8 VDD VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=2 m=1 w=2.1e-06
M9 NET012 NET012 NET012 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=4 m=1 w=4.2e-06
M8 NET7 NET7 NET7 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=8 m=1 w=8.190000000000001e-06
M7 NET7 VBIAS NET012 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=2 m=1 w=2.1e-06
M62 NET012 VDD GND GND sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
M1 NET8 VMIR NET7 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=4 m=1 w=4.2e-06
M4 VOUT VREF_IN NET7 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=4 m=1 w=4.2e-06
.ends REFERENCE_OTA

.subckt REFERENCE_BUFFER_CORE GND VBIAS VBIASP VBIASP2 VDD VFB_2 VFB_IN VREF VREF_IN
M97 NET017 NET017 NET017 GND sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=6.3e-07
M104 NET034 GND VBIASP GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=2 m=1 w=1.05e-06
M103 GND GND GND GND sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=4 m=1 w=1.89e-06
M102 NET036 NET036 NET036 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=4 m=1 w=4.2e-06
M100 NET017 NET017 NET017 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=2 m=1 w=2.1e-06
M62 NET034 VDD GND GND sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=4 m=1 w=1.26e-06
M98 NET034 NET034 NET034 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=2 m=1 w=2.1e-06
M19 NET017 VDD GND GND sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=2 m=1 w=4.2e-07
M17 NET036 VDD GND GND sky130_fd_pr__nfet_01v8 l=1.5e-07 nf=4 m=1 w=1.26e-06
M64 VFB_2 VBIAS NET036 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=4 m=1 w=4.2e-06
M66 VBIAS VBIAS NET034 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=4 m=1 w=4.2e-06
M7 VBIASP VBIAS NET017 GND sky130_fd_pr__nfet_01v8 l=3e-07 nf=2 m=1 w=1.05e-06
M115 NET022 VDD VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
M114 NET029 NET029 NET029 VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=4 m=1 w=1.008e-05
M113 VREF VREF VREF VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=4 m=1 w=1.218e-05
M117 VDD VDD NET061 VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=2 m=1 w=2.52e-06
M112 NET061 NET061 NET061 VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=6.09e-06
M108 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=4 m=1 w=7.56e-06
M110 NET022 VDD VDD VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=2 m=1 w=2.52e-06
M111 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=4 m=1 w=9.03e-06
M107 VDD VDD VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=4 m=1 w=3.15e-06
M18 NET022 GND VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=8.4e-07
M16 NET029 GND VDD VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=4 m=1 w=3.15e-06
M118 VDD VBIASP VDD VDD sky130_fd_pr__pfet_01v8 l=5.24e-06 nf=2 m=2 w=1.008e-05
M99 NET061 NET018 NET022 VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=2 m=1 w=2.52e-06
M77 VBIASP VBIASP NET061 VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=3.15e-06
M105 VDD NET061 VDD VDD sky130_fd_pr__pfet_01v8 l=5.24e-06 nf=2 m=2 w=1.008e-05
M9 VREF VBIASP2 NET029 VDD sky130_fd_pr__pfet_01v8 l=3e-07 nf=4 m=1 w=1.008e-05
M0 VFB_2 VBIASP VREF VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=4 m=1 w=1.218e-05
M116 VDD VDD VBIASP VDD sky130_fd_pr__pfet_01v8 l=1.5e-07 nf=2 m=1 w=3.15e-06
I12 GND VBIAS VDD VFB_IN NET018 VREF_IN REFERENCE_OTA
.ends REFERENCE_BUFFER_CORE
