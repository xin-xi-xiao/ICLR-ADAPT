* g1-independent-dc-bias-boundary-v3; PHYSICAL core has one extra bias pin; I0 retained in simulation wrapper.
* PDK geometry normalization is distinct from exact source-domain boundary equivalence.
.subckt SONG_DACFC_PIN_3__PHYSICAL GNDA VDDA VINN VINP VOUT NET013
MXM69 NET3 NET70 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM68 NET2 NET70 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM63 NET70 DM_1 NET2 VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM62 VOUTN DM_1 NET3 VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM61 NET4 DM_1 NET050 VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM60 VOUTN DM_1 NET5 VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM59 NET1 NET013 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=8 w=1.05e-06
MXM58 NET049 VINP NET1 NET1 sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM57 NET043 VINN NET1 NET1 sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM11 VOUT NET4 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM7 NET049 VOUTN VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM10 NET043 NET4 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM6 NET050 VOUTN VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM5 NET5 VOUTN VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM9 NET063 VINP NET31 NET31 sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM8 DM_2 VINN NET31 NET31 sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM4 NET31 NET013 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=8 w=1.05e-06
MXM3 VB3 NET013 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM2 DM_1 DM_1 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM1 VB4 NET013 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM0 NET013 NET013 VDDA VDDA sky130_fd_pr__pfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM71 VOUTN VB3 NET85 GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM70 NET70 VB3 NET69 GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM65 NET69 VB4 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=32 w=1.05e-06
MXM64 NET85 VB4 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=32 w=1.05e-06
MXM23 VOUT NET049 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM22 NET049 NET043 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM21 NET043 NET043 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM19 DM_2 VB4 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=32 w=1.05e-06
MXM15 VOUTN VB3 DM_2 GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM20 NET063 VB4 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=32 w=1.05e-06
MXM16 NET4 VB3 NET063 GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM17 NET54 VB4 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM14 VB3 VB3 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=4 w=1.05e-06
MXM12 VB4 VB3 NET54 GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM18 NET56 VB4 GNDA GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
MXM13 DM_1 VB3 NET56 GNDA sky130_fd_pr__nfet_01v8 l=1.044e-06 nf=2 m=16 w=1.05e-06
C2 NET4 GNDA 3.7333333333333337e-13
C0 VOUT NET70 8.0000000000000002e-13
.ends SONG_DACFC_PIN_3__PHYSICAL
