* g1-source-preserving-rescue-v2; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt INVERTER A Q VDD VSS
M0 Q A VDD VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M1 Q A VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends INVERTER

.subckt NAND A B Q VDD VSS
M1 Q B VDD VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M0 Q A VDD VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M3 NET10 B VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M2 Q A NET10 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends NAND

.subckt NOR A B Q VDD VSS
M1 Q A NET5 VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M0 NET5 B VDD VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M3 Q B VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M2 Q A VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends NOR

.subckt PFD A B QA QB VDD VSS
XI0 QA QB NET65 VDD VSS NAND
XI1 NET65 NET50 VDD VSS INVERTER
XI9 NET61 NET63 QB VDD VSS NOR
XI8 B QB NET61 VDD VSS NOR
XI7 NET63 NET50 NET62 VDD VSS NOR
XI6 NET61 NET62 NET63 VDD VSS NOR
XI5 NET48 NET50 NET55 VDD VSS NOR
XI4 NET47 NET55 NET48 VDD VSS NOR
XI3 NET47 NET48 QA VDD VSS NOR
XI2 A QA NET47 VDD VSS NOR
.ends PFD

.subckt DUT_440_FULL VDD VSS VB1 VB2 VCONT1 LOGICA1 LOGICB1
XI1 NET36 NET35 VDD VSS INVERTER
M5 NET31 VSS NET34 VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M1 VCONT1 NET35 NET38 VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M0 NET38 VB2 VDD VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M6 NET34 VDD NET31 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M3 NET37 VB1 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M2 VCONT1 NET31 NET37 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
C0 VCONT1 VSS 1e-13
XI0 LOGICA1 LOGICB1 NET36 NET34 VDD VSS PFD
.ends DUT_440_FULL
