* mock-mos-intake-v1; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt NOR VDD A B OUT VSS
MXM1 OUT A VSS VSS n l=1.5e-07 nf=2 m=1 w=4.5e-07
MXM2 OUT B VSS VSS n l=1.5e-07 nf=2 m=1 w=4.5e-07
MXM4 OUT B NET1 VDD p l=1.5e-07 nf=2 m=1 w=9e-07
MXM3 NET1 A VDD VDD p l=1.5e-07 nf=2 m=1 w=9e-07
MXM5 NET2 B VDD VDD p l=1.5e-07 nf=2 m=1 w=9e-07
MXM6 OUT A NET2 VDD p l=1.5e-07 nf=2 m=1 w=9e-07
.ends NOR

.subckt DFF D CLK Q RESET VSS
X1 D CLK Q P VSS NOR
X2 D P P1 Q VSS NOR
X3 D P P2 P1 VSS NOR
X4 D P1 RESET P2 VSS NOR
.ends DFF

.subckt AND_PFD VDD OUT A B VSS
MXM1 OUT_NAND A NET1 VSS n l=1.5e-07 nf=2 m=1 w=4.5e-07
MXM2 OUT_NAND A VDD VDD p l=1.5e-07 nf=2 m=1 w=9e-07
MXM3 NET1 B VSS VSS n l=1.5e-07 nf=2 m=1 w=4.5e-07
MXM4 OUT_NAND B NET2 VSS n l=1.5e-07 nf=2 m=1 w=4.5e-07
MXM5 NET2 A VSS VSS n l=1.5e-07 nf=2 m=1 w=4.5e-07
MXM6 OUT_NAND B VDD VDD p l=1.5e-07 nf=2 m=1 w=9e-07
MXM7 OUT OUT_NAND VDD VDD p l=1.5e-07 nf=2 m=1 w=9e-07
MXM8 OUT OUT_NAND VSS VSS n l=1.5e-07 nf=2 m=1 w=4.5e-07
.ends AND_PFD

.subckt PFD VDD VSS A B DOWN UP RESET
X1 VDD A UP RESET VSS DFF
X2 VDD B DOWN RESET VSS DFF
X3 VDD RESET UP DOWN VSS AND_PFD
.ends PFD
