* mock-mos-intake-v1; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt NOR VDD A B OUT VSS
MXM1 OUT A VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MXM2 OUT B VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MXM4 OUT B NET1 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.89e-06 nfin=9
MXM3 NET1 A VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.89e-06 nfin=9
MXM5 NET2 B VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.89e-06 nfin=9
MXM6 OUT A NET2 VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.89e-06 nfin=9
.ends NOR

.subckt DFF D CLK Q RESET VSS
X1 D CLK Q P VSS NOR
X2 D P P1 Q VSS NOR
X3 D P P2 P1 VSS NOR
X4 D P1 RESET P2 VSS NOR
.ends DFF

.subckt AND_PFD VDD OUT A B VSS
MXM1 OUT_NAND A NET1 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MXM2 OUT_NAND A VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.89e-06 nfin=9
MXM3 NET1 B VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MXM4 OUT_NAND B NET2 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MXM5 NET2 A VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
MXM6 OUT_NAND B VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.89e-06 nfin=9
MXM7 OUT OUT_NAND VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.89e-06 nfin=9
MXM8 OUT OUT_NAND VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
.ends AND_PFD

.subckt PFD VDD VSS A B DOWN UP RESET
X1 VDD A UP RESET VSS DFF
X2 VDD B DOWN RESET VSS DFF
X3 VDD RESET UP DOWN VSS AND_PFD
.ends PFD
