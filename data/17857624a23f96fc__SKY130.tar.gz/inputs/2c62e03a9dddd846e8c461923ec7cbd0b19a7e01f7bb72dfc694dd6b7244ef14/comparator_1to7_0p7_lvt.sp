* mock-mos-intake-v1; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt COMPARATOR_1TO7_0P7_LVT CLKE D DB INM INP VDD VSS
M29 VOUT1P CLK VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=2 w=1.68e-06 nfin=8
M32 VOUT1M CLK VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=2 w=1.68e-06 nfin=8
M18 CLK NET043 VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=4 m=3 w=2.31e-06 nfin=11
M19 NET043 CLKE VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M7 DB VOUT2P VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.26e-06 nfin=6
M28 VOUT2P VOUT2M VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=8 m=11 w=2.52e-06 nfin=12
M38 VDD VSS VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M39 VDD VSS VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=4 m=3 w=2.31e-06 nfin=11
M34 VOUT2M VOUT2P VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=8 m=11 w=2.52e-06 nfin=12
M25 VOUT2P CLK VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M8 D VOUT2M VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.26e-06 nfin=6
M33 VOUT2M CLK VDD VDD sky130_fd_pr__pfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M35 NET058 CLK VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=2.1e-06 nfin=10
M10 VOUT1M INP NET058 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=2.52e-06 nfin=12
M9 D VOUT2M VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
M48 VSS VDD VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=2 w=2.52e-06 nfin=12
M41 VSS VDD VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
M43 VSS VDD VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=6 m=5 w=2.52e-06 nfin=12
M42 VSS VDD VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M11 VOUT1P INM NET058 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=2.52e-06 nfin=12
M26 CLK NET043 VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=1.68e-06 nfin=8
M14 VOUT2P VOUT2M VOUT1P VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=8 m=6 w=2.31e-06 nfin=11
M12 VOUT1P INM NET057 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=7 w=2.52e-06 nfin=12
M40 NET057 CLK VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=7 w=2.1e-06 nfin=10
M6 DB VOUT2P VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
M27 NET043 CLKE VSS VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=1 w=8.4e-07 nfin=4
M13 VOUT1M INP NET057 VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=2 m=7 w=2.52e-06 nfin=12
M21 VOUT2M VOUT2P VOUT1M VSS sky130_fd_pr__nfet_01v8 l=150e-9 nf=8 m=6 w=2.31e-06 nfin=11
.ends COMPARATOR_1TO7_0P7_LVT
