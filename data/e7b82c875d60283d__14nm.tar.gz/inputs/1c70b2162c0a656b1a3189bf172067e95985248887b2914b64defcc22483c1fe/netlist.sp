* g1-source-preserving-rescue-v2; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt NAND GND VDD VIN1 VIN2 VOUT
M2 VOUT VIN1 NET16 GND n l=6e-08 nf=2 m=1 nfin=2
M3 NET16 VIN2 GND GND n l=6e-08 nf=2 m=1 nfin=2
M0 VOUT VIN1 VDD VDD p l=6e-08 nf=2 m=1 nfin=2
M1 VOUT VIN2 VDD VDD p l=6e-08 nf=2 m=1 nfin=2
.ends NAND

.subckt INV1X GND VDD VIN VOUT
M0 VOUT VIN GND GND n l=6e-08 nf=2 m=1 nfin=2
M1 VOUT VIN VDD VDD p l=6e-08 nf=2 m=1 nfin=2
.ends INV1X

.subckt NOR GND VDD VIN1 VIN2 VOUT
M0 VOUT VIN1 GND GND n l=6e-08 nf=2 m=1 nfin=2
M1 VOUT VIN2 GND GND n l=6e-08 nf=2 m=1 nfin=2
M3 VOUT VIN1 NET14 VDD p l=6e-08 nf=2 m=1 nfin=6
M2 NET14 VIN2 VDD VDD p l=6e-08 nf=2 m=1 nfin=6
.ends NOR

.subckt NETLIST GND PD PU VCTL VDD
M17 NET027 VSTEPD NET044 GND n l=6e-08 nf=2 m=1 nfin=2
M16 NET044 PDB GND GND n l=6e-08 nf=2 m=1 nfin=2
M13 NET036 NET036 GND GND n l=2e-07 nf=2 m=1 nfin=2
M14 VSTEPD PD NET036 GND n l=6e-08 nf=2 m=1 nfin=2
M12 NET026 NET036 GND GND n l=2e-07 nf=2 m=1 nfin=2
M8 NET22 PU GND GND n l=6e-08 nf=2 m=1 nfin=2
M7 NET058 VSTEPU NET22 GND n l=6e-08 nf=2 m=1 nfin=2
M0 VSTEPU PUB GND GND n l=6e-08 nf=2 m=1 nfin=2
M19 NET043 PDB VDD VDD p l=6e-08 nf=2 m=1 nfin=2
M18 NET027 VSTEPD NET043 VDD p l=6e-08 nf=2 m=1 nfin=2
M15 VSTEPD PD VDD VDD p l=6e-08 nf=2 m=1 nfin=2
M6 NET058 VSTEPU NET21 VDD p l=6e-08 nf=2 m=1 nfin=2
M5 NET21 PU VDD VDD p l=6e-08 nf=2 m=1 nfin=2
M3 NET27 NET8 VDD VDD p l=2e-07 nf=2 m=1 nfin=4
M2 NET8 NET8 VDD VDD p l=2e-07 nf=2 m=1 nfin=4
M1 VSTEPU PUB NET8 VDD p l=6e-08 nf=2 m=1 nfin=2
C3 VDD VSTEPD 1.25e-14
C1 GND VSTEPU 1.25e-14
C4 GND NET058 1.25e-14
C5 VDD NET027 1.25e-14
C0 GND VCTL 8e-13
XI0 GND VDD NET058 PU VPULSEU NAND
XI11 GND VDD PD PDB INV1X
XI1 GND VDD PU PUB INV1X
M4 VCTL VPULSEU NET27 VDD p l=6e-08 nf=2 m=1 nfin=4
M9 VCTL VPULSED NET026 GND n l=6e-08 nf=2 m=1 nfin=2
XI10 GND VDD NET027 PDB VPULSED NOR
.ends NETLIST
