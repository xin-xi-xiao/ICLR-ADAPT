* g1-source-preserving-rescue-v2; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt NOR GND VDD VIN1 VIN2 VOUT
M0 VOUT VIN1 GND GND n l=6e-08 nf=2 m=1 nfin=2
M1 VOUT VIN2 GND GND n l=6e-08 nf=2 m=1 nfin=2
M3 VOUT VIN1 NET14 VDD p l=6e-08 nf=2 m=1 nfin=6
M2 NET14 VIN2 VDD VDD p l=6e-08 nf=2 m=1 nfin=6
.ends NOR

.subckt NETLIST_COMPARATOR CLK GND Q QB VDD VINN VINP
M2 OUT OUTP NET021 VDD p l=6e-08 nf=2 m=3 nfin=10
M4 OUTP OUT NET020 VDD p l=6e-08 nf=2 m=3 nfin=10
M3 NET023 CLK VDD VDD p l=6e-08 nf=2 m=1 nfin=3
XI1 GND VDD OUT Q QB NOR
XI0 GND VDD OUTP QB Q NOR
M0 NET020 VINP NET023 VDD p l=2e-05 nf=2 m=1 nfin=4
M1 NET021 VINN NET023 VDD p l=2e-05 nf=2 m=1 nfin=4
M12 NET021 CLK GND GND n l=6e-08 nf=2 m=1 nfin=2
M11 NET020 CLK GND GND n l=6e-08 nf=2 m=1 nfin=2
M10 NET020 CLK NET021 GND n l=6e-08 nf=2 m=1 nfin=2
M9 OUT CLK GND GND n l=6e-08 nf=2 m=1 nfin=2
M6 OUT OUTP GND GND n l=6e-08 nf=2 m=1 nfin=2
M7 OUTP OUT GND GND n l=6e-08 nf=2 m=1 nfin=2
M8 OUTP CLK GND GND n l=6e-08 nf=2 m=1 nfin=2
.ends NETLIST_COMPARATOR
