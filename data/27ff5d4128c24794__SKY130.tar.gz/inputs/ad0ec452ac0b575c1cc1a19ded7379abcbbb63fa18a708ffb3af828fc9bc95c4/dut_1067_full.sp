* g1-source-preserving-rescue-v2; topology/hierarchy preserved; geometry normalization is not electrical equivalence.
.subckt INVERTER A Q VDD VSS
M0 Q A VDD VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M1 Q A VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends INVERTER

.subckt DUT_1067_FULL VDD VSS VOUT1 VCLK1 VCLK2 VCLK3 VCLK4 VCLK5 VCLK6 VCLK7 VCLK8
M31 NET61 VCLK7 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M30 NET31 VCLK8 NET58 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M29 NET58 VCLK7 NET27 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M28 NET31 NET57 NET59 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M27 NET59 NET55 NET27 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M26 NET31 VCLK8 NET60 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M25 NET60 NET55 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M24 NET31 NET57 NET61 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M23 NET65 VCLK5 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M22 NET27 VCLK6 NET62 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M21 NET62 VCLK5 NET22 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M20 NET27 NET51 NET63 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M19 NET63 NET49 NET22 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M18 NET27 VCLK6 NET64 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M17 NET64 NET49 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M16 NET27 NET51 NET65 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M15 NET69 VCLK3 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M14 NET22 VCLK4 NET66 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M13 NET66 VCLK3 NET17 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M12 NET22 NET45 NET67 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M11 NET67 NET43 NET17 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M10 NET22 VCLK4 NET68 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M9 NET68 NET43 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M8 NET22 NET45 NET69 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M7 NET17 VCLK2 NET70 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M6 NET70 VCLK1 VDD VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M5 NET17 NET39 NET71 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M4 NET71 NET37 VDD VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M3 NET17 VCLK2 NET72 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M2 NET72 NET37 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M1 NET17 NET39 NET73 VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
M0 NET73 VCLK1 VSS VSS sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
XI9 NET33 VOUT1 VDD VSS INVERTER
XI8 NET31 NET33 VDD VSS INVERTER
XI7 VCLK8 NET57 VDD VSS INVERTER
XI6 VCLK7 NET55 VDD VSS INVERTER
XI5 VCLK6 NET51 VDD VSS INVERTER
XI4 VCLK5 NET49 VDD VSS INVERTER
XI3 VCLK4 NET45 VDD VSS INVERTER
XI2 VCLK3 NET43 VDD VSS INVERTER
XI1 VCLK2 NET39 VDD VSS INVERTER
XI0 VCLK1 NET37 VDD VSS INVERTER
M32 NET31 NET33 VDD VDD sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends DUT_1067_FULL
