* Explicit file-level interface and source-proven global rails; geometry initialization is not electrical equivalence.
.subckt SINGLE_ENDED_LOW_VOLTAGE_CASCODE_PMOS VBIASP VINN VINP VOUTP VDD! GND!
MM7 VOUTP VINN NET11 NET18 sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM6 NET13 VINP NET11 NET18 sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM5 NET11 VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM1 VOUTP NET17 NET20 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM0 NET13 NET17 NET19 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM9 NET20 NET13 GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM8 NET19 NET13 GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends SINGLE_ENDED_LOW_VOLTAGE_CASCODE_PMOS

.subckt LG_NPMOS BIASN VBIASN VBIASP VDD! GND!
MM4 VBIASP VBIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM2 VBIASN VBIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM10 NETA BIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM3 VBIASP VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM1 VBIASN NETA VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM0 NETA NETA VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends LG_NPMOS

.subckt CR4_2 VBIASN VBIASP VDD! GND!
MM11 NET023 NET024 VBIASN GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM8 NET025 NET010 NET023 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM9 NET024 NET024 NET023 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM7 NET010 NET010 NET025 GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM2 VBIASN VBIASN GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM0 VBIASP NET025 GND! GND! sky130_fd_pr__nfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM10 NET024 VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM4 NET010 VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM3 VBIASN VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
MM1 VBIASP VBIASP VDD! VDD! sky130_fd_pr__pfet_01v8 l=1.8e-07 nf=2 m=1 w=1.05e-06
.ends CR4_2

.subckt SINGLE_ENDED_LOW_VOLTAGE_CASCODE_PMOS_LG_NPMOS_CR4_2 VINN VINP VOUTP LG_VBIASN VBIASP VDD! GND!
XIOTA LG_VBIASP VINN VINP VOUTP VDD! GND! SINGLE_ENDED_LOW_VOLTAGE_CASCODE_PMOS
XILG_NPMOS BIASN LG_VBIASN LG_VBIASP VDD! GND! LG_NPMOS
XIBCR4_2 BIASN VBIASP VDD! GND! CR4_2
.ends SINGLE_ENDED_LOW_VOLTAGE_CASCODE_PMOS_LG_NPMOS_CR4_2
.end
