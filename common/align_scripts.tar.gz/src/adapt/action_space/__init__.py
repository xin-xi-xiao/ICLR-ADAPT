"""Fixed-dimensional, physics-anchored action interface for ADAPT."""

from .decoder import (
    ActionMasks,
    DecodedAction,
    DecoderContext,
    X12ScreenV2Decoder,
)
from .roles import (
    PLACEMENT_SCREEN_ROLES,
    ROLE_ORDER,
    NetEntity,
    PhysicsAnchoredRoleAssigner,
    RoleAssignment,
    RoleAssignmentKey,
)
from .role_evidence import (
    CompiledTopNetUniverse,
    CompatibilityRunProvenance,
    ResolvedPhysicalRoleTargets,
    ResolvedRoleTarget,
    RoleEvidenceContractError,
    RoleEvidenceRegistry,
    extract_compiled_top_net_universe,
    load_role_evidence_registry,
    resolve_preregistered_role_targets,
)
from .schema import (
    GLOBAL_SLOT_COUNT,
    ROLE_SLOT_TO_ROLE,
    X12_SCREEN_V2_SLOT_NAMES,
    RequestedAction,
    load_x12_screen_v2_schema,
)

__all__ = [
    "ActionMasks",
    "CompiledTopNetUniverse",
    "CompatibilityRunProvenance",
    "DecodedAction",
    "DecoderContext",
    "GLOBAL_SLOT_COUNT",
    "NetEntity",
    "PLACEMENT_SCREEN_ROLES",
    "PhysicsAnchoredRoleAssigner",
    "ROLE_ORDER",
    "ROLE_SLOT_TO_ROLE",
    "RequestedAction",
    "ResolvedPhysicalRoleTargets",
    "ResolvedRoleTarget",
    "RoleAssignment",
    "RoleAssignmentKey",
    "RoleEvidenceContractError",
    "RoleEvidenceRegistry",
    "X12_SCREEN_V2_SLOT_NAMES",
    "X12ScreenV2Decoder",
    "extract_compiled_top_net_universe",
    "load_role_evidence_registry",
    "load_x12_screen_v2_schema",
    "resolve_preregistered_role_targets",
]
