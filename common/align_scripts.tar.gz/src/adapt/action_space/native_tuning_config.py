"""Versioned contract for ALIGN B/S native tuning constants.

The config is intentionally a *wiring contract*, not a claim that the current
ALIGN binary consumes these overrides.  Until a source patch is built and
traced, every B/S slot is ``blocked_consumer`` and its native default is kept
separate from the shared32 normalized reference value.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from adapt.contracts.common import ContractError

from .shared32_plan import load_shared32_plan


NATIVE_TUNING_CONFIG_VERSION = "native-tuning-config-v1"
BS_SLOTS = ("G05", "R04", "R05", "R06", "R07", "R08", "R09", "W07", "W08", "W09", "W10")
ROUTER_ENV_KEYS = {
    "R04": "ADAPT_R6_NATIVE_R04_GRID_TARGET",
    "R06": "ADAPT_R6_NATIVE_R06_EDGE_PENALTY",
    "R07": "ADAPT_R6_NATIVE_R07_PLATE_SCALE",
}
ROUTER_SIGNAL_METALS_ENV = "ADAPT_R6_NATIVE_SIGNAL_METALS"

# Native defaults are source-level values; normalized references are the
# frozen shared32 action values.  Keeping both prevents a normalized action
# from being mistaken for a source constant.
NATIVE_DEFAULTS: Mapping[str, Any] = {
    "G05": 1,
    "R04": "derived_by_chip_and_profile",
    "R05": 5,
    "R06": 2,
    "R07": 1.5,
    "R08": 1,
    "R09": 0.2,
    "W07": 1,
    "W08": 100,
    "W09": 7,
    "W10": 10,
}

SOURCE_LOCATIONS: Mapping[str, str] = {
    "G05": "pdks/{FinFET14nm,Bulk65nm,Bulk45nm}_Mock_PDK/mos.py:MOSGenerator._addMOSArray.minvias",
    "R04": "PlaceRouteHierFlow/router/GcellGlobalRouter.cpp:472-514",
    "R05": "PlaceRouteHierFlow/router/GcellGlobalRouter.cpp:532",
    "R06": "PlaceRouteHierFlow/router/GlobalGraph.cpp:54",
    "R07": "PlaceRouteHierFlow/router/GlobalGrid.cpp:412",
    "R08": "PlaceRouteHierFlow/router/Router.cpp:53",
    "R09": "PlaceRouteHierFlow/router/A_star.cpp:1347",
    "W07": "PlaceRouteHierFlow/router/PowerRouter.cpp:1241",
    "W08": "PlaceRouteHierFlow/router/A_star.cpp:1435",
    "W09": "PlaceRouteHierFlow/router/PowerRouter.cpp:913",
    "W10": "PlaceRouteHierFlow/router/PowerRouter.cpp:869",
}


@dataclass(frozen=True)
class NativeTuningSlot:
    slot_id: str
    native_default: Any
    profile_reference: Any
    source_location: str
    status: str = "blocked_consumer"
    patch_id: str = "r6-native-tuning-config-v1-pending-source-patch"

    def to_dict(self) -> dict[str, Any]:
        return {
            "slot_id": self.slot_id,
            "native_default": self.native_default,
            "profile_reference": self.profile_reference,
            "source_location": self.source_location,
            "status": self.status,
            "patch_id": self.patch_id,
        }


@dataclass(frozen=True)
class NativeTuningConfig:
    version: str
    slots: tuple[NativeTuningSlot, ...]
    requested: Mapping[str, Any]

    @classmethod
    def create(cls, requested: Mapping[str, Any] | None = None) -> "NativeTuningConfig":
        plan = load_shared32_plan()
        requested = dict(requested or {})
        unknown = sorted(set(requested) - set(BS_SLOTS))
        if unknown:
            raise ContractError(f"NativeTuningConfig only covers B/S slots: {unknown}")
        slots: list[NativeTuningSlot] = []
        for slot_id in BS_SLOTS:
            profile_reference = plan.slot(slot_id).reference
            value = requested.get(slot_id, profile_reference)
            # Validate normalized action values even though they are blocked
            # from the current native binary.
            plan.slot(slot_id).validate_value(value)
            slots.append(NativeTuningSlot(
                slot_id=slot_id,
                native_default=NATIVE_DEFAULTS[slot_id],
                profile_reference=profile_reference,
                source_location=SOURCE_LOCATIONS[slot_id],
            ))
        return cls(NATIVE_TUNING_CONFIG_VERSION, tuple(slots), requested)

    def to_trace(self) -> dict[str, Any]:
        return {
            "schema": self.version,
            "status": "blocked_consumer_until_versioned_source_patch",
            "slots": [
                {
                    **slot.to_dict(),
                    "requested": self.requested.get(slot.slot_id, slot.profile_reference),
                    "effective": None,
                    "consumer_hit_count": 0,
                    "applicability": "not_claimed",
                }
                for slot in self.slots
            ],
        }

    def router_environment(self, active_slots: Sequence[str], *,
                           frozen_signal_metal_indices: Sequence[int] | None = None) -> dict[str, str]:
        """Encode explicit R04/R06/R07 activation; this is not consumer proof.

        R04's 8/16/32 action is a target grid count. The accompanying frozen
        resources are actual zero-based native metal indices, never R01/R02
        action quantiles. This method neither guesses nor expands that table.
        """
        active = tuple(active_slots)
        if len(set(active)) != len(active) or set(active) - set(ROUTER_ENV_KEYS):
            raise ContractError("router_environment covers explicit unique R04/R06/R07 slots only")
        plan = load_shared32_plan()
        env = {}
        for slot in active:
            value = plan.slot(slot).validate_value(self.requested.get(slot, plan.slot(slot).reference))
            env[ROUTER_ENV_KEYS[slot]] = repr(float(value)) if slot == "R07" else str(int(value))
        if "R04" in active:
            indices = list(frozen_signal_metal_indices) if frozen_signal_metal_indices is not None else []
            if (len(indices) < 2 or any(not isinstance(index, int) or isinstance(index, bool) or index < 0 for index in indices)
                    or indices != sorted(set(indices))):
                raise ContractError("R04 requires a frozen ascending table of at least two actual native metal indices; action quantiles are not metal indices")
            env[ROUTER_SIGNAL_METALS_ENV] = ",".join(map(str, indices))
        return env

    def default_regression_fixture(self) -> dict[str, Any]:
        """Describe the pre-patch regression expectation without faking a hit."""

        return {
            "schema": "native-tuning-default-regression-v1",
            "config_version": self.version,
            "expected_native_defaults": dict(NATIVE_DEFAULTS),
            "requested_reference_values": {
                slot.slot_id: slot.profile_reference for slot in self.slots
            },
            "consumer_status": "blocked_consumer",
            "regression_rule": "source patch must preserve native defaults when no override is supplied",
        }
