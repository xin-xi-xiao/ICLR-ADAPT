"""Ordinary-PDN scope, frozen W03--W06 resources and consumer readback.

Uses the existing four conditional q coordinates, never a new tuple selector.
The declared power resource stack is frozen independently of actions. Static
legality does not establish stripe capacity, electrical connectivity or IR/EM.
"""
from __future__ import annotations

import copy
import hashlib
from itertools import product
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from adapt.contracts.common import ContractError
from .shared32_layer_decoder import (
    build_power_layer_windows, decode_layer_window, validate_actual_pin_layers,
    validate_reference_layer_window,
)

SCHEMA = "shared32-frozen-power-layer-campaign-v1"
SLOTS = ("W03", "W04", "W05", "W06")
FIELDS = ("bottom_power_grid_layer", "top_power_grid_layer", "bottom_power_routing_layer", "top_power_routing_layer")
Q = (0, .5, 1)
REFERENCE_Q = (0, 1, 0, 1)
ANCHORS = {"reference": REFERENCE_Q, "interior": (.5, .5, .5, .5),
           "low_grid": (0, 0, 0, 1)}
SOURCES = ["ALIGN-public/PlaceRouteHierFlow/PnRDB/ReadDesignRuleJson.cpp:446-467",
    "ALIGN-public/align/pnr/router.py:100-144",
    "ALIGN-public/PlaceRouteHierFlow/router/PowerRouter.cpp:683-706,973-979,1495-1498",
    "ALIGN-public/PlaceRouteHierFlow/PnRDB/PnRdatabase.cpp:1439-1481",
    "ALIGN-public/align/pnr/checkers.py:32,86-155"]


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _artifact(path: Path) -> dict[str, str]:
    return {"path": str(path.resolve()), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def _resource_identity(pdk: Mapping[str, Any]) -> dict[str, Any]:
    value = copy.deepcopy(pdk)
    for field in (*FIELDS, "h_skip_factor", "v_skip_factor"):
        value["design_info"].pop(field, None)
    return value


def collect_power_scope(baseline_run_dir: str | Path, *, top: str,
                        native_pin_evidence: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Read exact selected top power pins and ordinary power-stage evidence.

    Viewer pin tags retain real imported selected primitive/child contacts;
    router grid/hookup additions are drawing records. This source-based contact
    inventory is distinct from a direct native PowerNets.Pins memory receipt.
    Guard-ring/multiple-domain/custom-PDN cases need dedicated evidence.
    """
    run = Path(baseline_run_dir).resolve()
    manifest_path = run / "run_manifest.json"
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text())
    else:
        # The runner reads actual power pins before writing its final manifest.
        # Use the completed physical invocation, then require the same exact
        # accepted selected candidate below; absence is never treated as pass.
        manifest_path = run / "phase_manifest.json"
        phases = json.loads(manifest_path.read_text())
        physical = [row for row in phases if row.get("phase") == "physical"]
        if len(physical) != 1:
            raise ContractError("one completed physical invocation required")
        manifest = {**physical[0], "collector_status": "pending_selection"}
    work = Path(manifest.get("align_workdir", run / "align_workdir"))
    if manifest.get("returncode") != 0 or manifest.get("collector_status") not in {"ok", "pending_selection"}:
        raise ContractError("completed explicit-PDN baseline required")
    command = manifest.get("command", [])
    if "--PDN_mode" in command or "-pdn" in command:
        raise ContractError("PDN simulation mode overrides grid bounds; ordinary power flow required")
    pdk_argument = next((command[i + 1] for i, argument in enumerate(command[:-1]) if argument in {"-p", "--pdk_dir"}), None)
    topology_path = work / "1_topology" / f"{top}.verilog.json"
    topology = json.loads(topology_path.read_text())
    modules = {m["name"]: m for m in topology["modules"]}
    if top not in modules:
        raise ContractError("exact compiled top missing")
    if any(c["constraint"] == "GuardRing" for m in modules.values() for c in m["constraints"]):
        raise ContractError("guard-ring power pins require additional direct native evidence")
    globals_by_role = {role: [r["actual"] for r in topology.get("global_signals", []) if r.get("formal") == formal]
        for role, formal in (("power", "supply1"), ("ground", "supply0"))}
    if any(len(values) != 1 for values in globals_by_role.values()) or globals_by_role["power"] == globals_by_role["ground"]:
        raise ContractError("actual compiled global supply1/supply0 pair required")
    rails = globals_by_role["power"] + globals_by_role["ground"]
    forbidden = {net for c in modules[top]["constraints"] if c["constraint"] == "DoNotRoute" for net in c["nets"]}
    if forbidden & set(rails):
        raise ContractError("explicit supply is DoNotRoute")
    selection_path = run / "selected_candidate_collection.json"
    selection = json.loads(selection_path.read_text())
    chosen = [c for c in selection["candidates"] if c["candidate_id"] == selection.get("selected_id")]
    if selection.get("top_name") != top or len(chosen) != 1 or chosen[0].get("postroute_label_eligible") is not True:
        raise ContractError("exact accepted selected candidate required")
    routed = Path(chosen[0]["routed_json"])
    if not routed.is_absolute():
        routed = work / routed
    geometry = json.loads(routed.read_text())
    pdk_path = work / "3_pnr/inputs/layers.json"
    pdk = json.loads(pdk_path.read_text())
    metals = {r["Layer"] for r in pdk["Abstraction"] if r["Layer"].startswith("M")}
    contacts = {rail: {} for rail in rails}
    for term in geometry["terminals"]:
        if term.get("netName") not in contacts or term.get("netType") != "pin" or term.get("layer") not in metals:
            continue
        rect = term.get("rect")
        if not isinstance(rect, list) or len(rect) != 4 or rect[2] <= rect[0] or rect[3] <= rect[1]:
            raise ContractError("power pin contains invalid or empty physical geometry")
        contacts[term["netName"]][(term["layer"], *rect)] = {"layer": term["layer"], "rect": rect}
    if any(not records for records in contacts.values()):
        raise ContractError("one or more declared supplies lack selected real metal pin contacts")
    logs = [path for path in (run / "stdout.log", run / "physical.stdout.log") if path.is_file()]
    log_text = "\n".join(path.read_text(errors="replace") for path in logs)
    if f"Create power grid: {top}" not in log_text or f"Power routing {top}" not in log_text:
        raise ContractError("ordinary top-level grid/hookup calls not observed")
    artifacts = [_artifact(path) for path in (manifest_path, topology_path, selection_path, routed, pdk_path, *logs)]
    evidence_kind = "selected_imported_real_power_pin_contacts_source_grounded_conservative"
    pin_access = {"module_name": top, "complete": True,
        "pin_layers": sorted({row["layer"] for records in contacts.values() for row in records.values()}),
        "provenance": {"evidence_kind": evidence_kind, "artifacts": artifacts},
        "contacts_by_supply": {rail: list(records.values()) for rail, records in contacts.items()},
        "native_PowerNets_Pins_memory_readback": "unobserved"}
    if native_pin_evidence is not None:
        if (native_pin_evidence.get("complete") is not True or native_pin_evidence.get("module_name") != top
                or not native_pin_evidence.get("provenance") or not native_pin_evidence.get("pin_layers")):
            raise ContractError("direct native power pin evidence incomplete")
        pin_access = copy.deepcopy(native_pin_evidence)
    return {"top": top, "baseline_run_dir": str(run), "workdir": str(work), "selected_candidate_id": selection["selected_id"],
        "original_pdk_directory": str(Path(pdk_argument).resolve()) if pdk_argument else None,
        "pdk_payload": pdk, "topology": topology, "artifacts": artifacts, "pin_access": pin_access,
        "power_evidence": {"complete": True, "power_profile": "explicit_pdn", "ordinary_power_flow": True,
            "power_ports": globals_by_role["power"], "ground_ports": globals_by_role["ground"],
            "provenance": {"compiled_global_signals": topology["global_signals"], "artifacts": artifacts}},
        "bbox": geometry["bbox"], "electrical_signoff": "not_inferred_from_stage_completion"}


def declare_power_resources(pdk: Mapping[str, Any], *, grid_allowed_layers: Sequence[str] | None = None,
    routing_allowed_layers: Sequence[str] | None = None) -> dict[str, Any]:
    """Freeze explicit available power resources, separately from default grid.

    The audited initial declaration uses the original PDK ordinary-power hookup
    envelope (14nm M1..M6, 65nm M2..M6) for BOTH candidate windows. This is an
    experimental resource policy, not a claim that higher physical metals are
    absent/illegal. Callers can provide other justified explicit sequences.
    """
    metals = [r for r in pdk["Abstraction"] if r["Layer"].startswith("M")]
    names = [r["Layer"] for r in metals]
    info = pdk["design_info"]
    if info.get(FIELDS[2]) not in names or info.get(FIELDS[3]) not in names:
        raise ContractError("explicit native power-hookup defaults required to declare initial resource policy")
    low, high = names.index(info[FIELDS[2]]), names.index(info[FIELDS[3]])
    if low >= high:
        raise ContractError("original power resource envelope has fewer than two layers")
    available = names[low:high + 1]
    return {"policy": "explicit_available_pdk_resources", "physical_metal_stack": names,
        "grid_allowed_layers": list(grid_allowed_layers) if grid_allowed_layers is not None else available,
        "routing_allowed_layers": list(routing_allowed_layers) if routing_allowed_layers is not None else available,
        "default_grid_window_is_not_a_hard_resource_limit": True,
        "declaration_basis": "explicit campaign resource envelope initially anchored to original ordinary power-hookup envelope",
        "pdk_payload_sha256": _sha(pdk), "physical_metal_and_via_source_sha256": _sha(pdk["Abstraction"]),
        "design_info_original": {field: info[field] for field in FIELDS}}


def power_anchor_catalog(window: Mapping[str, Any]) -> dict[str, Any]:
    result = {}
    for label, q in ANCHORS.items():
        baseline = decode_layer_window(window, q)
        slots = {}
        for index, slot in enumerate(SLOTS):
            rows = []
            for value in Q:
                vector = list(q)
                vector[index] = value
                decoded = decode_layer_window(window, vector)
                rows.append({"q": value, "raw_tuple": decoded["raw_tuple"], "native_index_tuple": decoded["native_index_tuple"],
                    "aliases_anchor": decoded["raw_tuple"] == baseline["raw_tuple"]})
            slots[slot] = {"levels": rows, "effective_level_count": len({tuple(row["raw_tuple"]) for row in rows}),
                "background_q": list(q)}
        result[label] = {"q": list(q), "raw_tuple": baseline["raw_tuple"], "slots": slots,
            "comparison_requires_its_own_matched_baseline": True}
    groups = {}
    for q in product(Q, repeat=4):
        decoded = decode_layer_window(window, q)
        key = ",".join(decoded["raw_tuple"])
        groups.setdefault(key, []).append(list(q))
    return {"anchors": result, "q_tuple_count": 81, "effective_q_tuple_count": len(groups),
        "aliases_by_native_tuple": groups, "scope": "static_conditional_mapping_not_physical_response", "action_dimension_count": 4}


def freeze_power_layer_campaign(baseline_run_dir: str | Path, *, top: str,
    output_path: str | Path | None = None, reference_policy: str,
    grid_allowed_layers: Sequence[str] | None = None, routing_allowed_layers: Sequence[str] | None = None,
    hard_allowed_grid_layers: Sequence[str] | None = None, hard_allowed_routing_layers: Sequence[str] | None = None,
    native_pin_evidence: Mapping[str, Any] | None = None) -> dict[str, Any]:
    if reference_policy not in {"new_power_reference", "reuse_native_power_reference"}:
        raise ContractError("explicit new/reuse power reference policy required")
    scope = collect_power_scope(baseline_run_dir, top=top, native_pin_evidence=native_pin_evidence)
    pdk = scope["pdk_payload"]
    declaration = declare_power_resources(pdk, grid_allowed_layers=grid_allowed_layers, routing_allowed_layers=routing_allowed_layers)
    for field, hard in (("grid_allowed_layers", hard_allowed_grid_layers), ("routing_allowed_layers", hard_allowed_routing_layers)):
        if hard is not None:
            if any(name not in declaration["physical_metal_stack"] for name in hard):
                raise ContractError("hard power resource includes nonexistent layer")
            declaration[field] = [name for name in declaration[field] if name in hard]
    declaration["hard_grid_allowed_layers"] = list(hard_allowed_grid_layers) if hard_allowed_grid_layers is not None else None
    declaration["hard_routing_allowed_layers"] = list(hard_allowed_routing_layers) if hard_allowed_routing_layers is not None else None
    window = build_power_layer_windows(pdk, top=top, pin_access=scope["pin_access"], power_evidence=scope["power_evidence"],
        grid_allowed_layers=declaration["grid_allowed_layers"], routing_allowed_layers=declaration["routing_allowed_layers"],
        resource_policy="explicit", provenance={"resource_declaration": declaration, "scope_artifacts": scope["artifacts"]})
    if window.get("status") != "ready_static":
        raise ContractError(f"power layer preflight blocked: {window.get('blockers')}")
    reference = validate_reference_layer_window(window, pdk["design_info"], REFERENCE_Q)
    if reference["status"] != "matched_reference" and reference_policy != "new_power_reference":
        raise ContractError("reference q changes original native power window; new_power_reference required")
    repo = Path(__file__).resolve().parents[3]
    campaign = {"schema": SCHEMA, "top": top, "scope": scope, "resource_declaration": declaration, "window": window,
        "reference_q": list(REFERENCE_Q), "reference_policy": reference_policy, "native_reference_comparison": reference,
        "reference_status": "matched_native_fields_other_reuse_gates_required" if reference["status"] == "matched_reference" else "pending_new_power_reference_run",
        "resource_identity_sha256": _sha(_resource_identity(pdk)), "static_aliases": power_anchor_catalog(window),
        "source_consumer_paths": SOURCES, "source_artifacts": [_artifact(repo / s.split(":")[0]) for s in SOURCES] + [_artifact(Path(__file__))],
        "action_dimension_count": 4, "runtime_hit_count": None,
        "capacity_preflight": {"status": "unobserved_requires_actual_grid", "baseline_bbox": scope["bbox"],
            "reason": "PowerRouter may enlarge bbox and obstacle removal may eliminate VDD/GND stripes; structural tuples do not prove stripe capacity"},
        "limitations": ["No signal-below-power-grid constraint is added.", "Power pin coverage is conservatively frozen; postaction actual pins must be checked.",
            "Explicit resource declaration, four conditional coordinates and matched per-anchor baselines are separate concepts.", "No electrical signoff or IR/EM inferred from static feasibility."]}
    campaign["campaign_sha256"] = _sha(campaign)
    if output_path is not None:
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x") as stream:
            json.dump(campaign, stream, indent=2)
            stream.write("\n")
    return campaign


def load_power_layer_campaign(campaign: Mapping[str, Any] | str | Path) -> dict[str, Any]:
    value = json.loads(Path(campaign).read_text()) if isinstance(campaign, (str, Path)) else copy.deepcopy(campaign)
    if value.get("schema") != SCHEMA or value.get("campaign_sha256") != _sha({k: v for k, v in value.items() if k != "campaign_sha256"}):
        raise ContractError("power campaign schema/hash mismatch")
    return value


def apply_power_layer_campaign(layers_path: str | Path, campaign: Mapping[str, Any] | str | Path,
    q_values: Mapping[str, Any] | Sequence[Any], *, anchor: str = "reference") -> dict[str, Any]:
    frozen, path = load_power_layer_campaign(campaign), Path(layers_path)
    if anchor not in ANCHORS or anchor not in frozen["static_aliases"]["anchors"]:
        raise ContractError("anchor must be a predeclared power-window background")
    if path.resolve() == Path(frozen["scope"]["workdir"]) / "3_pnr/inputs/layers.json":
        raise ContractError("cannot mutate frozen baseline PDK")
    if frozen["scope"].get("original_pdk_directory") and path.resolve().is_relative_to(Path(frozen["scope"]["original_pdk_directory"])):
        raise ContractError("private run-local PDK required; original baseline generator PDK is immutable")
    pdk = json.loads(path.read_text())
    if _sha(_resource_identity(pdk)) != frozen["resource_identity_sha256"]:
        raise ContractError("PDK physical/hard resources changed since power-window freeze")
    decoded = decode_layer_window(frozen["window"], q_values)
    snapshot = path.with_name("layers.pre_shared32_power_layers.json")
    if snapshot.exists():
        raise ContractError("power layer action already applied")
    original = path.read_bytes()
    pdk["design_info"].update(decoded["raw_values"])
    with snapshot.open("xb") as stream:
        stream.write(original)
    path.write_text(json.dumps(pdk, indent=2) + "\n")
    receipt = {"schema": "shared32-power-layer-pdk-action-v1", "campaign_sha256": frozen["campaign_sha256"],
        "anchor": anchor, "anchor_q": list(ANCHORS[anchor]), "matching_anchor_baseline_required": True,
        "decoded": decoded, "pre_action_layers": _artifact(snapshot), "effective_layers": _artifact(path),
        "all_four_original_design_info_fields_written": True, "runtime_hit_count": None}
    return {"power_layer_broadcast": receipt, "requested_values": decoded["requested_q"], "requested_all_values": decoded["requested_q"],
        "effective_values": decoded["slot_raw_values"], "effective_all_values": decoded["slot_raw_values"],
        "request_write_count": {slot: 1 for slot in SLOTS}, "consumer_status_all": {slot: "prepared_requires_power_readback" for slot in SLOTS}}


def readback_power_layers(trace: Mapping[str, Any], campaign: Mapping[str, Any] | str | Path,
    workdir: str | Path, *, native_observation: Mapping[str, Any] | None = None,
    actual_pin_access: Mapping[str, Any] | None = None) -> dict[str, Any]:
    frozen, work = load_power_layer_campaign(campaign), Path(workdir)
    request = trace.get("power_layer_broadcast", trace)
    if request.get("campaign_sha256") != frozen["campaign_sha256"]:
        raise ContractError("power-layer trace campaign mismatch")
    expected = decode_layer_window(frozen["window"], request["decoded"]["requested_q"])
    result: dict[str, Any] = {"schema": "shared32-power-layer-consumer-readback-v1", "slots": {}, "runtime_hit_count": None,
        "campaign_sha256": frozen["campaign_sha256"], "source_consumer_paths": SOURCES}
    try:
        path = work / "3_pnr/inputs/layers.json"
        pdk = json.loads(path.read_text())
        if _sha(_resource_identity(pdk)) != frozen["resource_identity_sha256"]:
            raise ContractError("loaded physical power resources differ from frozen context")
        result["loaded_layers"] = _artifact(path)
        topology_path = work / "1_topology" / f"{frozen['top']}.verilog.json"
        result["power_scope_status"] = "unobserved"
        if topology_path.is_file():
            actual_globals = json.loads(topology_path.read_text()).get("global_signals")
            if actual_globals != frozen["scope"]["topology"]["global_signals"]:
                raise ContractError("actual compiled supply classification differs from frozen power scope")
            result["power_scope_status"] = "observed_compiled_supply_identity"
        for slot, field, index in zip(SLOTS, FIELDS, expected["native_index_tuple"]):
            matches = pdk["design_info"].get(field) == expected["raw_values"][field]
            result["slots"][slot] = {"status": "observed_artifacts" if matches else "mismatch",
                "actual_layer_name": pdk["design_info"].get(field), "source_inferred_native_index": index if matches else None,
                "native_call_status": "unobserved"}
        result["native_call_evidence"] = "unobserved"
        if native_observation is not None:
            from .shared32_power_skip_adapter import OBSERVER_ROUTER_SHA256
            identity = native_observation.get("runtime_identity", {})
            source = Path(identity.get("module_path", "/nonexistent"))
            if native_observation.get("issues") or not source.is_file() or _artifact(source)["sha256"] != OBSERVER_ROUTER_SHA256:
                raise ContractError("verified ordinary power observer required")
            pairs = {p["mode"]: p for p in native_observation.get("completed_calls", [])}
            if set(pairs) != {2, 3}:
                raise ContractError("completed ordinary grid and hookup calls required")
            expected_rails = set(frozen["scope"]["power_evidence"]["power_ports"] + frozen["scope"]["power_evidence"]["ground_ports"])
            if any({n.get("name") for n in pair["exit"].get("power_nets", [])} != expected_rails for pair in pairs.values()):
                raise ContractError("native power-net identities differ from frozen supply pair")
            for coordinate, slot in enumerate(SLOTS):
                pair = pairs[2 if coordinate < 2 else 3]
                field = "metal_l" if coordinate % 2 == 0 else "metal_u"
                matches = all(event.get("module") == frozen["top"] and event.get("is_top") is True and event.get(field) == expected["native_index_tuple"][coordinate]
                    for event in (pair["enter"], pair["exit"]))
                result["slots"][slot]["native_call_status"] = "observed" if matches else "mismatch"
                if not matches:
                    result["slots"][slot]["status"] = "mismatch"
            result["native_call_evidence"] = {"runtime_identity": identity, "completed_calls": pairs}
        result["actual_pin_containment"] = validate_actual_pin_layers(frozen["window"], expected, actual_pin_access) if actual_pin_access else {"status": "unobserved"}
        good = all(row["status"] == "observed_artifacts" for row in result["slots"].values())
        result["status"] = "observed_artifacts" if good else "mismatch"
        result["consumer_status"] = {slot: row["status"] for slot, row in result["slots"].items()}
        result["full_power_admission"] = "separate_final_power_geometry_connectivity_and_anchor_baseline_gates_required"
    except (OSError, KeyError, ValueError, TypeError, ContractError) as exc:
        result.update(status="mismatch" if isinstance(exc, ContractError) else "unobserved", reason=str(exc))
        result["consumer_status"] = {slot: result["status"] for slot in SLOTS}
    return result
