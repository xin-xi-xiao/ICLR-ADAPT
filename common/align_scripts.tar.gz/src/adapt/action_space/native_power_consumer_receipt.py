"""Explicit W07–W10 native power configuration and actual consumer evidence.

The frozen pitch table belongs to the declared power-hookup resource profile,
independent of the selected W03–W06 window and W01/W02/W07 actions. Configuration
is not evidence: receipts require the private binary and complete native calls.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import statistics

from .native_tuning_config import NativeTuningConfig

PATCH_ID = "align-r6-native-power-v1"
MODULE_SHA256 = "8bfddfda89971c2de5eae59b04c62d056c9fb98f20b31eb979598704f92bf0fb"
MARKER = "ADAPT_R6_NATIVE_POWER_V1 "
ENV_KEYS = {
    "W07": "ADAPT_R6_NATIVE_W07_POWER_WIDTH",
    "W08": "ADAPT_R6_NATIVE_W08_VIA_EXPAND_EFFORT",
    "W09": "ADAPT_R6_NATIVE_W09_SOURCE_COUNT",
    "W10": "ADAPT_R6_NATIVE_W10_EXPAND_SCALE",
}
RESOURCE_ENV = "ADAPT_R6_NATIVE_W08_FROZEN_PITCH"
DEFAULTS = {"W07": 1, "W08": 100, "W09": 7, "W10": 10}
NATIVE_INT_MAX = 2**31 - 1


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def freeze_power_pitch(layers_path, native_indices, *, resource_provenance):
    """Freeze explicit, ascending native indices, with source/unit provenance.

    ReadPDKJSON consumes the FIRST element of a Pitch array and converts the
    integer pitch using integer arithmetic ``2 * pitch / ScaleFactor``. This
    function mirrors that conversion, including truncation. It does not select
    legal layers; callers must supply the preregistered power resource table.
    """
    indices = list(native_indices)
    if (not indices or any(type(i) is not int or i < 0 for i in indices)
            or indices != sorted(set(indices))):
        raise ValueError("explicit ascending unique native power resource indices required")
    if not isinstance(resource_provenance, dict) or not resource_provenance:
        raise ValueError("power-hookup resource declaration provenance required")
    path = Path(layers_path).resolve()
    pdk = json.loads(path.read_text())
    scale = pdk.get("ScaleFactor")
    if type(scale) is not int or scale <= 0:
        raise ValueError("positive native integer ScaleFactor required")
    metals = [row for row in pdk["Abstraction"] if row["Layer"].startswith("M")]
    rows = []
    for index in indices:
        layer = metals[index]
        source = layer.get("Pitch")
        first = source[0] if isinstance(source, list) and source else source
        if type(first) is not int or first <= 0 or 2 * first > NATIVE_INT_MAX:
            raise ValueError("positive, nonoverflowing native source pitch required")
        native = 2 * first // scale
        if native <= 0 or layer.get("Direction") not in ("H", "V"):
            raise ValueError("positive native normal pitch and H/V direction required")
        rows.append({"native_index": index, "layer": layer["Layer"], "direction": layer["Direction"],
                     "source_pitch": source, "source_first_pitch": first, "native_pitch": native})
    return {"schema": "adapt-r6-frozen-power-pitch-v1", "layers_path": str(path), "layers_sha256": _sha(path),
            "scale_factor": scale, "native_length_multiplier": 2, "rows": rows,
            "p_ref": statistics.median(row["native_pitch"] for row in rows),
            "resource_provenance": resource_provenance,
            "mapping": "round_half_up(beta * median_frozen_original_native_normal_pitch)",
            "consumer": "PlaceRouteHierFlow/PnRDB/ReadDesignRuleJson.cpp:ReadPDKJSON; router/A_star.cpp:A_star_algorithm",
            "independent_of": ["W01", "W02", "W03", "W04", "W05", "W06", "W07"]}


def power_environment(config: NativeTuningConfig, active_slots, frozen_resources=None):
    """Encode only active slots. Unset W08 retains native100; beta1 is different.

    All experiments with this binary require a new matched baseline. Activating
    W08 beta=1 additionally creates its explicitly normalized reference profile;
    it must not be called a reuse of the legacy native100 background.
    """
    active = list(active_slots)
    if not active or len(set(active)) != len(active) or set(active) - set(ENV_KEYS):
        raise ValueError("explicit unique W07–W10 activation required")
    values = {row["slot_id"]: row["requested"] for row in config.to_trace()["slots"]}
    result = {}
    for slot in active:
        value = values[slot]
        if slot == "W08":
            if not isinstance(frozen_resources, dict):
                raise ValueError("frozen native power-hookup pitch resources required for W08")
            verified = freeze_power_pitch(frozen_resources["layers_path"],
                [row["native_index"] for row in frozen_resources["rows"]],
                resource_provenance=frozen_resources["resource_provenance"])
            if verified != frozen_resources:
                raise ValueError("frozen resource provenance or native pitch mapping mismatch")
            product = float(value) * verified["p_ref"]
            if not math.isfinite(product) or product < 0 or product > NATIVE_INT_MAX - 0.5:
                raise ValueError("W08 pitch-mapped native effort outside safe integer range")
            value = math.floor(product + 0.5)
            result[RESOURCE_ENV] = ",".join(f'{row["native_index"]}:{row["native_pitch"]}' for row in verified["rows"])
        result[ENV_KEYS[slot]] = str(int(value))
    return result


def readback_native_power(log_paths, requested, runtime_identity):
    """Parse actual C++ call pairs and verify scope, native values and clipping.

    ``runtime_identity`` requires patch_id, module_path, module_sha256,
    manifest_env and independently frozen expected_modules (ordinary power
    modules, generally exact top only); add frozen_resources for active W08.
    Missing/failed consumers remain unobserved/blocked; successful geometry or
    electrical correctness are separate gates, never implied by these receipts.
    """
    issues, events, artifacts = [], [], []
    def issue(status, reason, **context):
        issues.append({"status": status, "reason": reason, **context})
    try:
        env = power_environment(NativeTuningConfig.create(requested), requested, runtime_identity.get("frozen_resources"))
    except (KeyError, ValueError, TypeError, OSError, IndexError) as exc:
        env = {}; issue("blocked_scope", "invalid_or_missing_frozen_configuration", detail=str(exc))
    try:
        actual_sha = _sha(runtime_identity["module_path"])
    except (KeyError, OSError, TypeError):
        actual_sha = None
    if (actual_sha != MODULE_SHA256 or runtime_identity.get("module_sha256") != MODULE_SHA256
            or runtime_identity.get("patch_id") != PATCH_ID):
        issue("mismatch", "actual_native_binary_identity_mismatch")
    manifest_env = runtime_identity.get("manifest_env", {})
    if not isinstance(manifest_env, dict) or any(manifest_env.get(key) != value for key, value in env.items()):
        issue("mismatch", "manifest_environment_disagrees_with_requested_values")
    expected = runtime_identity.get("expected_modules", [])
    if (not isinstance(expected, list) or not expected or len(set(expected)) != len(expected)
            or any(not isinstance(v, str) or not v for v in expected)):
        expected = []; issue("blocked_scope", "independent_power_module_inventory_missing")
    seen = set()
    for supplied in log_paths:
        path = Path(supplied).resolve()
        if path in seen:
            issue("mismatch", "duplicate_log_path", path=str(path)); continue
        seen.add(path)
        try:
            data = path.read_bytes()
        except OSError:
            issue("unobserved", "native_log_missing", path=str(path)); continue
        artifacts.append({"path": str(path), "sha256": hashlib.sha256(data).hexdigest()})
        for number, line in enumerate(data.decode(errors="replace").splitlines(), 1):
            if MARKER not in line:
                continue
            try:
                row = json.loads(line.split(MARKER, 1)[1])
                if not isinstance(row, dict): raise ValueError("object required")
            except (ValueError, TypeError):
                issue("mismatch", "malformed_native_marker", path=str(path), line=number); continue
            if row.get("patch_id") != PATCH_ID or row.get("module") not in expected or row.get("mode") not in (2, 3):
                issue("mismatch", "native_patch_or_power_scope_mismatch", path=str(path), line=number)
            events.append({"fields": row, "path": str(path), "line": number})
    pending, calls = {}, []
    for event in events:
        row = event["fields"]
        if row.get("kind") == "failure":
            issue(row.get("class", "native_failure"), row.get("reason", "native_failure"), event=event)
        if row.get("phase") not in ("enter", "exit"):
            continue
        key = (event["path"], row.get("module"), row.get("mode"), row.get("kind"),
               row.get("net"), row.get("pin"), row.get("multi"), row.get("search"))
        if row["phase"] == "enter":
            if key in pending: issue("unobserved", "consumer_reentered_without_completion", event=event)
            call = {"kind": row.get("kind"), "module": row.get("module"), "mode": row.get("mode"), "entry": event, "exit": None}
            calls.append(call); pending[key] = call
        else:
            call = pending.pop(key, None)
            if call is None: issue("unobserved", "consumer_exit_without_entry", event=event)
            else: call["exit"] = event
            if row.get("unwinding_exception"): issue("native_failure", "consumer_unwound_exception", event=event)
    if pending:
        issue("unobserved", "incomplete_native_consumer_calls", count=len(pending))
    module_pairs = {(c["module"], c["mode"]) for c in calls if c["kind"] == "module" and c["exit"] is not None}
    if module_pairs != {(module, mode) for module in expected for mode in (2, 3)}:
        issue("unobserved", "ordinary_power_grid_and_hookup_module_coverage_incomplete",
              observed=sorted(module_pairs), expected=expected)
    slots = {}
    kinds = {"W07": "grid_width", "W08": "astar", "W09": "selection", "W10": "selection"}
    for slot, normalized in requested.items():
        if slot not in kinds: continue
        local = list(issues)
        def bad(reason, **context): local.append({"status": "mismatch", "reason": reason, **context})
        wanted = int(env[ENV_KEYS[slot]]) if ENV_KEYS[slot] in env else None
        selected = [c for c in calls if c["kind"] == kinds[slot]]
        completed = [c for c in selected if c["exit"] is not None]
        if {c["module"] for c in completed} != set(expected):
            local.append({"status": "unobserved", "reason": "slot_consumer_scope_incomplete"})
        for call in completed:
            row = call["exit"]["fields"]
            configs = [call["entry"]["fields"].get(slot, {}), row.get(slot, {})]
            if any(c.get("effective") != wanted or c.get("native_default") != DEFAULTS[slot]
                   or c.get("override_enabled") is not True or c.get("requested_raw") != str(wanted) for c in configs):
                bad("native_requested_effective_configuration_mismatch", call=call)
            if call["mode"] != (2 if slot == "W07" else 3): bad("slot_wrong_native_power_mode")
            try:
                if slot == "W07":
                    rows = row["rows"]
                    active = [v for v in rows if v["in_active_grid_window"]]
                    if not active or any(v["effective_width"] != v["baseline_width"] * wanted or not v["unit_R_unchanged"]
                                         or not v["unit_C_unchanged"] for v in rows):
                        bad("power_grid_width_or_unchanged_rc_mismatch")
                elif slot == "W08":
                    if row["cost_evaluations"] < row["via_transitions_evaluated"] or row["maximum_via_penalty"] < 0:
                        bad("invalid_actual_astar_cost_counts")
                elif slot == "W09":
                    records = row["selected_records"]
                    if (len(records) != min(wanted, row["distance_map_records"])
                        or len({v["grid_segment_index"] for v in records}) != row["selected_unique_segments"]
                        or row["distance_tie_discards"] != row["raw_distance_pairs"] - row["distance_map_records"]
                        or row["saturated"] != (row["distance_map_records"] <= wanted)):
                        bad("distance_map_selection_or_saturation_mismatch")
                elif slot == "W10":
                    bbox, pitches = row["source_target_bbox"], row["margin_pitch"]
                    unclip = [bbox[0]-wanted*pitches[0], bbox[1]-wanted*pitches[1], bbox[2]+wanted*pitches[0], bbox[3]+wanted*pitches[1]]
                    clip = [max(0,unclip[0]), max(0,unclip[1]), min(row["layout_extent"][0],unclip[2]), min(row["layout_extent"][1],unclip[3])]
                    if row["unclipped_window"] != unclip or row["window"] != clip or row["clip_sides"] != [a != b for a,b in zip(unclip,clip)]:
                        bad("native_margin_or_clipped_window_mismatch")
            except (KeyError, TypeError, ValueError):
                bad("native_consumer_detail_fields_missing_or_invalid", call=call)
        if slot == "W08" and runtime_identity.get("frozen_resources"):
            resource_events = [e["fields"] for e in events if e["fields"].get("kind") == "pitch_resources"]
            frozen = runtime_identity["frozen_resources"]
            wanted_rows = [{"native_index": r["native_index"], "layer": r["layer"], "direction": 0 if r["direction"] == "V" else 1,
                            "native_pitch": r["native_pitch"]} for r in frozen["rows"]]
            if {r["module"] for r in resource_events} != set(expected) or any(r.get("rows") != wanted_rows or r.get("p_ref") != frozen["p_ref"] for r in resource_events):
                bad("actual_native_frozen_pitch_resources_mismatch")
        status = "observed" if not local and completed else "unobserved"
        for severity in ("mismatch", "numerical_unsafe_runtime", "native_failure", "invalid_native_tuning_config", "blocked_scope"):
            if any(i["status"] == severity for i in local): status = severity; break
        slots[slot] = {"status": status, "requested": normalized, "expected_native": wanted,
            "native_default": DEFAULTS[slot], "consumer_hit_count": len(completed), "calls": selected,
            "evidence_kind": "actual_cpp_native_power_consumer_calls", "issues": local,
            "full_layout_geometry_validity": "separate_result_gate", "electrical_correctness": "not_inferred_from_consumer_receipt"}
        if slot == "W08":
            slots[slot]["via_transitions_evaluated"] = sum(c["exit"]["fields"].get("via_transitions_evaluated", 0) for c in completed)
            slots[slot]["effective_cost_opportunity"] = bool(slots[slot]["via_transitions_evaluated"])
    return {"schema": "adapt-r6-native-power-consumer-readback-v1", "patch_id": PATCH_ID,
        "runtime_identity": runtime_identity, "artifacts": artifacts, "slots": slots, "issues": issues,
        "all_active_slots_observed": bool(slots) and all(s["status"] == "observed" for s in slots.values()),
        "new_matched_baseline_required": True,
        "failed_hookups": [e for e in events if e["fields"].get("kind") == "hookup_result" and e["fields"].get("path_found") is False]}
