"""Compiled Generator.parameters binding for fixed shared32 MOS actions.

Runs after 1_topology, before restarting at 2_primitives. No ALIGN import or
process launch is performed here. Baseline generated geometry supplies frozen
shape ordering; writes, generated artifacts, inferred state, and runtime state
are kept distinct. G05 belongs to its separate native bridge.
"""
from __future__ import annotations

import copy
import ast
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from adapt.contracts.common import ContractError

SCHEMA = "shared32-frozen-MOS-primitive-campaign-v1"
SLOTS = ("G01", "G02", "G03", "G04")
DOMAINS = {"G01": (0, 1, 2, 4), "G02": (0, .25, .5, .75, 1),
           "G03": ("cc", "id", "ncc"), "G04": (0, 1)}
REFERENCE = {"G01": 0, "G02": .5, "G03": "cc", "G04": 1}
FIELDS = {"G01": "height", "G02": "legal_sizes", "G03": "pattern", "G04": "shared_diff"}
PDKS = {"FinFET14nm_Mock_PDK": "finfet", "Bulk65nm_Mock_PDK": "bulk"}


def _sha(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _artifact(path: Path) -> dict[str, str]:
    return {"path": str(path.resolve()), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def _int(value: Any, label: str, *, minimum: int = 0) -> int:
    try:
        decimal = Decimal(str(value))
        integer = int(decimal)
    except (ValueError, ArithmeticError):
        raise ContractError(f"{label}: finite integer required") from None
    if isinstance(value, bool) or decimal != integer or integer < minimum:
        raise ContractError(f"{label}: integer >= {minimum} required")
    return integer


def _generator(primitive: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    rows = [c for c in primitive.get("constraints", []) if c.get("constraint") == "Generator"]
    if len(rows) != 1 or str(rows[0].get("name", "")).upper() != "MOS":
        raise ContractError(f"{primitive.get('name')}: exactly one MOS Generator constraint required")
    parameters = rows[0].get("parameters")
    if parameters is not None and not isinstance(parameters, dict):
        raise ContractError("Generator.parameters must be a mapping or null")
    return copy.deepcopy(rows[0]), copy.deepcopy(parameters or {})


def _library_identity(library: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    # Electrical models, elements, pins, definition/master identities, all hard
    # constraints and their original parameters remain in the frozen payload.
    names = [row.get("name") for row in library]
    if any(not isinstance(name, str) or not name for name in names) or len(names) != len(set(names)):
        raise ContractError("primitive library names must be unique")
    return copy.deepcopy(list(library))


def resolve_height_mapping(parameters: Mapping[str, Any], fin: Any, pdk: Mapping[str, Any], *, api_height: Any = 28) -> dict[str, Any]:
    """Mirror the two actual height assignments, including explicit zero.

    API default 28 is replaced when main.py sees a height key, including 0.
    MOSGenerator then applies max(input,4*ceil((fin+16)/4)); only a truthy height
    overrides that fallback again. The shared32 reference separately has >=28.
    """
    layers = {row["Layer"]: row for row in pdk["Abstraction"]}
    pf = _int(layers["Fin"]["Pitch"], "Fin.Pitch", minimum=1)
    p2 = _int(layers["M2"]["Pitch"], "M2.Pitch", minimum=1)
    f = _int(fin, "generator fin", minimum=2)
    api = _int(api_height, "generate_primitive API height")
    explicit = parameters.get("height") if "height" in parameters else None
    supplied = _int(explicit, "Generator.height") if "height" in parameters else api
    fallback = max(supplied, 4 * ((f + 19) // 4))
    effective = supplied if explicit else fallback
    if effective % 4 or (effective * pf) % p2 or (effective - f) // 2 < 8:
        raise ContractError("baseline effective native height violates generator assertions")
    step = math.lcm(4, p2 // math.gcd(pf, p2))
    reference = ((max(28, f + 16, supplied) + step - 1) // step) * step
    return {"fin": f, "fin_pitch": pf, "m2_pitch": p2, "api_height": api,
            "original_height_key_present": "height" in parameters, "original_height_raw": explicit,
            "native_main_height_input": supplied, "native_baseline_effective_height": effective,
            "height_zero_semantics": "fallback_after_main_overrides_API28_not_necessarily_28",
            "legal_increment": step, "reference_height": reference,
            "reference_changes_native_height": reference != effective,
            "raw_height_by_k": {str(k): reference + k * step for k in DOMAINS["G01"]}}


def _electrical(primitive: Mapping[str, Any], family: str, pdk: Mapping[str, Any]) -> dict[str, Any]:
    elements = primitive.get("elements", [])
    if len(elements) not in (1, 2):
        raise ContractError("audited MOS protocol requires one or two electrical devices")
    units, sizes, fins = [], [], []
    for element in elements:
        values = element["parameters"]
        nf, multiplier = _int(values["NF"], "NF", minimum=1), _int(values["M"], "M", minimum=1)
        parallel = _int(values.get("PARALLEL", 1), "PARALLEL", minimum=1)
        multiplier *= parallel
        if family == "finfet":
            fin = _int(values["NFIN"], "NFIN", minimum=2)
            if nf % 2 or fin > pdk["design_info"]["unit_size_mos"]:
                raise ContractError("FinFET electrical decomposition violates native NF/NFIN bounds")
            electrical_width = fin
        else:
            electrical_width = int(float(values["W"]) * 1e9)
            fin = int(float(values["W"]) * 1e9 / pdk["design_info"]["Fin_pitch"])
        fins.append(fin)
        units.append(nf * multiplier)
        sizes.append(electrical_width * nf * multiplier)
    if len(set(fins)) != 1:
        raise ContractError("MOS generator requires equal device NFIN/quantized widths")
    count = math.ceil(sum(units) / (2 * len(elements)))
    unequal = len(elements) == 2 and sizes[0] != sizes[1]
    bypass = unequal and (family == "finfet" or "SCM" in primitive["name"])
    return {"device_count": len(elements), "fin": fins[-1], "factor_product": count,
            "unequal_device_sizes": unequal, "legal_sizes_consumer_bypassed": bypass,
            "equal_parameter_pair": len(elements) == 2 and elements[0]["parameters"] == elements[1]["parameters"] and elements[0]["model"] == elements[1]["model"],
            "common_source_pair": len(elements) == 2 and elements[0]["pins"].get("S") == elements[1]["pins"].get("S"),
            "electrical_elements_sha256": _sha(elements)}


def _legal_pair(pair: tuple[int, int], sizes: Any) -> bool:
    if sizes is None:
        return True
    if not isinstance(sizes, list) or any(not isinstance(row, dict) for row in sizes):
        raise ContractError("hard legal_sizes must be a list of patterns")
    return any(all(key not in row or row[key] == value for key, value in zip(("x", "y"), pair)) for row in sizes)


def _pattern(parameters: Mapping[str, Any], electrical: Mapping[str, Any], x: int) -> str:
    pattern = parameters.get("pattern") or ("single_device" if electrical["device_count"] == 1
                else "cc" if electrical["equal_parameter_pair"] else "ratio_devices")
    if pattern not in {"single_device", "cc", "id", "ratio_devices", "ncc"}:
        raise ContractError("unknown native MOS pattern")
    if electrical["device_count"] == 2 and (2 * x) % 4:
        pattern = "id"
    if electrical["unequal_device_sizes"]:
        pattern = "ratio_devices"
    return pattern


def _source_width(x: int, electrical: Mapping[str, Any], shared: int, mapping: Mapping[str, Any]) -> int:
    gates = x * electrical["device_count"] * (2 * mapping["stack"] + 6 * (1 - shared)) + 6 * shared
    width = gates * mapping["poly_pitch"]
    if mapping["family"] == "bulk":
        # Bulk add{N,P}MOSArray expands select/nwell to the M3 region grid.
        p3 = mapping["m3_pitch"]
        return ((width + p3 - 1) // p3 + (mapping["poly_pitch"] + p3 - 1) // p3) * p3
    return width


def _capability(primitive: Mapping[str, Any], parameters: Mapping[str, Any], electrical: Mapping[str, Any]) -> dict[str, Any]:
    caps = {slot: {"status": "eligible", "reason": None} for slot in SLOTS}
    if parameters.get("exact_patterns") is not None:
        for slot in ("G02", "G03"):
            caps[slot] = {"status": "inapplicable_hard_constraint", "reason": "original Generator.exact_patterns retained; legal_sizes is mutually exclusive"}
    elif electrical["legal_sizes_consumer_bypassed"]:
        caps["G02"] = {"status": "inapplicable_native_branch", "reason": "native unequal-ratio branch bypasses add_primitive/legal_sizes"}
    elif electrical["unequal_device_sizes"]:
        caps["G02"] = {"status": "blocked_shape_preflight", "reason": "unequal non-SCM Bulk shape path requires dedicated electrical/row feasibility evidence"}
    if not electrical["equal_parameter_pair"]:
        caps["G03"] = {"status": "inapplicable_structure", "reason": "pattern action is defined only for equal-parameter two-device MOS primitives"}
    elif "pattern" in parameters and parameters["pattern"]:
        caps["G03"] = {"status": "inapplicable_hard_constraint", "reason": "original explicit Generator.pattern retained as hard arrangement"}
    else:
        # Implicit cc is not hard. Preserve explicit geometric matching/order
        # constraints whose equivalence under a changed arrangement is unknown.
        hard = [c for c in primitive["constraints"] if c.get("constraint") in {"CommonCentroid", "SymmetricBlocks", "Order", "Align"}]
        if hard:
            caps["G03"] = {"status": "blocked_hard_matching", "reason": "explicit primitive geometric matching/order constraint needs arrangement equivalence validation", "hard_constraints": hard}
    if not electrical["equal_parameter_pair"] or not electrical["common_source_pair"]:
        caps["G04"] = {"status": "inapplicable_electrical_structure", "reason": "comparison restricted to equal-parameter pair with the same source net; electrical connections are never altered"}
    elif "shared_diff" in parameters:
        caps["G04"] = {"status": "inapplicable_hard_constraint", "reason": "original explicit Generator.shared_diff retained"}
    caps["G04"]["postaction_gate"] = "actual native primitive opens/shorts/DRC plus preserved electrical dispatch required; standalone LVS reported separately"
    return caps


def freeze_primitive_campaign(
    baseline_run_dir: str | Path, pdk_dir: str | Path, *, top: str,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Freeze every eligible MOS definition and its complete baseline shape set.

    A missing factor-pair artifact blocks G02 for the task instead of silently
    restricting its domain. Existing partial legal_sizes filters are respected.
    DRC/LVS is reported separately from observed generated geometry. G01 can be
    used independently of G02, retaining the original multi-variant pool.
    """
    run, pdk_dir = Path(baseline_run_dir).resolve(), Path(pdk_dir).resolve()
    if pdk_dir.name not in PDKS:
        raise ContractError("MOS generator protocol has not been audited for this PDK")
    output = Path(output_path) if output_path is not None else None
    if output is not None and output.exists():
        raise ContractError("frozen primitive campaign already exists")
    manifest = json.loads((run / "run_manifest.json").read_text())
    if manifest.get("returncode") != 0 or manifest.get("collector_status") != "ok":
        raise ContractError("completed baseline primitive/artifact context required")
    work = run / "align_workdir"
    library_path = work / "1_topology" / "__primitives_library__.json"
    library = _library_identity(json.loads(library_path.read_text()))
    topology_path = work / "1_topology" / f"{top}.verilog.json"
    topology = json.loads(topology_path.read_text())
    if top not in [m["name"] for m in topology["modules"]]:
        raise ContractError("exact compiled top absent")
    used = {i["abstract_template_name"] for m in topology["modules"] for i in m["instances"]}
    args_path = work / "2_primitives" / "__primitives__.json"
    arguments = json.loads(args_path.read_text())
    pdk = json.loads((pdk_dir / "layers.json").read_text())
    if pdk != json.loads((work / "3_pnr" / "inputs" / "layers.json").read_text()):
        raise ContractError("PDK differs from actual baseline generator/router resources")
    artifacts = [_artifact(path) for path in (library_path, topology_path, args_path, run / "run_manifest.json",
                 pdk_dir / "layers.json", pdk_dir / "mos.py", pdk_dir / "gen_param.py",
                 pdk_dir.parent.parent / "align/primitive/main.py",
                 pdk_dir.parent.parent / "align/schema/constraint.py", Path(__file__))]
    definitions = {}
    for primitive in library:
        if (primitive.get("generator") or {}).get("name", "").upper() != "MOS":
            continue
        name = primitive["name"]
        if name not in used:
            raise ContractError(f"unused MOS definition {name}: explicit scope resolution required")
        _, parameters = _generator(primitive)
        electrical = _electrical(primitive, PDKS[pdk_dir.name], pdk)
        variants = {key: row for key, row in arguments.items() if row.get("abstract_template_name") == name}
        if not variants:
            raise ContractError(f"{name}: no completed baseline primitive variants")
        if any(int(row["value"]) != electrical["fin"] for row in variants.values()):
            raise ContractError(f"{name}: actual generator fin differs from source electrical decomposition")
        api_heights = {row.get("height", 28) for row in variants.values()}
        if len(api_heights) != 1:
            raise ContractError(f"{name}: baseline variants have different native height contexts")
        height = resolve_height_mapping(parameters, electrical["fin"], pdk, api_height=next(iter(api_heights)))
        api_bodies = {row.get("bodyswitch", 1) for row in variants.values()}
        if len(api_bodies) != 1:
            raise ContractError(f"{name}: baseline variants have different body contexts")
        body = _int(parameters.get("body", next(iter(api_bodies))), "body")
        if body not in (0, 1):
            raise ContractError("native body comparison requires existing 0/1 body context")
        capabilities = _capability(primitive, parameters, electrical)
        layers = {row["Layer"]: row for row in pdk["Abstraction"]}
        stacks = {_int(row.get("stack", 1), "generator stack", minimum=1) for row in variants.values()}
        if len(stacks) != 1:
            raise ContractError(f"{name}: baseline variants have different stack contexts")
        pitch = layers["Poly"]["Pitch"]
        if PDKS[pdk_dir.name] == "bulk":
            length_diff = round(float(primitive["elements"][0]["parameters"]["L"]) * 1e9) - layers["Poly"]["Width"]
            pitch += length_diff + (20 if length_diff >= 100 else 0)
        width_mapping = {"family": PDKS[pdk_dir.name], "stack": next(iter(stacks)),
                         "poly_pitch": pitch, "m3_pitch": layers["M3"]["Pitch"]}
        rows, observed_pairs = [], set()
        for concrete, values in sorted(variants.items()):
            x, y = _int(values["x_cells"], "x_cells", minimum=1), _int(values["y_cells"], "y_cells", minimum=1)
            if x * y != electrical["factor_product"] and parameters.get("exact_patterns") is None:
                raise ContractError(f"{name}: generated x*y differs from frozen electrical factor product")
            path = work / "2_primitives" / f"{concrete}.json"
            geometry = json.loads(path.read_text())
            bbox = geometry["bbox"]
            width, actual_height = bbox[2] - bbox[0], bbox[3] - bbox[1]
            if width <= 0 or actual_height <= 0:
                raise ContractError(f"{concrete}: nonpositive baseline geometry")
            inferred = Fraction(actual_height, (y + body) * height["fin_pitch"])
            if inferred != height["native_baseline_effective_height"]:
                raise ContractError(f"{concrete}: baseline bbox disagrees with audited height/body/row mapping")
            observed_pairs.add((x, y))
            shape = {"x": x, "y": y, "concrete_name": concrete, "bbox": bbox,
                     "width": width, "height": actual_height,
                     "aspect_ratio_fraction": [width, actual_height], "geometry": _artifact(path),
                     "effective_pattern": _pattern(parameters, electrical, x),
                     "electrical_dispatch_arguments": {k: copy.deepcopy(v) for k, v in values.items()
                         if k not in {"x_cells", "y_cells", "abstract_template_name", "concrete_template_name"}},
                     "effective_shared_diff": parameters.get("shared_diff", 1 if electrical["device_count"] == 1 or electrical["common_source_pair"] else 0),
                     "validation": "baseline_generated_geometry_and_electrical_shape_identity_observed",
                     "individual_primitive_DRC_LVS": "unobserved_not_implied_by_file_presence"}
            rows.append(shape)
            artifacts.append(shape["geometry"])
            if capabilities["G04"]["status"] == "eligible" and _source_width(x, electrical, shape["effective_shared_diff"], width_mapping) != width:
                capabilities["G04"] = {"status": "blocked_geometry_preflight",
                    "reason": "actual baseline bbox width differs from audited shared-diffusion region mapping"}
        count = electrical["factor_product"]
        expected = {(x, count // x) for x in range(1, math.isqrt(count) + 1) if count % x == 0}
        expected |= {(y, x) for x, y in expected}
        expected = {pair for pair in expected if _legal_pair(pair, parameters.get("legal_sizes"))}
        if capabilities["G02"]["status"] == "eligible" and expected != observed_pairs:
            capabilities["G02"] = {"status": "blocked_shape_preflight",
                "reason": "baseline artifacts do not cover the full original-hard-filtered electrical factor table; no dynamic fallback",
                "missing_pairs": [list(pair) for pair in sorted(expected - observed_pairs)],
                "unexpected_pairs": [list(pair) for pair in sorted(observed_pairs - expected)]}
        rows.sort(key=lambda row: (Fraction(row["width"], row["height"]), row["x"], row["y"]))
        if len(observed_pairs) != len(rows):
            raise ContractError(f"{name}: ambiguous duplicate baseline geometry for one factor pair")
        definitions[name] = {"electrical": electrical, "baseline_generator_parameters": parameters,
                             "baseline_variants": rows, "shape_table": rows if capabilities["G02"]["status"] == "eligible" else [],
                             "height_mapping": height, "width_mapping": width_mapping, "body": body, "capabilities": capabilities,
                             "definition_sha256": _sha(primitive)}
    if not definitions:
        raise ContractError("no MOS definitions in exact compiled scope")
    scopes = {slot: {"eligible_definitions": [name for name, row in definitions.items() if row["capabilities"][slot]["status"] == "eligible"],
                     "excluded_definitions": {name: row["capabilities"][slot] for name, row in definitions.items() if row["capabilities"][slot]["status"] != "eligible"}}
              for slot in SLOTS}
    for slot, scope in scopes.items():
        blocked = any(row["status"].startswith("blocked") for row in scope["excluded_definitions"].values())
        # An incomplete feasible size table prevents an all-eligible G02 run.
        # G03 has a frozen conditional subset: explicit hard matching remains
        # excluded with its exact unresolved constraints, without vetoing other
        # equal-device primitives that have no such hard arrangement.
        scope["status"] = "blocked_capability" if blocked and (slot == "G02" or not scope["eligible_definitions"]) else "ready_static" if scope["eligible_definitions"] else "inapplicable"
        scope["coverage"] = "all_eligible_definitions_under_frozen_per_slot_capability_policy"
    campaign = {"schema": SCHEMA, "top": top, "baseline_run_dir": str(run), "pdk_dir": str(pdk_dir),
                "pdk_payload": pdk, "pdk_payload_sha256": _sha(pdk), "baseline_library": library,
                "baseline_library_sha256": _sha(library), "baseline_library_path": str(library_path),
                "baseline_topology_path": str(topology_path), "baseline_topology_sha256": _sha(topology),
                "definitions": definitions, "scope_by_slot": scopes, "domains": DOMAINS, "reference": REFERENCE,
                "shape_quantile_rule": "floor(q*(n-1)+0.5), bbox W/H then (x,y), x before pair doubling",
                "artifacts": artifacts, "runtime_hit_counts": None,
                "limitations": ["Generated baseline shapes are structural evidence, not individual DRC/LVS signoff.",
                                "G02 single-pair selection is an explicit new primitive-reference profile.",
                                "G01 height zero is resolved through the two native assignments; k=0 is not raw height=0.",
                                "Action primitive pins must be checked against any independently frozen routing windows."]}
    campaign["campaign_sha256"] = _sha(campaign)
    campaign["static_aliases"] = primitive_alias_catalog(campaign)
    campaign["campaign_sha256"] = _sha({k: v for k, v in campaign.items() if k != "campaign_sha256"})
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x") as stream:
            json.dump(campaign, stream, indent=2)
            stream.write("\n")
    return campaign


def load_primitive_campaign(campaign: Mapping[str, Any] | str | Path) -> dict[str, Any]:
    value = json.loads(Path(campaign).read_text()) if isinstance(campaign, (str, Path)) else copy.deepcopy(campaign)
    if value.get("schema") != SCHEMA or _sha({k: v for k, v in value.items() if k != "campaign_sha256"}) != value.get("campaign_sha256"):
        raise ContractError("primitive campaign schema/hash mismatch")
    return value


def decode_primitive_values(campaign: Mapping[str, Any] | str | Path, values: Mapping[str, Any], *,
                            active_slots: Sequence[str] = ("G01",)) -> dict[str, Any]:
    frozen = load_primitive_campaign(campaign)
    if not active_slots or len(set(active_slots)) != len(active_slots) or any(slot not in SLOTS for slot in active_slots):
        raise ContractError("unique G01/G02/G03/G04 active slots required; G05 is a separate bridge")
    requested = {}
    for slot in active_slots:
        value = values.get(slot)
        if isinstance(value, bool) or value not in DOMAINS[slot]:
            raise ContractError(f"{slot}: requested value outside the frozen domain")
        if frozen["scope_by_slot"][slot]["status"] != "ready_static":
            raise ContractError(f"{slot}: {frozen['scope_by_slot'][slot]}")
        requested[slot] = value
    decoded = {}
    for name, definition in frozen["definitions"].items():
        params, scope = copy.deepcopy(definition["baseline_generator_parameters"]), {}
        for slot in active_slots:
            if name not in frozen["scope_by_slot"][slot]["eligible_definitions"]:
                continue
            value = requested[slot]
            if slot == "G01":
                raw = definition["height_mapping"]["reference_height"] + int(value) * definition["height_mapping"]["legal_increment"]
                details = {"height_units": "generator_fin_pitch_units", "baseline_native_effective": definition["height_mapping"]["native_baseline_effective_height"]}
            elif slot == "G02":
                table = definition["shape_table"]
                rank = (int(value * 4) * (len(table) - 1) + 2) // 4
                chosen = table[rank]
                raw = [{"x": chosen["x"], "y": chosen["y"]}]
                levels = {(table[(int(q * 4) * (len(table) - 1) + 2) // 4]["x"], table[(int(q * 4) * (len(table) - 1) + 2) // 4]["y"]) for q in DOMAINS[slot]}
                details = {"rank": rank, "candidate_count": len(table), "effective_level_count": len(levels), "frozen_baseline_geometry": chosen["geometry"]}
            else:
                raw, details = value, {"postaction_electrical_geometry_checks_required": True}
            params[FIELDS[slot]] = raw
            scope[slot] = {"requested": value, "raw_value": raw, **details, "runtime_hit_count": None}
        if scope:
            selected = params.get("legal_sizes") if "G02" in scope else None
            pairs = [(row["x"], row["y"]) for row in selected] if selected else [(row["x"], row["y"]) for row in definition["baseline_variants"]]
            if "G03" in scope:
                scope["G03"]["source_inferred_effective_patterns_by_pair"] = [
                    {"x": x, "y": y, "pattern": _pattern(params, definition["electrical"], x)} for x, y in pairs]
            decoded[name] = {"generator_parameters": params, "slots": scope}
    return {"campaign_sha256": frozen["campaign_sha256"], "requested_values": requested,
            "active_slots": list(active_slots), "decoded_by_definition": decoded,
            "scope_by_slot": {slot: frozen["scope_by_slot"][slot] for slot in active_slots}}


def primitive_alias_catalog(campaign: Mapping[str, Any] | str | Path) -> dict[str, Any]:
    """Static effective aliases for each slot with other Generator fields frozen.

    These are source/geometry equivalences, not measured response equivalences.
    An all-alias factor must not be budgeted as a physical contrast.
    """
    frozen = load_primitive_campaign(campaign)
    result = {}
    for slot in SLOTS:
        scope = frozen["scope_by_slot"][slot]
        if scope["status"] != "ready_static":
            result[slot] = {"status": scope["status"], "effective_level_count": 0,
                            "excluded_definitions": scope["excluded_definitions"]}
            continue
        groups = {}
        for value in DOMAINS[slot]:
            decoded = decode_primitive_values(frozen, {slot: value}, active_slots=(slot,))
            effective = {}
            for name, row in decoded["decoded_by_definition"].items():
                action = row["slots"][slot]
                effective[name] = action["source_inferred_effective_patterns_by_pair"] if slot == "G03" else action["raw_value"]
            key = _sha(effective)
            group = groups.setdefault(key, {"raw_levels": [], "effective_values": effective,
                                           "effective_signature": key})
            group["raw_levels"].append(value)
        aliases = list(groups.values())
        reference_group = next(row for row in aliases if REFERENCE[slot] in row["raw_levels"])
        result[slot] = {"status": "static_equivalence", "raw_level_count": len(DOMAINS[slot]),
                        "effective_level_count": len(groups), "all_levels_alias": len(groups) == 1,
                        "nonreference_effective_level_count": len(groups) - 1,
                        "reference_aliases": reference_group["raw_levels"], "groups": aliases,
                        "background": "other_Generator_fields_and_original_variant_pool_frozen"}
    return result


def broadcast_compiled_primitives(
    library_path: str | Path, campaign: Mapping[str, Any] | str | Path,
    values: Mapping[str, Any], *, active_slots: Sequence[str] = ("G01",), reference_policy: str,
) -> dict[str, Any]:
    """Write each eligible master once; never mutate topology, pins, or G05.

    Requires ``new_primitive_reference`` whenever G02 is active or G01 k=0
    differs from native baseline height. Otherwise the explicit policy may be
    ``reuse_compatible_primitive_background``; all other reuse gates remain.
    """
    if reference_policy not in {"new_primitive_reference", "reuse_compatible_primitive_background"}:
        raise ContractError("explicit primitive reference policy required")
    frozen, path = load_primitive_campaign(campaign), Path(library_path)
    if path.resolve() == Path(frozen["baseline_library_path"]):
        raise ContractError("cannot overwrite the baseline primitive library")
    original_bytes = path.read_bytes()
    library = _library_identity(json.loads(original_bytes))
    if library != frozen["baseline_library"]:
        raise ContractError("fresh compiled primitive/electrical/hard-constraint identity differs from baseline")
    decoded = decode_primitive_values(frozen, values, active_slots=active_slots)
    changed_height = [name for name in frozen["scope_by_slot"]["G01"]["eligible_definitions"]
                      if frozen["definitions"][name]["height_mapping"]["reference_changes_native_height"]] if "G01" in active_slots else []
    if ("G02" in active_slots or changed_height) and reference_policy != "new_primitive_reference":
        raise ContractError("G02 single-pair profile or changed G01 native fallback requires new_primitive_reference")
    snapshot = path.with_name(path.stem + ".pre_shared32_primitives.json")
    if snapshot.exists():
        raise ContractError("primitive broadcaster already applied; no action accumulation")
    result = copy.deepcopy(library)
    for primitive in result:
        if primitive["name"] not in decoded["decoded_by_definition"]:
            continue
        updated = decoded["decoded_by_definition"][primitive["name"]]
        for constraint in primitive["constraints"]:
            if constraint.get("constraint") == "Generator":
                constraint["parameters"] = updated["generator_parameters"]
    with snapshot.open("xb") as stream:
        stream.write(original_bytes)
    path.write_text(json.dumps(result, indent=2) + "\n")
    effective = {slot: {name: row["slots"][slot]["raw_value"] for name, row in decoded["decoded_by_definition"].items() if slot in row["slots"]} for slot in active_slots}
    receipt = {"schema": "shared32-compiled-MOS-generator-broadcast-v1", **decoded,
               "reference_policy": reference_policy, "reference_height_changes": changed_height,
               "routing_reference_compatibility": "actual_generated_pin_layers_must_be_rechecked",
               "baseline_reuse_claim": False if reference_policy == "new_primitive_reference" else "other_identity_gates_required",
               "library_path": str(path.resolve()), "pre_action_library": _artifact(snapshot),
               "effective_library_sha256": _sha(result), "effective_library_file_sha256": _artifact(path)["sha256"],
               "full_MOS_scope_prepared": True, "full_MOS_scope_verified": False,
               "generator_electrical_identity_preserved": True, "runtime_hit_count": None}
    return {"compiled_primitive_broadcast": receipt, "requested_values": decoded["requested_values"],
            "requested_all_values": decoded["requested_values"], "effective_values": effective, "effective_all_values": effective,
            "request_write_count": {slot: len(effective[slot]) for slot in active_slots},
            "consumer_status_all": {slot: "prepared_requires_primitive_readback" for slot in active_slots},
            "consumer_evidence_kind_primitive": "Generator_parameters_writes_not_runtime_hits"}


def readback_compiled_primitives(
    trace: Mapping[str, Any], campaign: Mapping[str, Any] | str | Path, workdir: str | Path, *,
    native_receipts: Mapping[str, Mapping[str, Any]] | None = None,
    primitive_checks: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Verify generated args/geometry, with optional real uc m2-track evidence.

    native_receipts is keyed by concrete name and requires primitive identity,
    m2_tracks and provenance. Geometry height is an inference, not a constructor
    call count. primitive_checks may provide completed opens/shorts/DRC/LVS
    evidence; missing checks never become successful signoff by file presence.
    """
    frozen, work = load_primitive_campaign(campaign), Path(workdir)
    request = trace.get("compiled_primitive_broadcast", trace)
    if request.get("campaign_sha256") != frozen["campaign_sha256"]:
        raise ContractError("primitive trace belongs to a different frozen campaign")
    expected = decode_primitive_values(frozen, request["requested_values"], active_slots=request["active_slots"])
    generation_checks = None
    if "G04" in request["active_slots"] and primitive_checks is None:
        generation_checks = collect_native_primitive_checks(work.parent)
        primitive_checks = generation_checks.get("checks_by_concrete", {})
    result: dict[str, Any] = {"schema": "shared32-MOS-generator-consumer-readback-v1", "campaign_sha256": frozen["campaign_sha256"],
                              "definitions": {}, "runtime_hit_count": None, "full_MOS_scope_verified": False,
                              "electrical_LVS_signoff": "unobserved"}
    if generation_checks is not None:
        result["generation_check_evidence"] = generation_checks
    library_path, args_path = work / "1_topology/__primitives_library__.json", work / "2_primitives/__primitives__.json"
    try:
        library = json.loads(library_path.read_text())
        arguments = json.loads(args_path.read_text())
        if _sha(library) != request["effective_library_sha256"]:
            raise ContractError("loaded primitive library differs from prepared Generator parameters")
        result["artifacts"] = [_artifact(library_path), _artifact(args_path)]
        for name, decoded in expected["decoded_by_definition"].items():
            definition = frozen["definitions"][name]
            parameters = decoded["generator_parameters"]
            rows = {concrete: row for concrete, row in arguments.items() if row.get("abstract_template_name") == name}
            expected_pairs = parameters["legal_sizes"] if "G02" in decoded["slots"] else [
                {"x": row["x"], "y": row["y"]} for row in definition["baseline_variants"]]
            expected_pairs = {(row["x"], row["y"]) for row in expected_pairs}
            actual_pairs = {(row.get("x_cells"), row.get("y_cells")) for row in rows.values()}
            status = "generated_artifacts_observed" if rows and actual_pairs == expected_pairs else "mismatch"
            variants = []
            effective_height = resolve_height_mapping(parameters, definition["electrical"]["fin"], frozen["pdk_payload"],
                api_height=definition["height_mapping"]["api_height"])["native_baseline_effective_height"]
            for concrete, row in sorted(rows.items()):
                geometry_path = work / "2_primitives" / f"{concrete}.json"
                geometry = json.loads(geometry_path.read_text())
                bbox = geometry["bbox"]
                inferred_height = Fraction(bbox[3] - bbox[1], (row["y_cells"] + definition["body"]) * definition["height_mapping"]["fin_pitch"])
                dispatch = {k: v for k, v in row.items() if k not in {
                    "x_cells", "y_cells", "abstract_template_name", "concrete_template_name"}}
                electrical_matches = dispatch == definition["baseline_variants"][0]["electrical_dispatch_arguments"]
                matches = inferred_height == effective_height and electrical_matches
                expected_width = None
                width_matches = None
                if "G04" in decoded["slots"]:
                    expected_width = _source_width(row["x_cells"], definition["electrical"], parameters["shared_diff"], definition["width_mapping"])
                    width_matches = bbox[2] - bbox[0] == expected_width
                    matches = matches and width_matches
                native = (native_receipts or {}).get(concrete, {})
                native_height = None
                native_status = "unobserved"
                if native:
                    if (native.get("primitive") != name or native.get("block_name") != concrete
                            or native.get("status") != "observed" or not native.get("provenance")
                            or not isinstance(native.get("m2_tracks"), int) or isinstance(native.get("m2_tracks"), bool)):
                        native_status = "invalid_native_evidence"
                        matches = False
                    else:
                        native_height = Fraction(native["m2_tracks"] * definition["height_mapping"]["m2_pitch"], definition["height_mapping"]["fin_pitch"])
                        native_status = "observed_native_generator_grid" if native_height == effective_height else "mismatch"
                        matches = matches and native_height == effective_height
                check = (primitive_checks or {}).get(concrete, {})
                checks_pass = (check.get("status") == "completed" and bool(check.get("provenance"))
                               and all(check.get(key) == 0 for key in ("opens", "shorts", "drc_errors")))
                checks_pass = checks_pass or (check.get("native_checks_status") == "completed_no_reported_errors"
                    and check.get("count_evidence_kind") == "source_inferred_from_complete_ERROR_level_phase_logs"
                    and check.get("all_primitive_generation_completed") is True and bool(check.get("provenance")))
                variants.append({"concrete_name": concrete, "actual_x_cells": row["x_cells"], "actual_y_cells": row["y_cells"],
                    "source_inferred_actual_array_x": row["x_cells"] * definition["electrical"]["device_count"],
                    "geometry": _artifact(geometry_path), "bbox": bbox, "geometry_inferred_height": float(inferred_height),
                    "expected_effective_height": effective_height, "height_geometry_matches": inferred_height == effective_height,
                    "electrical_dispatch_arguments_match": electrical_matches,
                    "shared_diff_source_expected_width": expected_width, "shared_diff_width_geometry_matches": width_matches,
                    "native_height_status": native_status, "native_height": float(native_height) if native_height is not None else None,
                    "source_inferred_pattern": _pattern(parameters, definition["electrical"], row["x_cells"]),
                    "source_inferred_shared_diff": parameters.get("shared_diff", 1 if definition["electrical"]["device_count"] == 1 or definition["electrical"]["common_source_pair"] else 0),
                    "primitive_checks": copy.deepcopy(check) if check else {"status": "unobserved"},
                    "primitive_checks_passed": checks_pass, "runtime_hit_count": None})
                if not matches:
                    status = "mismatch"
            result["definitions"][name] = {"status": status, "slots": decoded["slots"], "variants": variants,
                "generated_pair_set_matches": actual_pairs == expected_pairs,
                "primitive_validation": "passed" if variants and all(row["primitive_checks_passed"] for row in variants) else "unobserved_or_failed"}
        good = bool(result["definitions"]) and all(row["status"] == "generated_artifacts_observed" for row in result["definitions"].values())
        result["status"] = "generated_artifacts_observed" if good else "mismatch"
        result["full_MOS_scope_verified"] = good
        result["consumer_status"] = {slot: result["status"] for slot in request["active_slots"]}
        if "G03" in request["active_slots"] and good:
            result["consumer_status"]["G03"] = "source_inferred_requires_arrangement_readback"
        if "G04" in request["active_slots"]:
            result["G04_consumer_evidence"] = {"kind": "actual_generated_bbox_width_and_preserved_native_electrical_dispatch",
                "status": "observed_artifacts" if good else "mismatch", "standalone_LVS": "unobserved",
                "native_checker_evidence": "source_grounded_phase_log_inference" if generation_checks else "supplied_or_unobserved"}
        arrangement = bool(set(request["active_slots"]) & {"G03", "G04"})
        result["eligible_for_primitive_stage_admission"] = good and (not arrangement or all(
            row["primitive_validation"] == "passed" for row in result["definitions"].values()))
        result["primitive_admission_basis"] = ("generated_shapes_and_preserved_native_electrical_dispatch_for_geometry_inference"
            if not arrangement else "arrangement_or_sharing_requires_actual_native_opens_shorts_DRC_evidence")
        result["shared32_admission"] = "other_full_run_gates_required"
        result["evidence_limits"] = {"G01": "actual bbox/grid height inference; supplied native m2_tracks if present",
            "G02": "actual generated x/y variant inventory; no runtime call count",
            "G03": "loaded Generator.pattern plus source-inferred arrangement; direct native pattern unobserved",
            "G04": "loaded Generator.shared_diff plus source-derived bbox width match; direct native shared_diff unobserved"}
        if result["definitions"] and all(v["primitive_checks_passed"] and v["primitive_checks"].get("electrical_LVS") == "passed"
            for d in result["definitions"].values() for v in d["variants"]):
            result["electrical_LVS_signoff"] = "supplied_primitive_evidence_passed_other_run_gates_required"
    except (OSError, ValueError, ContractError, KeyError, TypeError, AttributeError, ZeroDivisionError) as exc:
        result.update(status="mismatch" if isinstance(exc, ContractError) else "unobserved", reason=str(exc), eligible_for_primitive_stage_admission=False)
    return result


def collect_native_primitive_checks(run_dir: str | Path) -> dict[str, Any]:
    """Infer completed native check execution from real sources and phase logs.

    Native primitive generation runs connectivity and DRC but does not assert
    their counters are zero. Nonzero checks unconditionally emit ERROR records.
    A complete primitive registry and subsequent PnR marker bound the generation
    phase. Quiet logs under the verified code/configuration support a zero-error
    inference, not direct counter observation or standalone LVS.
    """
    run = Path(run_dir)
    result: dict[str, Any] = {"schema": "shared32-native-primitive-check-log-evidence-v1",
        "status": "unobserved", "checks_by_concrete": {}, "native_counts_observed": False,
        "standalone_LVS": "unobserved", "runtime_hit_count": None}
    try:
        # The runner performs this readback after physical completion, before
        # writing its final run_manifest. The phase manifest is already durable
        # then and is the direct command/return-code evidence for generation.
        phase_path, final_path = run / "phase_manifest.json", run / "run_manifest.json"
        runtime_path = run / "runtime_receipt.json"
        runtime = json.loads(runtime_path.read_text())
        if phase_path.is_file():
            manifest_path = phase_path
            records = json.loads(phase_path.read_text())
            if not isinstance(records, list) or any(not isinstance(row, dict) for row in records):
                raise ContractError("phase manifest must contain explicit phase records")
            manifest = {"phase_records": records}
        else:
            manifest_path = final_path
            manifest = json.loads(final_path.read_text())
            if manifest.get("returncode") is None:
                raise ContractError("completed log capture required; overall routing may have failed later")
        phases = [row for row in manifest.get("phase_records", []) if row.get("phase") == "physical"]
        if len(phases) > 1:
            raise ContractError("ambiguous primitive-generating physical phase")
        if phase_path.is_file() and (len(phases) != 1 or type(phases[0].get("returncode")) is not int):
            raise ContractError("completed physical phase log capture required; final run manifest is optional")
        command = phases[0]["command"] if phases else manifest["command"]
        start = next((command[i + 1] for i, value in enumerate(command[:-1]) if value == "--flow_start"), "1_topology")
        if start not in {"1_topology", "2_primitives"}:
            raise ContractError("command does not execute primitive generation")
        verbosity = next((command[i + 1] for i, value in enumerate(command[:-1]) if value in {"-v", "--verbosity"}), "INFO")
        if verbosity not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
            raise ContractError("console configuration can suppress native checker ERROR records")
        init = Path(runtime["module_paths"]["align"])
        if _artifact(init)["sha256"] != runtime["sha256"]["align"]:
            raise ContractError("recorded ALIGN package identity changed")
        actual_root, canonical_root = init.parent, Path(__file__).resolve().parents[3] / "ALIGN-public/align"
        requirements = {
            "primitive/main.py": {"generate_primitives", "generate_primitive"},
            "cell_fabric/canvas.py": {"gen_data", "writeJSON", "removeDuplicates"},
            "cell_fabric/drc.py": {"run"},
            "cell_fabric/remove_duplicates.py": {"remove_duplicates", "check_opens"},
        }
        artifacts = [_artifact(manifest_path), _artifact(runtime_path), _artifact(init), _artifact(Path(__file__))]
        for relative, functions in requirements.items():
            actual, canonical = actual_root / relative, canonical_root / relative
            def methods(path: Path) -> dict[str, str]:
                return {node.name: ast.dump(node, include_attributes=False) for node in ast.walk(ast.parse(path.read_text()))
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in functions}
            if methods(actual) != methods(canonical) or set(methods(actual)) != functions:
                raise ContractError(f"native checker execution/reporting source changed: {relative}")
            artifacts.append(_artifact(actual))
        logging_config = actual_root / "config/logging.ini"
        if logging_config.read_bytes() != (canonical_root / "config/logging.ini").read_bytes():
            raise ContractError("native logging configuration differs from audited ERROR-reporting configuration")
        artifacts.append(_artifact(logging_config))
        stdout_path = run / ("physical.stdout.log" if phases else "stdout.log")
        stderr_path = run / ("physical.stderr.log" if phases else "stderr.log")
        lines = stdout_path.read_text(errors="replace").splitlines()
        boundary = next((i for i, line in enumerate(lines) if "align.pnr.main" in line and "Running Place & Route for " in line), None)
        if boundary is None:
            raise ContractError("post-generation PnR boundary absent; complete phase interval unobserved")
        # ERROR summaries are emitted through the verified stdout handler.
        # Capture stderr too as provenance; subsequent PnR failures do not turn
        # earlier successfully completed primitive generation into an assertion.
        stderr_path.read_bytes()
        diagnostics = []
        for i, line in enumerate(lines[:boundary], 1):
            if ("align.cell_fabric.remove_duplicates" in line or "align.cell_fabric.drc" in line) and "Found errors:" in line:
                diagnostics.append({"line": i, "text": line})
            elif " ERROR " in line or "AssertionError" in line or "Traceback (most recent call last)" in line:
                diagnostics.append({"line": i, "text": line, "classification": "other_primitive_phase_error"})
        command_work = next((command[i + 1] for i, value in enumerate(command[:-1]) if value in {"-w", "--working_dir"}), None)
        work = Path(command_work or manifest.get("align_workdir", run / "align_workdir"))
        registry_path = work / "2_primitives/__primitives__.json"
        registry = json.loads(registry_path.read_text())
        if not registry:
            raise ContractError("completed primitive registry empty")
        artifacts.extend(_artifact(path) for path in (stdout_path, stderr_path, registry_path))
        for concrete in registry:
            for extension in ("json", "lef", "gds.json"):
                path = work / "2_primitives" / f"{concrete}.{extension}"
                if not path.is_file():
                    raise ContractError("registry has an incomplete generated geometry/LEF/GDS product")
        provenance = {"artifacts": artifacts, "primitive_interval_stdout_end_line": boundary,
            "completion_boundary": lines[boundary], "generating_command": command,
            "completion_manifest_kind": "completed_physical_phase" if manifest_path == phase_path else "terminal_run",
            "physical_phase_returncode": phases[0].get("returncode") if phases else manifest.get("returncode"),
            "actual_counter_values": "unobserved", "source_logic": "default writeJSON executes connectivity/DRC; nonzero results log ERROR before return; registry dump follows all returns"}
        result.update(status="completed_no_reported_errors" if not diagnostics else "reported_native_check_errors",
            diagnostics=diagnostics, provenance=provenance, generated_concrete_count=len(registry),
            error_attribution="entire_primitive_phase; diagnostic logger lacks per-primitive identity")
        result["checks_by_concrete"] = {name: {"native_checks_status": result["status"],
            "count_evidence_kind": "source_inferred_from_complete_ERROR_level_phase_logs",
            "all_primitive_generation_completed": True, "native_counts_observed": False,
            "opens": None, "shorts": None, "drc_errors": None, "electrical_LVS": "unobserved", "provenance": provenance}
            for name in registry}
    except (OSError, ValueError, KeyError, TypeError, ContractError) as exc:
        result["reason"] = str(exc)
    return result
