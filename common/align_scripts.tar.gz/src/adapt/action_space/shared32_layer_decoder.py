"""Frozen conditional signal/power layer-window decoding for shared32 M4.

The feasible sets below establish conservative, baseline layer-level structural
conditions only. They do not establish spatial pin access, congestion, routing
success, or capacity for power stripes. No ALIGN process is imported or launched.
"""

from __future__ import annotations

from collections import Counter
import copy
import hashlib
from itertools import product
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from adapt.contracts.common import ContractError


SCHEMA_ID = "shared32-frozen-layer-windows-v1"
Q_VALUES = (0, 0.5, 1)
QUANTILE_RULE = "index=floor(q*(count-1)+0.5); sorted unique native indices"
_SLOTS = {"signal": ("R01", "R02"), "power": ("W03", "W04", "W05", "W06")}
_FIELDS = {"signal": ("min_layer", "max_layer"),
           "power": ("bottom_power_grid_layer", "top_power_grid_layer",
                     "bottom_power_routing_layer", "top_power_routing_layer")}
_SOURCE_PATHS = [
    "docs/ALIGN_32_PARAMETERS_SHAPE_AND_FULL_DESIGN_DIMENSIONS_20260908.md:M4",
    "ALIGN-public/PlaceRouteHierFlow/PnRDB/ReadDesignRuleJson.cpp:31-133",
    "ALIGN-public/PlaceRouteHierFlow/router/GlobalGrid.cpp:136",
    "ALIGN-public/PlaceRouteHierFlow/router/Grid.cpp:1000-1073",
    "ALIGN-public/PlaceRouteHierFlow/router/GcellGlobalRouter.cpp:492-508,1066-1087",
    "ALIGN-public/PlaceRouteHierFlow/router/GcellDetailRouter.cpp:1028-1037",
    "ALIGN-public/PlaceRouteHierFlow/router/PowerRouter.cpp:683-706,973-979",
]


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _integer(value: Any, field: str, *, positive: bool = True) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or int(value) != value:
        raise ContractError(f"{field} must be an integer")
    if value < (1 if positive else 0):
        raise ContractError(f"{field} has invalid sign")
    return int(value)


def _resources(pdk: Mapping[str, Any]) -> dict[str, Any]:
    scale = _integer(pdk.get("ScaleFactor"), "ScaleFactor")
    abstraction = pdk.get("Abstraction")
    if not isinstance(abstraction, list):
        raise ContractError("PDK Abstraction is missing")
    metals = []
    for item in abstraction:
        if not isinstance(item, Mapping) or not str(item.get("Layer", "")).startswith("M"):
            continue
        name = item["Layer"]
        if not isinstance(name, str) or name in [x["name"] for x in metals]:
            raise ContractError("PDK metal names must be unique strings")
        if item.get("Direction") not in {"V", "H"}:
            raise ContractError(f"metal {name} has no native H/V direction")
        pitch = 2 * _integer(item.get("Pitch"), f"{name}.Pitch") // scale
        width = 2 * _integer(item.get("Width"), f"{name}.Width") // scale
        metals.append({"name": name, "index": len(metals), "direction": item["Direction"],
                       "pitch_native": pitch, "width_native": width})
    if len(metals) < 2:
        raise ContractError("native routers require at least two metal layers")
    indices = {m["name"]: m["index"] for m in metals}
    vias: dict[tuple[int, int], list[str]] = {}
    for item in abstraction:
        if not isinstance(item, Mapping) or not str(item.get("Layer", "")).startswith("V"):
            continue
        stack = item.get("Stack")
        if not isinstance(stack, list) or len(stack) != 2 or any(x not in indices for x in stack):
            continue  # Contacts (e.g. V0) are not intermetal resources.
        lower, upper = (indices[x] for x in stack)
        if upper != lower + 1:
            continue
        try:
            wx = 2 * _integer(item.get("WidthX"), f"{item['Layer']}.WidthX") // scale
            wy = 2 * _integer(item.get("WidthY"), f"{item['Layer']}.WidthY") // scale
        except ContractError:
            continue
        if wx > 0 and wy > 0:
            vias.setdefault((lower, upper), []).append(item["Layer"])
    return {"metals": metals, "indices": indices, "vias": vias, "scale_factor": scale}


def _envelope(resources: Mapping[str, Any], names: Sequence[str]) -> tuple[int, int]:
    if isinstance(names, (str, bytes)) or not names:
        raise ContractError("an explicit nonempty allowed layer sequence is required")
    indices = resources["indices"]
    if any(name not in indices for name in names):
        raise ContractError("allowed layer absent from native Metalmap")
    ordered = sorted({indices[name] for name in names})
    if len(ordered) != len(names) or ordered != list(range(ordered[0], ordered[-1] + 1)):
        raise ContractError("allowed resources must be unique and a continuous native layer interval")
    return ordered[0], ordered[-1]


def _default_envelope(pdk: Mapping[str, Any], resources: Mapping[str, Any], low: str, high: str) -> tuple[int, int]:
    info = pdk.get("design_info", {})
    indices = resources["indices"]
    if info.get(low) not in indices or info.get(high) not in indices:
        raise ContractError(f"explicit PDK design_info {low}/{high} required; no native fallback inferred")
    bounds = indices[info[low]], indices[info[high]]
    if bounds[0] > bounds[1]:
        raise ContractError("PDK default bounds are reversed")
    return bounds


def _grid_reasons(resources: Mapping[str, Any], lower: int, upper: int) -> set[str]:
    metals = resources["metals"]
    reasons = set()
    if not 0 <= lower < upper < len(metals):
        return {"requires_at_least_two_ordered_layers"}
    for index in range(lower, upper + 1):
        metal = metals[index]
        if metal["pitch_native"] <= 0 or metal["width_native"] <= 0:
            reasons.add("nonpositive_native_metal_pitch_or_width")
        # Grid.cpp reads existing neighbors in the full PDK, even outside bounds.
        for neighbor in (index - 1, index + 1):
            if 0 <= neighbor < len(metals):
                if metals[neighbor]["direction"] == metal["direction"]:
                    reasons.add("native_grid_neighbor_direction_not_orthogonal")
                if metals[neighbor]["pitch_native"] <= 0:
                    reasons.add("native_grid_neighbor_pitch_not_positive")
        if index < upper and (index, index + 1) not in resources["vias"]:
            reasons.add("missing_positive_adjacent_via_stack")
    return reasons


def _pin_layers(pin_access: Mapping[str, Any] | None, resources: Mapping[str, Any], scope: str) -> list[int]:
    if not isinstance(pin_access, Mapping) or pin_access.get("complete") is not True:
        raise ContractError("complete baseline pin-layer evidence is required")
    if pin_access.get("module_name") != scope:
        raise ContractError("pin-layer evidence scope does not match requested module")
    if not pin_access.get("provenance"):
        raise ContractError("pin-layer evidence requires provenance")
    names = pin_access.get("pin_layers")
    if not isinstance(names, list) or not names:
        raise ContractError("nonempty necessary pin-layer inventory is required")
    indices = resources["indices"]
    if any(name not in indices for name in names):
        raise ContractError("necessary pin layer is absent from native Metalmap")
    return sorted({indices[name] for name in names})


def _blocked(kind: str, scope: str, reason: str, provenance: Mapping[str, Any] | None) -> dict[str, Any]:
    return {"schema": SCHEMA_ID, "kind": kind, "module_name": scope,
            "status": "blocked_decoder", "blockers": [reason], "tuples": [],
            "full_routing_feasibility": "unobserved", "provenance": copy.deepcopy(provenance or {})}


def _selection(tuples: Sequence[Sequence[int]], q_values: Sequence[float]) -> tuple[list[int], list[dict[str, Any]]]:
    candidates = list(tuples)
    selected, steps = [], []
    for coordinate, q in enumerate(q_values):
        available = sorted({row[coordinate] for row in candidates})
        # For the frozen q set, the only tie is q=.5; integer arithmetic is exact.
        index = 0 if q == 0 else len(available) - 1 if q == 1 else len(available) // 2
        value = available[index]
        q_outputs = [available[0], available[len(available) // 2], available[-1]]
        steps.append({"coordinate": coordinate, "q": q, "candidate_indices": available,
                      "candidate_count": len(available), "selected_index_in_candidates": index,
                      "selected_native_index": value, "q_grid_outputs": q_outputs,
                      "effective_level_count_for_prefix": len(set(q_outputs))})
        selected.append(value)
        candidates = [row for row in candidates if row[coordinate] == value]
    return selected, steps


def _finish(kind: str, scope: str, resources: Mapping[str, Any], tuples: list[list[int]],
            rejected: Counter, candidate_count: int, context: Mapping[str, Any]) -> dict[str, Any]:
    body = {"schema": SCHEMA_ID, "kind": kind, "module_name": scope,
            "ordered_layers": [x["name"] for x in resources["metals"]],
            "metal_resources": resources["metals"],
            "via_resources": [{"native_indices": list(pair), "vias": names} for pair, names in sorted(resources["vias"].items())],
            "tuples": tuples, "slots": list(_SLOTS[kind]), "raw_fields": list(_FIELDS[kind]),
            "quantile_rule": QUANTILE_RULE, "q_domain": list(Q_VALUES), "context": copy.deepcopy(context)}
    decoded = [_selection(tuples, q)[0] for q in product(Q_VALUES, repeat=len(_SLOTS[kind]))] if tuples else []
    return {**body, "frozen_sha256": _hash(body),
            "status": "ready_static" if tuples else "infeasible_static",
            "blockers": [] if tuples else ["no_window_satisfies_frozen_structural_conditions"],
            "candidate_tuple_count": candidate_count, "feasible_tuple_count": len(tuples),
            "q_tuple_count": len(decoded), "effective_decoded_tuple_count": len({tuple(x) for x in decoded}),
            "count_evidence": "static_enumeration_of_frozen_q_domain_not_runtime_hits",
            "rejected_reason_counts": dict(sorted(rejected.items())),
            "full_routing_feasibility": "unobserved", "spatial_pin_access": "unobserved",
            "actual_pin_recheck_required": True, "source_consumer_paths": _SOURCE_PATHS,
            "limitations": ["Baseline layer containment is conservative, not proof of spatial access or successful routing.",
                            "After primitive/hierarchy changes, recheck actual pin layers against this frozen set; do not rebuild it from the action.",
                            "Native routers can extend windows to pin layers; actual consumed bounds require runtime readback.",
                            "Power stripe capacity and full geometry/DRC/connectivity remain run-time gates."]}


def build_signal_layer_windows(
    pdk: Mapping[str, Any], *, module_name: str,
    constraints: Sequence[Mapping[str, Any]], pin_access: Mapping[str, Any] | None,
    allowed_layers: Sequence[str] | None = None, resource_policy: str | None = None,
    provenance: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Freeze F_signal,m from explicit resources, hard Route bounds and pins.

    ``resource_policy='design_info_bounds_and_hard_route'`` explicitly adopts
    the PDK signal default interval as this campaign's conservative envelope.
    Otherwise pass ``allowed_layers``; missing policy/resources are blocked.
    All supplied Route entries are treated as hard bounds (intersection).
    Nonempty Route.customize is blocked because the audited native max-layer
    override uses max rather than a safe intersection. Pin evidence requires
    ``module_name, complete=True, pin_layers=[...], provenance``.
    """
    try:
        resources = _resources(pdk)
        pins = _pin_layers(pin_access, resources, module_name)
        if resource_policy == "design_info_bounds_and_hard_route":
            lower, upper = _default_envelope(pdk, resources, "bottom_signal_routing_layer", "top_signal_routing_layer")
            if allowed_layers is not None:
                lo, hi = _envelope(resources, allowed_layers)
                lower, upper = max(lower, lo), min(upper, hi)
        elif resource_policy in (None, "explicit") and allowed_layers is not None:
            lower, upper = _envelope(resources, allowed_layers)
        else:
            raise ContractError("explicit allowed_layers or supported resource_policy required")
        hard_routes = []
        for constraint in constraints:
            if constraint.get("constraint", constraint.get("const_name")) != "Route":
                continue
            if constraint.get("customize"):
                raise ContractError("Route.customize blocked: native max(global_max,custom_max) semantics require a separate audited policy")
            hard_routes.append(dict(constraint))
            for field in ("min_layer", "max_layer"):
                value = constraint.get(field)
                if value is None:
                    continue
                if value not in resources["indices"]:
                    raise ContractError(f"hard Route {field} absent from Metalmap")
                bound = resources["indices"][value]
                if field == "min_layer":
                    lower = max(lower, bound)
                else:
                    upper = min(upper, bound)
    except (ContractError, KeyError, TypeError, AttributeError) as exc:
        return _blocked("signal", module_name, str(exc), provenance)
    tuples, rejected, count = [], Counter(), 0
    for low in range(lower, upper + 1):
        for high in range(low + 1, upper + 1):
            count += 1
            reasons = _grid_reasons(resources, low, high)
            if pins[0] < low or pins[-1] > high:
                reasons.add("baseline_pin_layers_outside_window")
            if reasons:
                rejected.update(reasons)
            else:
                tuples.append([low, high])
    context = {"pdk_sha256": _hash(pdk), "resource_policy": resource_policy or "explicit",
               "allowed_layers": list(allowed_layers) if allowed_layers is not None else None,
               "resolved_resource_bounds": [lower, upper], "hard_route_constraints": hard_routes,
               "pin_access": pin_access, "provenance": provenance or {}}
    return _finish("signal", module_name, resources, tuples, rejected, count, context)


def build_power_layer_windows(
    pdk: Mapping[str, Any], *, top: str, pin_access: Mapping[str, Any] | None,
    power_evidence: Mapping[str, Any] | None,
    grid_allowed_layers: Sequence[str] | None = None,
    routing_allowed_layers: Sequence[str] | None = None,
    resource_policy: str | None = None, provenance: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Freeze top-level F_power for an explicitly identified ordinary PDN.

    Supply complete evidence with ``power_profile='explicit_pdn'``,
    ``ordinary_power_flow=True``, exactly one ``power_ports`` and one
    ``ground_ports`` identity, and provenance. PDN simulation mode is excluded
    because that Python branch overwrites grid bounds with indices 4 and 5.
    Explicit allowed resources carry any design hard power limits; alternatively
    ``resource_policy='design_info_bounds'`` freezes the PDK default envelopes.
    """
    try:
        resources = _resources(pdk)
        pins = _pin_layers(pin_access, resources, top)
        evidence = power_evidence or {}
        if (evidence.get("complete") is not True or evidence.get("power_profile") != "explicit_pdn"
                or evidence.get("ordinary_power_flow") is not True or not evidence.get("provenance")):
            raise ContractError("complete explicit-PDN ordinary-flow identity evidence required")
        power, ground = evidence.get("power_ports"), evidence.get("ground_ports")
        if (not isinstance(power, list) or not isinstance(ground, list) or len(power) != 1 or len(ground) != 1
                or not isinstance(power[0], str) or not isinstance(ground[0], str)
                or not power[0] or not ground[0] or power[0] == ground[0]):
            raise ContractError("one distinct identified power/ground pair required; multiple domains unsupported")
        bounds = []
        for names, low, high in ((grid_allowed_layers, "bottom_power_grid_layer", "top_power_grid_layer"),
                                 (routing_allowed_layers, "bottom_power_routing_layer", "top_power_routing_layer")):
            if resource_policy == "design_info_bounds":
                lower, upper = _default_envelope(pdk, resources, low, high)
                if names is not None:
                    lo, hi = _envelope(resources, names)
                    lower, upper = max(lower, lo), min(upper, hi)
            elif resource_policy in (None, "explicit") and names is not None:
                lower, upper = _envelope(resources, names)
            else:
                raise ContractError("explicit grid/routing resources or design_info_bounds policy required")
            bounds.append((lower, upper))
    except (ContractError, KeyError, TypeError, AttributeError) as exc:
        return _blocked("power", top, str(exc), provenance)
    tuples, rejected, count = [], Counter(), 0
    (grid_low, grid_high), (route_low, route_high) = bounds
    for gl in range(grid_low, grid_high + 1):
        for gu in range(gl + 1, grid_high + 1):
            for rl in range(route_low, min(gl, route_high) + 1):
                for ru in range(max(gu, route_low), route_high + 1):
                    count += 1
                    reasons = _grid_reasons(resources, gl, gu) | _grid_reasons(resources, rl, ru)
                    if pins[0] < rl or pins[-1] > ru:
                        reasons.add("baseline_power_pin_layers_outside_hookup_window")
                    # Both grid sizing and hookup margins use highest and highest-1.
                    for high in (gu, ru):
                        if high < 1 or resources["metals"][high]["direction"] == resources["metals"][high - 1]["direction"]:
                            reasons.add("power_highest_predecessor_direction_or_index_invalid")
                    if reasons:
                        rejected.update(reasons)
                    else:
                        tuples.append([gl, gu, rl, ru])
    context = {"pdk_sha256": _hash(pdk), "resource_policy": resource_policy or "explicit",
               "resolved_resource_bounds": [list(x) for x in bounds], "pin_access": pin_access,
               "power_evidence": power_evidence, "provenance": provenance or {}}
    return _finish("power", top, resources, tuples, rejected, count, context)


def decode_layer_window(frozen: Mapping[str, Any], q_values: Mapping[str, Any] | Sequence[Any]) -> dict[str, Any]:
    """Decode independent frozen q coordinates; no q_low<=q_high restriction.

    The frozen artifact is integrity-checked and never rebuilt by this function.
    In particular signal q=(1,0) can select a legal low<high tuple.
    """
    if frozen.get("schema") != SCHEMA_ID or frozen.get("status") != "ready_static":
        raise ContractError("cannot decode a blocked or empty frozen layer-window set")
    keys = ("schema", "kind", "module_name", "ordered_layers", "metal_resources", "via_resources", "tuples", "slots", "raw_fields", "quantile_rule", "q_domain", "context")
    if _hash({key: frozen.get(key) for key in keys}) != frozen.get("frozen_sha256"):
        raise ContractError("frozen layer-window set hash mismatch")
    slots = _SLOTS[frozen["kind"]]
    if isinstance(q_values, Mapping):
        if any(slot not in q_values for slot in slots):
            raise ContractError("all conditional q coordinates are required")
        values = [q_values[slot] for slot in slots]
    elif isinstance(q_values, Sequence) and not isinstance(q_values, (str, bytes)):
        values = list(q_values)
    else:
        raise ContractError("q_values must be a coordinate mapping or sequence")
    if len(values) != len(slots) or any(isinstance(q, bool) or not isinstance(q, (int, float)) or q not in Q_VALUES for q in values):
        raise ContractError("each conditional q must be exactly one of {0,0.5,1}")
    selected, steps = _selection(frozen["tuples"], values)
    names = [frozen["ordered_layers"][index] for index in selected]
    for slot, step in zip(slots, steps):
        step["slot"] = slot
        step["candidate_layers"] = [frozen["ordered_layers"][index] for index in step["candidate_indices"]]
    return {"schema": "shared32-layer-decode-receipt-v1", "status": "decoded_static",
            "kind": frozen["kind"], "module_name": frozen["module_name"],
            "requested_q": dict(zip(slots, values)), "raw_tuple": names,
            "native_index_tuple": selected, "raw_values": dict(zip(frozen["raw_fields"], names)),
            "slot_raw_values": dict(zip(slots, names)), "conditional_steps": steps,
            "frozen_sha256": frozen["frozen_sha256"], "effective_level_id": _hash(names),
            "feasible_tuple_count": frozen["feasible_tuple_count"],
            "q_tuple_count": frozen["q_tuple_count"],
            "effective_decoded_tuple_count": frozen["effective_decoded_tuple_count"],
            "quantile_rule": QUANTILE_RULE, "full_routing_feasibility": "unobserved",
            "actual_pin_recheck_required": True, "runtime_hit_count": None}


def validate_actual_pin_layers(frozen: Mapping[str, Any], decoded: Mapping[str, Any],
                               pin_access: Mapping[str, Any]) -> dict[str, Any]:
    """Recheck action-generated pin layers without modifying the baseline F."""
    if decoded.get("frozen_sha256") != frozen.get("frozen_sha256"):
        raise ContractError("decode receipt belongs to a different frozen set")
    expected = decode_layer_window(frozen, decoded.get("requested_q", {}))
    if expected["native_index_tuple"] != decoded.get("native_index_tuple"):
        raise ContractError("decode receipt tuple mismatch")
    resources = {"indices": {name: index for index, name in enumerate(frozen["ordered_layers"])}}
    try:
        pins = _pin_layers(pin_access, resources, frozen["module_name"])
    except ContractError as exc:
        return {"status": "blocked_pin_evidence", "reason": str(exc), "frozen_sha256": frozen["frozen_sha256"]}
    low, high = decoded["native_index_tuple"][-2:]
    fits = low <= pins[0] and pins[-1] <= high
    return {"status": "passed_layer_containment" if fits else "infeasible_pin_layers",
            "required_pin_indices": pins, "window_indices": [low, high],
            "frozen_sha256": frozen["frozen_sha256"], "full_routing_feasibility": "unobserved",
            "pin_access_sha256": _hash(pin_access)}


def validate_reference_layer_window(
    frozen: Mapping[str, Any], reference_values: Mapping[str, Any] | Sequence[str],
    q_values: Mapping[str, Any] | Sequence[Any],
) -> dict[str, Any]:
    """Require reference q to reproduce the actual untouched native background.

    A legal but different decoded tuple needs a newly registered baseline; it is
    not evidence that an old native background can be reused. Pass all native
    field names (``min_layer,max_layer`` or the four power fields), or a tuple.
    """
    decoded = decode_layer_window(frozen, q_values)
    if isinstance(reference_values, Mapping):
        values = [reference_values.get(field) for field in frozen["raw_fields"]]
    elif isinstance(reference_values, Sequence) and not isinstance(reference_values, (str, bytes)):
        values = list(reference_values)
    else:
        values = []
    indices = {name: index for index, name in enumerate(frozen["ordered_layers"])}
    valid = len(values) == len(frozen["slots"]) and all(isinstance(x, str) and x in indices for x in values)
    native = [indices[x] for x in values] if valid else []
    feasible = bool(valid and native in frozen["tuples"])
    matched = feasible and values == decoded["raw_tuple"]
    return {"status": "matched_reference" if matched else "blocked_reference",
            "reference_raw_tuple": values, "decoded_raw_tuple": decoded["raw_tuple"],
            "reference_tuple_in_frozen_set": feasible,
            "reason": None if matched else "native_reference_fields_missing_or_unknown" if not valid
            else "native_reference_outside_frozen_set" if not feasible else "reference_q_decodes_different_native_background",
            "frozen_sha256": frozen["frozen_sha256"], "full_routing_feasibility": "unobserved",
            "other_baseline_reuse_identity_gates": "not_checked_by_layer_reference_comparison"}


def _lef_pin_layers(contents: str, macro: str) -> dict[str, set[str]]:
    """Read the emitted ALIGN LEF PIN/PORT/RECT dialect, rejecting unknown shapes."""
    pins: dict[str, set[str]] = {}
    pin, layer, in_port, macro_seen, macro_closed = None, None, False, False, False
    for line in contents.splitlines():
        words = line.split()
        if not words or words[0].startswith("#"):
            continue
        token = words[0]
        if token == "MACRO":
            if macro_seen or len(words) != 2 or words[1] != macro:
                raise ContractError("LEF must contain exactly the expected concrete macro")
            macro_seen = True
        elif token == "PIN":
            if not macro_seen or macro_closed or pin is not None or len(words) != 2 or words[1] in pins:
                raise ContractError("malformed or duplicate LEF PIN")
            pin = words[1]
            pins[pin] = set()
        elif pin is not None:
            if token == "PORT":
                if in_port:
                    raise ContractError("nested LEF PORT")
                in_port, layer = True, None
            elif token == "END":
                if in_port and len(words) == 1:
                    in_port, layer = False, None
                elif not in_port and words == ["END", pin]:
                    pin = None
                else:
                    raise ContractError("malformed LEF PIN/PORT END")
            elif in_port and token == "LAYER":
                if len(words) != 3 or words[-1] != ";":
                    raise ContractError("unsupported LEF pin layer syntax")
                layer = words[1]
            elif in_port and token == "RECT":
                if layer is None or len(words) != 6 or words[-1] != ";":
                    raise ContractError("unsupported LEF pin RECT syntax")
                coords = [float(x) for x in words[1:5]]
                if not all(math.isfinite(x) for x in coords) or coords[0] >= coords[2] or coords[1] >= coords[3]:
                    raise ContractError("nonpositive or nonfinite LEF pin rectangle")
                if layer.startswith("M"):
                    pins[pin].add(layer)
            elif in_port:
                raise ContractError("unsupported LEF pin geometry; explicit evidence required")
        elif words == ["END", macro]:
            macro_closed = True
    if not macro_seen or not macro_closed or pin is not None or in_port:
        raise ContractError("incomplete LEF macro/pin evidence")
    return pins


def collect_baseline_pin_layers(
    workdir: str | Path, top: str, *,
    module_pin_evidence: Mapping[str, Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Inventory compiled instance pin contacts from every baseline variant.

    Returns ``modules[name]`` evidence accepted as ``pin_access`` by the window
    builders. Uses exactly ``1_topology/<top>.verilog.json``, the primitive
    manifest, JSON pin geometry, and the LEF contacts consumed by PnR. All
    generated concrete variants of an abstract primitive are included.

    Hierarchical leaf propagation is only a proxy for a routed child's exported
    interface. To complete a parent scope, supply child evidence keyed by child
    module name, with ``module_name, complete=True, ports={formal: [layers]},
    provenance``. Do not obtain that override by relabeling this function's
    ``port_layer_proxy``. Global rails are not guessed from net-name spelling;
    all connected formal pins are conservatively included. Top terminal pin
    placement and spatial accessibility remain unverified.
    """
    root = Path(workdir)
    artifacts: dict[str, dict[str, str]] = {}

    def read(path: Path, *, as_json: bool = True) -> Any:
        payload = path.read_bytes()
        artifacts[str(path)] = {"path": str(path), "sha256": hashlib.sha256(payload).hexdigest()}
        return json.loads(payload) if as_json else payload.decode()

    sources = ["ALIGN-public/align/pnr/build_pnr_model.py:43-86,167-175",
               "ALIGN-public/align/cell_fabric/gen_lef.py:23-58",
               "ALIGN-public/PlaceRouteHierFlow/PnRDB/ReadLEF.cpp:200-247",
               "ALIGN-public/PlaceRouteHierFlow/PnRDB/PnRdatabase.cpp:850-864,1832"]
    output: dict[str, Any] = {"schema": "shared32-baseline-pin-inventory-v1", "top": top,
                              "modules": {}, "source_consumer_paths": sources,
                              "spatial_pin_access": "unobserved", "runtime_hit_count": None}
    try:
        topology = read(root / "1_topology" / f"{top}.verilog.json")
        modules = {m["name"]: m for m in topology["modules"]}
        if len(modules) != len(topology["modules"]) or top not in modules:
            raise ContractError("compiled module names must be unique and include exact top")
        manifest = read(root / "2_primitives" / "__primitives__.json")
        if not isinstance(manifest, dict):
            raise ContractError("primitive manifest must map concrete template names")
        variants: dict[str, list[str]] = {}
        for concrete, entry in manifest.items():
            if (not isinstance(entry, dict) or entry.get("concrete_template_name") != concrete
                    or not isinstance(entry.get("abstract_template_name"), str)):
                raise ContractError("primitive manifest template identity is incomplete")
            if Path(concrete).name != concrete:
                raise ContractError("primitive template is not a local basename")
            variants.setdefault(entry["abstract_template_name"], []).append(concrete)
        primitive_pins = {}

        def primitive(concrete: str) -> dict[str, set[str]]:
            if concrete in primitive_pins:
                return primitive_pins[concrete]
            geometry = read(root / "2_primitives" / f"{concrete}.json")
            if not isinstance(geometry.get("terminals"), list):
                raise ContractError(f"{concrete}: missing primitive terminal list")
            json_pins: dict[str, set[str]] = {}
            for terminal in geometry["terminals"]:
                if terminal.get("netType") != "pin":
                    continue
                name, layer = terminal.get("netName"), terminal.get("layer")
                if not isinstance(name, str) or not isinstance(layer, str):
                    raise ContractError(f"{concrete}: unnamed pin geometry")
                json_pins.setdefault(name, set())
                if layer.startswith("M"):
                    json_pins[name].add(layer)
            lef_pins = _lef_pin_layers(read(root / "2_primitives" / f"{concrete}.lef", as_json=False), concrete)
            if json_pins != lef_pins:
                raise ContractError(f"{concrete}: JSON pin layers disagree with native LEF contacts")
            primitive_pins[concrete] = lef_pins
            return lef_pins

        def visit(name: str, ancestors: tuple[str, ...] = ()) -> dict[str, Any]:
            if name in ancestors:
                raise ContractError("recursive compiled module cycle: " + "/".join((*ancestors, name)))
            if name in output["modules"]:
                return output["modules"][name]
            module, blockers, endpoints = modules[name], [], []
            layers, proxy = set(), {}
            parameters = module.get("parameters")
            if not isinstance(parameters, list) or any(not isinstance(x, str) for x in parameters):
                raise ContractError(f"{name}: compiled module port identities missing")
            if not isinstance(module.get("instances"), list) or not module["instances"]:
                raise ContractError(f"{name}: nonempty compiled instance list required")
            for instance in module["instances"]:
                instance_name = instance.get("instance_name")
                template = instance.get("template_name", instance.get("abstract_template_name"))
                fa_map = instance.get("fa_map")
                if (not isinstance(instance_name, str) or not isinstance(template, str)
                        or not isinstance(fa_map, list) or not fa_map):
                    raise ContractError(f"{name}: incomplete instance identity or fa_map")
                child = visit(template, (*ancestors, name)) if template in modules else None
                explicit = (module_pin_evidence or {}).get(template, {}) if child else {}
                child_complete = bool(child and explicit.get("module_name") == template
                                      and explicit.get("complete") is True and explicit.get("provenance")
                                      and isinstance(explicit.get("ports"), Mapping))
                concrete_names = sorted(variants.get(template, [])) if child is None else []
                if child is None and not concrete_names:
                    blockers.append(f"{instance_name}: no baseline concrete variants for {template}")
                for fa in fa_map:
                    formal, actual = fa.get("formal"), fa.get("actual")
                    if not isinstance(formal, str) or not formal or not isinstance(actual, str) or not actual:
                        raise ContractError(f"{name}/{instance_name}: invalid formal/actual net identity")
                    pin_layers, evidence_kind = set(), "primitive_LEF_and_JSON_all_baseline_variants"
                    used_variants = []
                    if child is not None:
                        raw = explicit.get("ports", {}).get(formal) if child_complete else None
                        if (child_complete and isinstance(raw, list) and raw
                                and all(isinstance(x, str) and x.startswith("M") for x in raw)):
                            pin_layers.update(raw)
                            evidence_kind = "explicit_routed_child_port_layers"
                        else:
                            pin_layers.update(child["port_layer_proxy"].get(formal, []))
                            evidence_kind = "unverified_recursive_leaf_proxy"
                            blockers.append(f"{instance_name}/{formal}: routed child interface pin layers missing")
                    else:
                        for concrete in concrete_names:
                            try:
                                contacts = primitive(concrete).get(formal)
                                if not contacts:
                                    raise ContractError(f"{concrete}/{formal}: no positive metal pin contacts")
                                pin_layers.update(contacts)
                                used_variants.append(concrete)
                            except (OSError, ValueError, ContractError, TypeError, AttributeError) as exc:
                                blockers.append(f"{instance_name}/{formal}: {exc}")
                    layers.update(pin_layers)
                    if actual in parameters:
                        proxy.setdefault(actual, set()).update(pin_layers)
                    endpoints.append({"instance_name": instance_name, "template_name": template,
                                      "formal": formal, "actual": actual, "canonical_net_id": [name, actual],
                                      "pin_layers": sorted(pin_layers), "evidence_kind": evidence_kind,
                                      "concrete_variants": used_variants})
            if not layers:
                blockers.append("no necessary instance pin-layer evidence")
            result = {"module_name": name, "complete": not blockers,
                      "status": "complete_conservative_layer_inventory" if not blockers else "blocked_pin_evidence",
                      "pin_layers": sorted(layers), "blockers": sorted(set(blockers)),
                      "endpoints": endpoints, "port_layer_proxy": {k: sorted(v) for k, v in sorted(proxy.items())},
                      "evidence_scope": "connected_instance_formal_pins_all_baseline_variants",
                      "spatial_pin_access": "unobserved", "provenance": {"topology_path": str(root / "1_topology" / f"{top}.verilog.json"),
                      "module_pin_evidence": copy.deepcopy(module_pin_evidence or {}),
                      "inventory_method": "compiled_fa_map_and_primitive_LEF_JSON_crosscheck"}}
            output["modules"][name] = result
            return result

        visit(top)
        output["status"] = "complete_conservative_layer_inventory" if all(x["complete"] for x in output["modules"].values()) else "blocked_pin_evidence"
    except (OSError, ValueError, ContractError, KeyError, TypeError, AttributeError) as exc:
        output.update(status="blocked_pin_evidence", blockers=[str(exc)])
    output["artifacts"] = [artifacts[key] for key in sorted(artifacts)]
    for evidence in output["modules"].values():
        evidence["provenance"]["artifacts"] = copy.deepcopy(output["artifacts"])
    output["limitations"] = ["Complete refers to conservative baseline instance pin layers, not spatial access or routing feasibility.",
                             "Exported child interfaces require explicit routed-child port evidence; propagated leaf layers are only a proxy.",
                             "All baseline primitive variants are included; action-generated variants require a separate frozen-window pin recheck.",
                             "Router-generated module terminals and power-net classification are not inferred from terminal names."]
    return output


def collect_routed_child_port_layers(
    workdir: str | Path, pdk: Mapping[str, Any], *, top: str,
    selected_candidate: Mapping[str, Any] | str | Path,
) -> dict[str, Any]:
    """Extract actual exported child pins of an explicitly selected baseline.

    ``selected_candidate`` is the runner's selected_candidate_collection JSON
    path or its payload. Its exact selected top identifies a Results placement;
    only concrete children reachable in that placement are read. Routed LEF
    PIN/PORTs are authoritative: native WriteLef serializes blockPins contacts
    that CheckinChildnodetoBlock copies into parents. Viewer JSON pin tags can
    omit newly routed exported contacts, so they are checked as a subset and
    recorded separately. Named drawing and descendant pin guesses are unused.

    The returned ``module_pin_evidence`` feeds collect_baseline_pin_layers.
    Missing/ambiguous selected identity, absent child LEF, unknown metal, or a
    missing exported formal pin blocks completeness. This does not prove spatial
    accessibility or that future actions preserve baseline interfaces.
    """
    root, artifacts = Path(workdir), {}

    def read(path: Path, *, as_json: bool = True) -> Any:
        payload = path.read_bytes()
        artifacts[str(path)] = {"path": str(path), "sha256": hashlib.sha256(payload).hexdigest()}
        return json.loads(payload) if as_json else payload.decode()

    result: dict[str, Any] = {"schema": "shared32-selected-routed-child-ports-v1", "top": top,
                              "module_pin_evidence": {}, "full_routing_feasibility": "unobserved",
                              "runtime_hit_count": None, "source_consumer_paths": [
                                  "ALIGN-public/align/pnr/router.py:203-237",
                                  "ALIGN-public/PlaceRouteHierFlow/PnRDB/PnRdatabase.cpp:850-864,1041-1072",
                                  "ALIGN-public/align/pnr/checkers.py:48-52,114-151,173-209"]}
    try:
        resources = _resources(pdk)
        selection = read(Path(selected_candidate)) if isinstance(selected_candidate, (str, Path)) else copy.deepcopy(selected_candidate)
        selected_id = selection.get("selected_id")
        if (selection.get("top_name") != top or not isinstance(selected_id, str)
                or Path(selected_id).name != selected_id or not selection.get("selection_policy")):
            raise ContractError("exact selected top identity and selection policy are required")
        rows = [row for row in selection.get("candidates", []) if row.get("candidate_id") == selected_id]
        if (len(rows) != 1 or rows[0].get("postroute_label_eligible") is not True
                or rows[0].get("routed_json") != f"3_pnr/{selected_id}.json"):
            raise ContractError("selected routed candidate must be unique and explicitly identified")
        read(root / "3_pnr" / f"{selected_id}.json")  # Bind to the existing selected routed output.
        topology = read(root / "1_topology" / f"{top}.verilog.json")
        compiled = {module["name"]: module for module in topology["modules"]}
        if len(compiled) != len(topology["modules"]) or top not in compiled:
            raise ContractError("exact compiled top/module identities are required")
        placement = read(root / "3_pnr" / "Results" / f"{selected_id}.scaled_placement_verilog.json")
        modules = {module["concrete_name"]: module for module in placement["modules"]}
        leaves = {leaf["concrete_name"] for leaf in placement.get("leaves", [])}
        if (len(modules) != len(placement["modules"]) or selected_id not in modules
                or modules[selected_id].get("abstract_name") != top or set(modules) & leaves):
            raise ContractError("selected placement has ambiguous or mismatched concrete top/module identities")
        uses: dict[str, list[dict[str, Any]]] = {}

        def visit(concrete: str, ancestors: tuple[str, ...] = ()) -> None:
            if concrete in ancestors:
                raise ContractError("selected placement contains a module cycle")
            module = modules[concrete]
            abstract = module.get("abstract_name")
            if abstract not in compiled or module.get("parameters") != compiled[abstract].get("parameters"):
                raise ContractError("selected module/port identities differ from compiled topology")
            seen = set()
            for instance in module["instances"]:
                name, child = instance.get("instance_name"), instance.get("concrete_template_name")
                if not isinstance(name, str) or name in seen:
                    raise ContractError("selected placement instance identity is missing or duplicated")
                seen.add(name)
                if child in modules:
                    child_module = modules[child]
                    if instance.get("abstract_template_name") != child_module.get("abstract_name"):
                        raise ContractError("selected child abstract/concrete identity mismatch")
                    connections = instance.get("fa_map")
                    if not isinstance(connections, list) or not connections:
                        raise ContractError("selected child formal/actual map missing")
                    if any(fa.get("formal") not in child_module["parameters"] for fa in connections):
                        raise ContractError("selected child formal is not a declared port")
                    uses.setdefault(child, []).append({"parent_concrete_name": concrete, "instance_name": name,
                                                      "fa_map": copy.deepcopy(connections)})
                    visit(child, (*ancestors, concrete))
                elif child not in leaves:
                    raise ContractError("selected instance is neither an identified module nor primitive leaf")

        visit(selected_id)
        for concrete in sorted(uses):
            module = modules[concrete]
            abstract, formals = module["abstract_name"], module["parameters"]
            evidence = result["module_pin_evidence"].setdefault(abstract, {
                "module_name": abstract, "complete": True, "ports": {}, "variants": [], "blockers": [],
                "evidence_scope": "exported_native_blockPins_of_selected_baseline_child_variants"})
            try:
                routed = read(root / "3_pnr" / f"{concrete}.json")
                native_pins = _lef_pin_layers(read(root / "3_pnr" / "Results" / f"{concrete}.lef", as_json=False), abstract)
                if not isinstance(routed.get("terminals"), list):
                    raise ContractError("routed child terminal list missing")
                json_pins: dict[str, set[str]] = {formal: set() for formal in formals}
                for terminal in routed["terminals"]:
                    formal, layer = terminal.get("netName"), terminal.get("layer")
                    if terminal.get("netType") != "pin" or formal not in json_pins:
                        continue
                    if layer in resources["indices"]:
                        rect = terminal.get("rect")
                        if (not isinstance(rect, list) or len(rect) != 4
                                or any(isinstance(x, bool) or not isinstance(x, (float, int)) or not math.isfinite(x) for x in rect)
                                or rect[0] >= rect[2] or rect[1] >= rect[3]):
                            raise ContractError("routed child pin rectangle is missing or nonpositive")
                        json_pins[formal].add(layer)
                    elif isinstance(layer, str) and layer.startswith("M"):
                        raise ContractError("routed child JSON pin uses a metal absent from native Metalmap")
                ports = {}
                for formal in formals:
                    layers = native_pins.get(formal)
                    if not layers:
                        raise ContractError(f"exported child formal {formal} has no native metal contacts")
                    if any(layer not in resources["indices"] for layer in layers):
                        raise ContractError(f"exported child formal {formal} uses a metal absent from native Metalmap")
                    if not json_pins[formal].issubset(layers):
                        raise ContractError(f"viewer pin tag for {formal} disagrees with native exported contacts")
                    ports[formal] = sorted(layers, key=resources["indices"].get)
                    evidence["ports"][formal] = sorted(set(evidence["ports"].get(formal, [])) | layers,
                                                        key=resources["indices"].get)
                evidence["variants"].append({"concrete_name": concrete, "selected_uses": uses[concrete],
                    "native_exported_port_layers": ports,
                    "viewer_pin_tag_layers": {formal: sorted(layers, key=resources["indices"].get) for formal, layers in json_pins.items()},
                    "native_layers_missing_from_viewer_pin_tags": {
                        formal: sorted(set(ports[formal]) - json_pins[formal], key=resources["indices"].get) for formal in formals}})
            except (OSError, ValueError, ContractError, KeyError, TypeError, AttributeError) as exc:
                evidence["complete"] = False
                evidence["blockers"].append(f"{concrete}: {exc}")
        result["selected_candidate_id"] = selected_id
        result["status"] = "complete_exported_child_port_inventory" if all(
            evidence["complete"] for evidence in result["module_pin_evidence"].values()) else "blocked_pin_evidence"
        result["selection_sha256"] = _hash(selection)
    except (OSError, ValueError, ContractError, KeyError, TypeError, AttributeError) as exc:
        result.update(status="blocked_pin_evidence", blockers=[str(exc)])
    result["artifacts"] = [artifacts[path] for path in sorted(artifacts)]
    for evidence in result["module_pin_evidence"].values():
        evidence["provenance"] = {"selected_candidate_id": result.get("selected_candidate_id"),
                                  "selection_sha256": result.get("selection_sha256"), "pdk_sha256": _hash(pdk),
                                  "artifacts": copy.deepcopy(result["artifacts"]),
                                  "source_consumer_paths": result["source_consumer_paths"]}
    result["limitations"] = ["Native LEF exported PIN contacts are authoritative; viewer JSON pin tags alone can omit routed interface layers.",
                             "Only children reachable in the explicitly selected baseline placement are included.",
                             "Baseline pin-layer evidence establishes conservative containment, not future routing feasibility.",
                             "Top-down routes with filenames not explicitly identified by the selected placement remain blocked; no suffix fallback is used."]
    return result
