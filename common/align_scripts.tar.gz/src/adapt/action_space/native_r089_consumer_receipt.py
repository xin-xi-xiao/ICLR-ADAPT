"""Explicit R08/R09 configuration and native detail-router evidence."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re
import statistics

from .native_tuning_config import NativeTuningConfig

PATCH_ID = "align-r6-native-r089-v1"
MODULE_SHA256 = "a708387fc9b4e61920c1953d9a3b7735cdc5fb52bc94242c76a32253ff1a2861"
MARKER = "ADAPT_R6_DETAIL_V1"
ENV_KEYS = {"R08": "ADAPT_R6_NATIVE_R08_GRID_SCALE", "R09": "ADAPT_R6_NATIVE_R09_SYMMETRY_WEIGHT"}
RESOURCE_ENV = "ADAPT_R6_NATIVE_R09_FROZEN_UNIT_R"


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def freeze_r09_unit_r(layers_path, native_indices):
    """Freeze explicit legal resource indices; never derive these from action q.

    ReadPDKJSON orders native metals by their occurrence in Abstraction and
    multiplies UnitR.Mean by 0.0005 (ReadDesignRuleJson.cpp). Preserve both units.
    The caller registers this artifact before varying Route windows or w.
    """
    indices = list(native_indices)
    if (not indices or any(type(index) is not int or index < 0 for index in indices)
            or indices != sorted(set(indices))):
        raise ValueError("explicit ascending unique native signal resource indices required")
    path = Path(layers_path).resolve()
    layers = [row for row in json.loads(path.read_text())["Abstraction"] if row["Layer"].startswith("M")]
    rows = []
    for index in indices:
        layer = layers[index]
        unit_r = layer.get("UnitR", {})
        if not isinstance(unit_r, dict):
            raise ValueError("this native build reads UnitR.Mean")
        source = unit_r.get("Mean", 0)
        if not isinstance(source, (int, float)) or isinstance(source, bool) or not math.isfinite(source) or source < 0:
            raise ValueError("invalid frozen UnitR.Mean")
        rows.append({"native_index": index, "layer": layer["Layer"], "source_unit_r": source,
                     "native_unit_r": source * 0.0005})
    positive = [row["native_unit_r"] for row in rows if row["native_unit_r"] > 0]
    if not positive:
        raise ValueError("no positive frozen signal native unit_R")
    return {"schema": "adapt-r6-frozen-signal-unit-r-v1", "layers_path": str(path), "layers_sha256": _sha(path),
            "native_rc_scale": 0.0005, "rows": rows, "r_ref": statistics.median(positive),
            "mapping": "median_positive_native_unit_r_independent_of_action_route_window"}


def detail_environment(config: NativeTuningConfig, active_slots, frozen_resources=None):
    active = list(active_slots)
    if not active or len(set(active)) != len(active) or set(active) - set(ENV_KEYS):
        raise ValueError("explicit unique R08/R09 activation required")
    values = {row["slot_id"]: row["requested"] for row in config.to_trace()["slots"]}
    result = {ENV_KEYS[slot]: str(int(values[slot])) if slot == "R08" else repr(float(values[slot])) for slot in active}
    if "R09" in active:
        if not isinstance(frozen_resources, dict):
            raise ValueError("frozen signal native unit_R resource artifact required")
        verified = freeze_r09_unit_r(frozen_resources["layers_path"], [row["native_index"] for row in frozen_resources["rows"]])
        if verified != frozen_resources:
            raise ValueError("frozen resource provenance or native-unit conversion mismatch")
        result[RESOURCE_ENV] = ",".join(f'{row["native_index"]}:{row["native_unit_r"]!r}' for row in verified["rows"])
    return result


def _number(value):
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _integer(value):
    return int(value) if isinstance(value, str) and re.fullmatch(r"[0-9]+", value) else None


def _same_number(a, b):
    x, y = _number(a), _number(b)
    return x is not None and y is not None and math.isclose(x, y, rel_tol=1e-12, abs_tol=1e-15)


def readback_native_r089(log_paths, requested, runtime_identity):
    """Require actual native identity, independent modules and complete calls.

    Identity fields: patch_id, module_path, module_sha256, manifest_env,
    expected_modules and frozen_resources (from freeze_r09_unit_r) for R09.
    R09 empty reference/searches without nonzero cost remain inapplicable.
    """
    common, events, artifacts, router_modules = [], [], [], set()
    def add(status, reason, **context):
        common.append({"status": status, "reason": reason, **context})
    try:
        env = detail_environment(NativeTuningConfig.create(requested), requested, runtime_identity.get("frozen_resources"))
    except (KeyError, ValueError, TypeError, OSError, IndexError) as exc:
        env = {}; add("blocked_scope", "invalid_or_missing_frozen_config", detail=str(exc))
    if runtime_identity.get("patch_id") != PATCH_ID:
        add("mismatch", "patch_identity_mismatch")
    try:
        actual_sha = _sha(runtime_identity["module_path"])
    except (OSError, TypeError, KeyError):
        actual_sha = None
    if actual_sha != MODULE_SHA256 or runtime_identity.get("module_sha256") != MODULE_SHA256:
        add("mismatch", "actual_native_module_identity_mismatch")
    manifest_env = runtime_identity.get("manifest_env", {})
    if not isinstance(manifest_env, dict) or any(manifest_env.get(k) != v for k, v in env.items()):
        add("mismatch", "manifest_environment_disagrees_with_config")
    expected = runtime_identity.get("expected_modules", [])
    if not isinstance(expected, list) or not expected or any(not isinstance(v, str) or not v for v in expected) or len(set(expected)) != len(expected):
        expected = []; add("blocked_scope", "compiled_pnr_module_inventory_missing")
    seen = set()
    for supplied in log_paths:
        path = Path(supplied).resolve()
        if path in seen:
            add("mismatch", "duplicate_log_path"); continue
        seen.add(path)
        try:
            data = path.read_bytes()
        except OSError:
            add("unobserved", "native_log_missing", path=str(path)); continue
        artifacts.append({"path": str(path), "sha256": hashlib.sha256(data).hexdigest()})
        for number, line in enumerate(data.decode(errors="replace").splitlines(), 1):
            if "align.pnr.router" in line:
                match = re.search(r"bottom up routing for (\S+) \(\d+\) placement version \d+", line)
                if match: router_modules.add(match[1])
            if MARKER + " " not in line:
                continue
            fields = {}
            for token in line.split(MARKER + " ", 1)[1].split():
                key, sep, value = token.partition("=")
                if not sep or key in fields:
                    add("mismatch", "malformed_native_marker", path=str(path), line=number)
                fields[key] = value
            events.append({"fields": fields, "path": str(path), "line": number})
    if set(expected) != router_modules:
        add("blocked_scope", "independent_router_module_coverage_mismatch", expected=expected, observed=sorted(router_modules))
    slots = {}
    for slot, value in requested.items():
        issues, calls, configurations, exits, resources, dispatches = list(common), [], {}, {}, {}, {}
        pending = {}
        def issue(status, reason, **context):
            issues.append({"status": status, "reason": reason, **context})
        for event in events:
            f = event["fields"]
            if f.get("slot") != slot: continue
            module, phase = f.get("module"), f.get("phase")
            if f.get("patch") != PATCH_ID or module not in expected:
                issue("mismatch", "native_patch_or_module_mismatch", event=event)
            if "class" in f:
                issue(f["class"] if f["class"] in ("blocked_scope", "numerical_unsafe_runtime") else "mismatch", f.get("reason", "native_failure")); continue
            if phase in ("config", "module_enter"):
                if module in configurations: issue("mismatch", "duplicate_module_configuration", module=module)
                configurations[module] = event
            elif phase == "dispatch":
                if module in dispatches: issue("mismatch", "duplicate_module_dispatch", module=module)
                dispatches[module] = event
            elif phase == "resource":
                resources.setdefault(module, []).append(event)
            elif phase == "module_exit":
                if module in exits: issue("mismatch", "duplicate_module_completion", module=module)
                exits[module] = event
            elif phase in (("grid_enter", "grid_exit") if slot == "R08" else ("search_enter", "search_exit")):
                key = (event["path"], module, f.get("net"))
                if phase.endswith("_enter"):
                    if key in pending: issue("unobserved", "consumer_entry_without_previous_completion")
                    call = {"module": module, "net": f.get("net"), "entry": event, "exit": None}
                    pending[key] = call; calls.append(call)
                else:
                    call = pending.pop(key, None)
                    if call is None: issue("unobserved", "consumer_exit_without_entry")
                    else: call["exit"] = event
            else:
                issue("mismatch", "unknown_native_phase", event=event)
        if pending: issue("unobserved", "native_consumer_call_incomplete")
        if set(configurations) != set(expected) or set(exits) != set(expected):
            issue("blocked_scope", "detail_module_configuration_or_completion_missing")
        effective, meaningful = {}, 0
        for module in expected:
            c = configurations.get(module, {}).get("fields", {})
            end = exits.get(module, {}).get("fields", {})
            module_calls = [row for row in calls if row["module"] == module]
            valid = _integer(end.get("grid_calls" if slot == "R08" else "search_calls")) == len(module_calls)
            if slot == "R08":
                dispatch = dispatches.get(module, {}).get("fields", {})
                valid = (valid and _number(dispatch.get("requested")) == value and _integer(dispatch.get("native_default")) == 1
                         and _integer(dispatch.get("effective")) == value and _integer(dispatch.get("path_number")) == 1
                         and _integer(c.get("effective")) == value and _integer(c.get("path_number")) == 1 and _integer(end.get("effective")) == value)
                effective[module] = {"grid_scale": value, "grid_calls": len(module_calls)}
            else:
                frozen = runtime_identity.get("frozen_resources") or {}
                r_ref = frozen.get("r_ref")
                raw = value * r_ref if isinstance(r_ref, (int, float)) else None
                valid = (valid and _number(c.get("requested")) == value and _number(c.get("native_default")) == .2
                         and _same_number(c.get("r_ref"), r_ref) and _same_number(c.get("effective_raw"), raw))
                actual_rows = [e["fields"] for e in resources.get(module, [])]
                frozen_rows = frozen.get("rows", [])
                valid = (valid and len(actual_rows) == len(frozen_rows)
                         and _integer(c.get("positive_resources")) == sum(row["native_unit_r"] > 0 for row in frozen_rows))
                for observed, registered in zip(actual_rows, frozen_rows):
                    valid = (valid and _integer(observed.get("native_index")) == registered["native_index"] and observed.get("layer") == registered["layer"]
                             and _number(observed.get("expected_unit_r")) == registered["native_unit_r"]
                             and _number(observed.get("actual_unit_r")) is not None
                             and math.isclose(_number(observed.get("actual_unit_r")), registered["native_unit_r"], rel_tol=1e-12, abs_tol=1e-15))
                effective[module] = {"weight": value, "r_ref": r_ref, "effective_raw": raw, "search_calls": len(module_calls)}
            if not valid: issue("mismatch", "module_config_resource_or_call_count_mismatch", module=module)
        for call in calls:
            if call["exit"] is None: continue
            a, b = call["entry"]["fields"], call["exit"]["fields"]
            if slot == "R08":
                vertices = _integer(b.get("vertices"))
                valid = (_integer(a.get("effective")) == value and _integer(b.get("effective")) == value
                         and vertices is not None and _integer(a.get("actual_low")) is not None and _integer(a.get("actual_high")) is not None
                         and _integer(a.get("actual_low")) <= _integer(a.get("actual_high")) and _integer(a.get("actual_low")) == _integer(b.get("actual_low"))
                         and _integer(a.get("actual_high")) == _integer(b.get("actual_high")))
                call["applicable"] = vertices is not None and vertices > 0
                meaningful += int(call["applicable"])
            else:
                raw = effective.get(call["module"], {}).get("effective_raw")
                r_ref = effective.get(call["module"], {}).get("r_ref")
                refs, count, nonzero, found, segments = [_integer(b.get(key)) for key in ("reference_segments", "cost_evaluations", "nonzero_cost_evaluations", "found", "path_segments")]
                penalty = _number(b.get("penalty_sum"))
                valid = (_number(a.get("requested")) == value and _same_number(a.get("effective_raw"), raw) and _same_number(b.get("effective_raw"), raw)
                         and _same_number(a.get("r_ref"), r_ref)
                         and all(v is not None for v in (refs, count, nonzero, found, segments)) and 0 <= nonzero <= count
                         and found in (0, 1) and _integer(a.get("reference_segments")) == refs
                         and (refs > 0 or nonzero == 0) and _integer(a.get("sources")) is not None and _integer(a.get("destinations")) is not None
                         and penalty is not None and penalty >= 0
                         and (penalty == 0 if value == 0 or nonzero == 0 else penalty > 0))
                call["applicable"] = refs is not None and refs > 0 and nonzero is not None and nonzero > 0
                meaningful += int(call["applicable"])
            call["status"] = "observed" if valid else "mismatch"
            if not valid: issue("mismatch", "native_consumer_outcome_mismatch", call=call)
        states = {e["status"] for e in issues}
        status = next((s for s in ("mismatch", "numerical_unsafe_runtime", "blocked_scope", "unobserved") if s in states), "observed" if meaningful else "inapplicable")
        completed = sum(row["exit"] is not None for row in calls)
        slots[slot] = {"slot_id": slot, "status": status, "scope_kind": "module_local" if slot == "R08" else "global_native",
                       "scope_status": "verified" if not issues else "unverified", "requested_value": value, "expected_modules": expected,
                       "configurations": configurations, "resources": resources, "effective_values_by_scope": effective, "calls": calls, "issues": issues,
                       "entered_call_count": len(calls), "completed_call_count": completed, "failed_or_interrupted_call_count": len(calls)-completed,
                       "runtime_hit_count": completed, "meaningful_call_count": meaningful, "eligible_for_final_shared32_admission": False}
    return {"schema": "adapt-r6-native-r089-consumer-readback-v1", "patch_id": PATCH_ID, "slots": slots,
            "consumer_status": {k: v["status"] for k, v in slots.items()}, "native_module_identity": {"path": runtime_identity.get("module_path"), "actual_sha256": actual_sha, "required_sha256": MODULE_SHA256},
            "manifest_env": manifest_env, "frozen_resources": runtime_identity.get("frozen_resources"), "artifacts": artifacts,
            "eligible_for_final_shared32_admission": False}
