"""Native-coordinate mapping of the frozen P04--P07 extra-track actions.

ReadConstraint.cpp uses int(raw)*2/ScaleFactor for distances, but micrometres
times 2000 for halos. ILP_solver.cpp snaps gaps to the first directional metal
pitch. This module does not invent/select modules or prove runtime consumption.
"""
from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from adapt.contracts.common import ContractError


def placement_track_values(
    constraints: Sequence[Mapping[str, Any]], pdk: Mapping[str, Any],
    extra_tracks: Mapping[str, int],
) -> dict[str, Any]:
    """Decode one module's baseline constraints, preserving last-write order."""
    sf = float(pdk['ScaleFactor'])
    if not math.isfinite(sf) or sf <= 0:
        raise ContractError('positive ScaleFactor is required')
    metal = [item for item in pdk['Abstraction'] if str(item.get('Layer', '')).startswith('M')]
    pitches = {}
    for axis, direction in [('x', 'V'), ('y', 'H')]:
        first = next((item for item in metal if item.get('Direction') == direction), None)
        if first is None:
            raise ContractError(f'no {direction} placement pitch')
        pitches[axis] = int(2 * int(first['Pitch']) / sf)
        if pitches[axis] <= 0:
            raise ContractError('native placement pitch is zero')
    defaults = pdk.get('design_info', {})
    baseline = {'P04': int(2 * int(defaults.get('Hspace', 0)) / sf),
                'P05': int(2 * int(defaults.get('Vspace', 0)) / sf),
                'P06': 0., 'P07': 0.}
    for con in constraints:
        kind = con.get('constraint')
        if kind in ('BlockDistance', 'HorizontalDistance', 'VerticalDistance'):
            value = int(2 * int(con['abs_distance']) / sf)
            for slot in (('P04', 'P05') if kind == 'BlockDistance' else
                         ('P04',) if kind == 'HorizontalDistance' else ('P05',)):
                baseline[slot] = value
        elif kind == 'Boundary':
            baseline['P06'] = float(con.get('halo_horizontal', 0)) * 2000
            baseline['P07'] = float(con.get('halo_vertical', 0)) * 2000
    result = {}
    for slot, axis in [('P04','x'),('P05','y'),('P06','x'),('P07','y')]:
        k = extra_tracks[slot]
        if isinstance(k, bool) or k not in (0,1,2,4,8):
            raise ContractError(f'{slot} requires frozen extra-track choices')
        base = baseline[slot]
        if base < 0 or not math.isfinite(base):
            raise ContractError(f'{slot}: invalid baseline')
        pitch = pitches[axis]
        target = math.ceil(base / pitch) * pitch + k * pitch
        if slot in ('P04', 'P05'):
            raw = math.ceil(target * sf / 2)
            native = int(raw * 2 / sf)
            effective = math.ceil(native / pitch) * pitch
            if effective != target:
                raise ContractError(f'{slot}: target not exactly representable')
        else:
            raw = target / 2000
            native = raw * 2000
            effective = native
        result[slot] = {'requested_extra_tracks': k, 'baseline_native': base,
                        'pitch_native': pitch, 'target_native': target,
                        'raw_value': raw, 'effective_native': effective}
    return {'schema': 'shared32-placement-track-mapping-v1', 'scale_factor': sf,
            'slots': result, 'scope_policy': 'caller_supplied_module_baseline'}
