"""Frozen external P08/R03 net selectors at the compiled topology boundary.

No ALIGN imports or launches. External supply exclusions affect only selector
membership; native Nets/PowerNets classification and electrical connectivity are
preserved. Artifact readback never claims field-level native runtime counts.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Mapping, Sequence

from adapt.contracts.common import ContractError
from .shared32_layer_decoder import collect_baseline_pin_layers, collect_routed_child_port_layers

SCHEMA = "shared32-frozen-net-selector-campaign-v1"
ROLE_SCHEMA = "shared32-explicit-net-role-map-v1"
DOMAINS = {"P08": (1, 2, 4, 8, 16), "R03": (1, 2, 3)}
OTHER_ACTION_CONSTRAINTS = {"AspectRatio", "HorizontalDistance", "VerticalDistance", "Boundary", "Route"}
SOURCES = ["ALIGN-public/align/pnr/build_pnr_model.py:59-93,126-139",
    "ALIGN-public/align/pnr/write_constraint.py:156-174",
    "ALIGN-public/PlaceRouteHierFlow/PnRDB/ReadConstraint.cpp:87-94,530-539",
    "ALIGN-public/PlaceRouteHierFlow/placer/design.cpp:183-198",
    "ALIGN-public/PlaceRouteHierFlow/router/GcellDetailRouter.cpp:293-297,394-410,479",
    "ALIGN-public/PlaceRouteHierFlow/router/GcellGlobalRouter.cpp:173-209"]


def _sha(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _artifact(path: Path) -> dict[str, str]:
    return {"path": str(path.resolve()), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def _integer(value: Any, *, positive: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < (1 if positive else 0):
        raise ContractError("integer native net value required")
    return value


def _identity(topology: Mapping[str, Any]) -> dict[str, Any]:
    value = copy.deepcopy(topology)
    names = [m["name"] for m in value["modules"]]
    if not names or any(not isinstance(name, str) or not name or Path(name).name != name for name in names) or len(names) != len(set(names)):
        raise ContractError("unique nonempty compiled module inventory required")
    for module in value["modules"]:
        module.pop("constraints")
    return value


def _hard_constraints(module: Mapping[str, Any]) -> list[dict[str, Any]]:
    return [copy.deepcopy(c) for c in module["constraints"] if c["constraint"] not in OTHER_ACTION_CONSTRAINTS]


def _native_values(constraints: Sequence[Mapping[str, Any]], *, native: bool) -> dict[str, dict[str, int]]:
    """Mirror ordered last-write wins, including truthy NetConst.criticality."""
    result: dict[str, dict[str, int]] = {"P08": {}, "R03": {}}
    if native and isinstance(constraints, Mapping):
        constraints = constraints["constraints"]
    for row in constraints:
        kind = row.get("const_name" if native else "constraint")
        if native:
            if kind == "CritNet":
                result["P08"][row["net_name"]] = _integer(row["priority"])
            elif kind == "Multi_Connection":
                result["R03"][row["net_name"]] = _integer(row["multi_number"], positive=True)
        elif kind == "NetPriority" or (kind == "NetConst" and row.get("criticality")):
            value = _integer(row["weight"] if kind == "NetPriority" else row["criticality"])
            for name in row["nets"]:
                result["P08"][name] = value
        elif kind == "MultiConnection":
            for name in row["nets"]:
                result["R03"][name.upper()] = _integer(row["multiplier"], positive=True)
    return result


def _report(path: Path) -> dict[str, dict[str, list[dict[str, Any]]]]:
    result: dict[str, dict[str, list[dict[str, Any]]]] = {}
    node = net = None
    for line in path.read_text().splitlines():
        if line.startswith("Node "):
            node, net = line[5:].strip(), None
            if node:
                result.setdefault(node, {})
        elif line.startswith("  Net ") and node:
            net = line[6:].strip()
            result[node].setdefault(net, [])
        elif node and net:
            match = re.fullmatch(r"\s+Pin (.+) Find a path ([01])", line)
            if match:
                result[node][net].append({"pin": match[1], "found_path": int(match[2])})
    return result


def _roles(topology: Mapping[str, Any], role_map: Mapping[str, Any], top: str) -> dict[str, Any]:
    if role_map.get("schema") != ROLE_SCHEMA or role_map.get("top") != top or not role_map.get("version"):
        raise ContractError("versioned explicit role map for exact top required")
    if not role_map.get("provenance") or not role_map.get("classification_kind"):
        raise ContractError("role-map source provenance and native/external classification required")
    for artifact in role_map["provenance"]:
        if not artifact.get("reason") or _artifact(Path(artifact["path"]))["sha256"] != artifact.get("sha256"):
            raise ContractError("role-map source changed or reason missing")
    modules = {m["name"]: m for m in topology["modules"]}
    roles = {name: {"power": set(), "ground": set()} for name in modules}
    if top not in modules:
        raise ContractError("exact top missing")
    for role in ("power", "ground"):
        values = role_map["top_exclusions"].get(role, [])
        if not isinstance(values, list) or any(n not in modules[top]["parameters"] for n in values):
            raise ContractError("declared selector rails must be exact compiled top ports")
        roles[top][role].update(values)
    changed = True
    while changed:
        changed = False
        for name, module in modules.items():
            for instance in module["instances"]:
                child = instance["abstract_template_name"]
                if child not in modules:
                    continue
                for fa in instance["fa_map"]:
                    for role in ("power", "ground"):
                        if fa["actual"] in roles[name][role] and fa["formal"] not in roles[child][role]:
                            roles[child][role].add(fa["formal"])
                            changed = True
    for name, module in modules.items():
        if roles[name]["power"] & roles[name]["ground"]:
            raise ContractError("conflicting power/ground roles on shared module master")
        for constraint in module["constraints"]:
            role = {"PowerPorts": "power", "GroundPorts": "ground"}.get(constraint["constraint"])
            if role and not set(constraint["ports"]).issubset(roles[name][role]):
                raise ContractError("role map omits an explicitly declared native supply")
        for instance in module["instances"]:
            child = instance["abstract_template_name"]
            if child in modules:
                for fa in instance["fa_map"]:
                    for role in ("power", "ground"):
                        if (fa["formal"] in roles[child][role]) != (fa["actual"] in roles[name][role]):
                            raise ContractError("shared module formal has inconsistent rail role across occurrences")
    return {name: {role: sorted(nets) for role, nets in values.items()} for name, values in roles.items()}


def freeze_net_campaign(baseline_run_dir: str | Path, *, top: str,
                        role_map: Mapping[str, Any] | str | Path,
                        output_path: str | Path | None = None) -> dict[str, Any]:
    run = Path(baseline_run_dir).resolve()
    work = run / "align_workdir"
    roles_input = json.loads(Path(role_map).read_text()) if isinstance(role_map, (str, Path)) else copy.deepcopy(role_map)
    manifest_path = run / "run_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("returncode") != 0 or manifest.get("collector_status") != "ok":
        raise ContractError("completed selected baseline required")
    path = work / "1_topology" / f"{top}.verilog.json"
    topology = json.loads(path.read_text())
    identity = _identity(topology)
    roles = _roles(topology, roles_input, top)
    pdk = json.loads((work / "3_pnr/inputs/layers.json").read_text())
    child = collect_routed_child_port_layers(work, pdk, top=top,
        selected_candidate=run / "selected_candidate_collection.json")
    if child.get("status") != "complete_exported_child_port_inventory":
        raise ContractError(f"selected child inventory incomplete: {child.get('reason', child.get('status'))}")
    pins = collect_baseline_pin_layers(work, top, module_pin_evidence=child["module_pin_evidence"])
    report_path = work / "3_pnr/Results/Router_Report.txt"
    report = _report(report_path)
    global_path = work / "3_pnr/global_router_plt.json"
    global_geometry = json.loads(global_path.read_text())
    global_nets = {row["name"]: row for row in global_geometry["Glbaol_Routes"]} if global_geometry["Cell Name"] == top else {}
    selected = {top: [child["selected_candidate_id"]]}
    selected.update({name: [v["concrete_name"] for v in row["variants"]] for name, row in child["module_pin_evidence"].items()})
    repo = Path(__file__).resolve().parents[3]
    source_paths = [repo / source.split(":")[0] for source in SOURCES]
    scopes, artifacts = {}, [_artifact(p) for p in (manifest_path, path, report_path, global_path, Path(__file__), *source_paths)]
    for module in topology["modules"]:
        name = module["name"]
        access = pins.get("modules", {}).get(name, {})
        if access.get("complete") is not True:
            raise ContractError(f"{name}: baseline physical pin inventory incomplete")
        if name not in selected or any(concrete not in report for concrete in selected[name]):
            raise ContractError(f"{name}: selected baseline Router_Report node missing")
        native_path = work / "3_pnr/inputs" / f"{name}.pnr.const.json"
        native = _native_values(json.loads(native_path.read_text()), native=True)
        compiler = _native_values(module["constraints"], native=False)
        if compiler != native:
            raise ContractError(f"{name}: baseline compiler/native priority or multi_connection differs")
        artifacts.append(_artifact(native_path))
        endpoints: dict[str, dict[tuple[str, str], Any]] = {}
        for endpoint in access["endpoints"]:
            endpoints.setdefault(endpoint["actual"], {})[(endpoint["instance_name"], endpoint["formal"])] = endpoint
        excluded_roles = set(roles[name]["power"] + roles[name]["ground"])
        do_not_route = {net for c in module["constraints"] if c["constraint"] == "DoNotRoute" for net in c["nets"]}
        net_rows = {}
        for net, connected in sorted(endpoints.items()):
            connections = list(connected.values())
            native_reports = {concrete: report[concrete].get(net, []) for concrete in selected[name]}
            physical = any(row["pin_layers"] and row["evidence_kind"] != "unverified_recursive_leaf_proxy" for row in connections)
            reason = "external_selector_supply_exclusion" if net in excluded_roles else "DoNotRoute" if net in do_not_route else "fewer_than_two_logical_block_endpoints" if len(connections) < 2 else "floating_no_baseline_pin_contacts" if not physical else None
            router_processed = all(len({row["pin"] for row in records}) >= 2 for records in native_reports.values())
            route_reason = reason
            if route_reason is None and not router_processed:
                if name == top and net in global_nets and not global_nets[net]["global_path"]:
                    route_reason = "baseline_global_path_empty_native_floating_gate"
                else:
                    raise ContractError(f"{name}/{net}: normal routing status unobserved in selected baseline")
            net_rows[net] = {"canonical_net_id": [name, net], "pin_count": len(connections), "endpoints": connections,
                "P08_exclusion": reason, "R03_exclusion": route_reason,
                "native_baseline_weight": native["P08"].get(net, 1), "native_baseline_multi_connection": native["R03"].get(net, 1),
                "baseline_native_router_processed": router_processed, "baseline_report_pins": native_reports,
                "native_electrical_supply_classification_changed": False,
                "baseline_top_global_path_count": len(global_nets[net]["global_path"]) if name == top and net in global_nets else None}
        candidates = sorted((net for net, row in net_rows.items() if row["P08_exclusion"] is None), key=lambda net: (-net_rows[net]["pin_count"], net))
        count = min(len(candidates) - 1, max(1, len(candidates) // 4)) if len(candidates) >= 2 else 0
        target, reference = candidates[:count], candidates[count:]
        p_status = "ready_static" if target and any(net_rows[n]["native_baseline_weight"] > 0 for n in reference) and any(net_rows[n]["native_baseline_weight"] > 0 for n in target) else "inapplicable_no_positive_relative_reference"
        routed = [net for net, row in net_rows.items() if row["R03_exclusion"] is None]
        scopes[name] = {"nets": net_rows, "P08": {"status": p_status, "target": target if p_status == "ready_static" else [],
            "reference": reference, "sorted_candidates": candidates}, "R03": {"status": "ready_static" if routed else "inapplicable_no_routed_signal", "target": routed},
            "baseline_native_constraints": native, "hard_constraints": _hard_constraints(module), "selected_concrete_nodes": selected[name]}
    campaign = {"schema": SCHEMA, "top": top, "baseline_run_dir": str(run), "baseline_workdir": str(work),
        "baseline_topology_path": str(path), "baseline_topology": topology, "compiler_identity": identity,
        "compiler_identity_sha256": _sha(identity), "role_map": roles_input, "role_map_sha256": _sha(roles_input),
        "selector_rail_roles_by_module": roles, "scopes": scopes, "domains": DOMAINS, "reference": {"P08": 1, "R03": 1},
        "selector_rule": "P08: (-distinct(instance,formal) count,canonical net); first min(N-1,max(1,floor(N/4))); no module terminals; R03: all eligible baseline processed signal nets",
        "pin_inventory": pins, "child_port_inventory": child, "artifacts": artifacts,
        "source_consumer_paths": SOURCES, "runtime_hit_count": None,
        "reference_changes": {"P08": [], "R03": [[name, net] for name, scope in scopes.items() for net in scope["R03"]["target"] if scope["nets"][net]["native_baseline_multi_connection"] != 1]},
        "limitations": ["Role exclusions are an external selector profile; native signal/power classification is unchanged.",
            "Selected baseline routing membership stays frozen across actions; routing success and repeated paths require postaction checks.",
            "CritNet/Multi_Connection files are consumer artifacts, not runtime field-call counts."]}
    campaign["campaign_sha256"] = _sha(campaign)
    if output_path is not None:
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open("x") as stream:
            json.dump(campaign, stream, indent=2)
            stream.write("\n")
    return campaign


def load_net_campaign(campaign: Mapping[str, Any] | str | Path) -> dict[str, Any]:
    value = json.loads(Path(campaign).read_text()) if isinstance(campaign, (str, Path)) else copy.deepcopy(campaign)
    if value.get("schema") != SCHEMA or value.get("campaign_sha256") != _sha({k: v for k, v in value.items() if k != "campaign_sha256"}):
        raise ContractError("net selector campaign schema/hash mismatch")
    return value


def decode_net_values(campaign: Mapping[str, Any] | str | Path, values: Mapping[str, Any], *, active_slots: Sequence[str] = ("P08",)) -> dict[str, Any]:
    frozen = load_net_campaign(campaign)
    if not active_slots or len(set(active_slots)) != len(active_slots) or any(slot not in DOMAINS for slot in active_slots):
        raise ContractError("unique active P08/R03 slots required")
    result = {"requested_values": {}, "effective_values": {}, "active_slots": list(active_slots)}
    for slot in active_slots:
        raw = values.get(slot)
        if isinstance(raw, bool) or not isinstance(raw, int) or raw not in DOMAINS[slot]:
            raise ContractError(f"{slot}: value outside frozen domain")
        result["requested_values"][slot] = raw
        effective = {name: {net: raw * scope["nets"][net]["native_baseline_weight"] if slot == "P08" else raw
            for net in scope[slot]["target"]} for name, scope in frozen["scopes"].items()}
        if not any(effective.values()):
            raise ContractError(f"{slot}: no eligible relative/routed net scope")
        result["effective_values"][slot] = effective
    return result


def broadcast_compiled_nets(topology_path: str | Path, campaign: Mapping[str, Any] | str | Path,
    values: Mapping[str, Any], *, active_slots: Sequence[str] = ("P08",), input_dir: str | Path | None = None,
    reference_policy: str = "reuse_compatible_net_background") -> dict[str, Any]:
    frozen, path = load_net_campaign(campaign), Path(topology_path)
    if reference_policy not in {"reuse_compatible_net_background", "new_net_reference"}:
        raise ContractError("explicit net reference policy required")
    if path.resolve() == Path(frozen["baseline_topology_path"]):
        raise ContractError("cannot mutate frozen baseline topology")
    original = path.read_bytes()
    topology = json.loads(original)
    if _identity(topology) != frozen["compiler_identity"]:
        raise ContractError("fresh compiled electrical/fa_map identity differs from frozen selector")
    decoded = decode_net_values(frozen, values, active_slots=active_slots)
    if any(frozen["reference_changes"][slot] for slot in active_slots) and reference_policy != "new_net_reference":
        raise ContractError("requested reference changes original native background; new_net_reference required")
    for module in topology["modules"]:
        if _hard_constraints(module) != frozen["scopes"][module["name"]]["hard_constraints"]:
            raise ContractError("fresh non-P/Route constraints differ from frozen net baseline")
        for slot in active_slots:
            for net, raw in decoded["effective_values"][slot][module["name"]].items():
                module["constraints"].append({"constraint": "NetPriority", "nets": [net], "weight": raw} if slot == "P08"
                    else {"constraint": "MultiConnection", "nets": [net], "multiplier": raw})
    snapshot = path.with_name(path.stem + ".pre_shared32_nets.json")
    if snapshot.exists():
        raise ContractError("net broadcaster already applied; action accumulation prohibited")
    mirrors = []
    if input_dir is not None:
        directory = Path(input_dir)
        for module in topology["modules"]:
            target = directory / f"{module['name'].lower()}.const.json"
            if target.parent.resolve() != directory.resolve():
                raise ContractError("invalid module filename")
            mirrors.append((target, module["constraints"]))
    with snapshot.open("xb") as stream:
        stream.write(original)
    path.write_text(json.dumps(topology, indent=2) + "\n")
    for target, constraints in mirrors:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(constraints, indent=2) + "\n")
    receipt = {"schema": "shared32-compiled-net-selector-broadcast-v1", "campaign_sha256": frozen["campaign_sha256"],
        **decoded, "reference_policy": reference_policy, "topology_path": str(path.resolve()),
        "pre_action_topology": _artifact(snapshot), "effective_topology_sha256": _sha(topology),
        "effective_constraints_by_module": {m["name"]: m["constraints"] for m in topology["modules"]},
        "role_map_sha256": frozen["role_map_sha256"], "selector_membership_rebuilt": False,
        "native_net_classification_changed": False, "runtime_hit_count": None,
        "input_mirrors": [_artifact(target) for target, _ in mirrors]}
    return {"compiled_net_broadcast": receipt, "requested_values": decoded["requested_values"],
        "requested_all_values": decoded["requested_values"], "effective_values": decoded["effective_values"],
        "effective_all_values": decoded["effective_values"],
        "request_write_count": {slot: sum(len(nets) for nets in decoded["effective_values"][slot].values()) for slot in active_slots},
        "consumer_status_all": {slot: "prepared_requires_native_constraint_readback" for slot in active_slots}}


def readback_compiled_nets(trace: Mapping[str, Any], campaign: Mapping[str, Any] | str | Path,
                          workdir: str | Path) -> dict[str, Any]:
    frozen, work = load_net_campaign(campaign), Path(workdir)
    request = trace.get("compiled_net_broadcast", trace)
    if request.get("campaign_sha256") != frozen["campaign_sha256"]:
        raise ContractError("net trace campaign identity mismatch")
    decoded = decode_net_values(frozen, request["requested_values"], active_slots=request["active_slots"])
    result: dict[str, Any] = {"schema": "shared32-net-consumer-readback-v1", "campaign_sha256": frozen["campaign_sha256"],
        "scopes": {}, "consumer_status": {}, "runtime_hit_count": None, "source_consumer_paths": SOURCES,
        "evidence_kind": "compiled_and_native_consumer_constraint_artifacts_not_runtime_calls"}
    try:
        topology_path = work / "1_topology" / f"{frozen['top']}.verilog.json"
        topology = json.loads(topology_path.read_text())
        if _identity(topology) != frozen["compiler_identity"]:
            raise ContractError("actual compiler identity differs from frozen selector")
        modules = {m["name"]: m for m in topology["modules"]}
        for name, scope in frozen["scopes"].items():
            if modules[name]["constraints"] != request["effective_constraints_by_module"][name]:
                raise ContractError("actual compiled constraints differ from prepared net profile")
            path = work / "3_pnr/inputs" / f"{name}.pnr.const.json"
            actual = _native_values(json.loads(path.read_text()), native=True)
            expected = copy.deepcopy(scope["baseline_native_constraints"])
            for slot in request["active_slots"]:
                expected[slot].update(decoded["effective_values"][slot][name])
            rows = {}
            for slot in request["active_slots"]:
                rows[slot] = {net: {"requested_raw": raw, "native_consumer_file_value": actual[slot].get(net, 1),
                    "status": "observed_artifacts" if actual[slot].get(net, 1) == raw else "mismatch"}
                    for net, raw in decoded["effective_values"][slot][name].items()}
            # Check all nets, including excluded supply/reference nets retained at baseline.
            matches = all(actual[slot].get(net, 1) == expected[slot].get(net, 1)
                for slot in DOMAINS for net in set(actual[slot]) | set(expected[slot]) | set(scope["nets"]))
            result["scopes"][name] = {"status": "observed_artifacts" if matches else "mismatch", "slots": rows,
                "consumer_file": _artifact(path), "all_baseline_or_requested_net_values_match": matches,
                "role_exclusions": frozen["selector_rail_roles_by_module"][name]}
        good = all(row["status"] == "observed_artifacts" for row in result["scopes"].values())
        result["status"] = "observed_artifacts" if good else "mismatch"
        result["consumer_status"] = {slot: result["status"] for slot in request["active_slots"]}
        result["full_eligible_net_scope_verified"] = good
        result["route_iteration_counts"] = "unobserved_not_inferred_from_multi_number_or_write_counts"
        result["eligible_for_constraint_stage_admission"] = good
        result["postaction_routing_success"] = "separate_selected_candidate_geometry_and_connectivity_gates_required"
    except (OSError, KeyError, ValueError, TypeError, ContractError) as exc:
        result.update(status="mismatch" if isinstance(exc, ContractError) else "unobserved", reason=str(exc),
            full_eligible_net_scope_verified=False, eligible_for_constraint_stage_admission=False)
        result["consumer_status"] = {slot: result["status"] for slot in request["active_slots"]}
    return result
