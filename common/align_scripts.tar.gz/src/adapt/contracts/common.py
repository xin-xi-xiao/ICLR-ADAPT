"""Small dependency-light helpers for contract validation and provenance hashes."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

import yaml


class ContractError(ValueError):
    """Raised when a versioned contract or manifest is invalid."""


def canonical_json_bytes(value: Any, *, omit_keys: tuple[str, ...] = ()) -> bytes:
    """Serialize a JSON-compatible value deterministically.

    Contract hashes deliberately exclude the declared hash field itself.  Nested
    values are left untouched so a semantic change anywhere below the root
    changes the digest.
    """

    if isinstance(value, Mapping):
        value = {key: item for key, item in value.items() if key not in omit_keys}
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def content_hash(value: Any, *, omit_keys: tuple[str, ...] = ()) -> str:
    return hashlib.sha256(canonical_json_bytes(value, omit_keys=omit_keys)).hexdigest()


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_yaml_mapping(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as stream:
        payload = yaml.safe_load(stream)
    if not isinstance(payload, dict):
        raise ContractError(f"contract must be a mapping: {path}")
    return payload


def load_json_mapping(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as stream:
        payload = json.load(stream)
    if not isinstance(payload, dict):
        raise ContractError(f"manifest must be a mapping: {path}")
    return payload


def validate_declared_hash(
    payload: Mapping[str, Any],
    *,
    field: str,
    source: str | Path,
) -> str:
    declared = payload.get(field)
    if not isinstance(declared, str) or len(declared) != 64:
        raise ContractError(f"{source}: {field} must be a 64-character SHA-256")
    actual = content_hash(payload, omit_keys=(field,))
    if declared != actual:
        raise ContractError(
            f"{source}: {field} mismatch: declared={declared}, actual={actual}"
        )
    return actual
