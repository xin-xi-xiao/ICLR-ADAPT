"""Open post-layout preflight utilities.

The package intentionally keeps native-IHP verification separate from the
ALIGN/SKY130 adapter path.  A successful IHP preflight validates only that the
native golden may be started; it does not claim that any DRC/LVS/PEX stage has
passed.
"""

from .ihp_native_preflight import (
    NativePreflightError,
    load_native_preflight_config,
    probe_native_environment,
)

__all__ = [
    "NativePreflightError",
    "load_native_preflight_config",
    "probe_native_environment",
]
