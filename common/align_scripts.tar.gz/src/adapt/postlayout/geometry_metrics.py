"""Deterministic geometry/resource metrics for Goal-R6.

The evaluator consumes an explicit, provenance-carrying geometry artifact.  It
does not infer signal/power identity from geometry or terminal names.  The
minimal fixture format intentionally accepts axis-aligned rectangles only;
production GDS/path serializers must convert polygons to this contract or
return ``unsupported_geometry`` instead of silently approximating them.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Iterable, Mapping, Sequence


class GeometryMetricError(ValueError):
    pass


def _rect(value: Sequence[Any], field: str) -> tuple[float, float, float, float]:
    if isinstance(value, (str, bytes)) or len(value) != 4:
        raise GeometryMetricError(f"{field} must be [x0,y0,x1,y1]")
    x0, y0, x1, y1 = (float(item) for item in value)
    if not all(map(lambda x: x == x and abs(x) != float("inf"), (x0, y0, x1, y1))):
        raise GeometryMetricError(f"{field} contains non-finite coordinates")
    if x1 <= x0 or y1 <= y0:
        raise GeometryMetricError(f"{field} must have positive width and height")
    return x0, y0, x1, y1


def _union_area(rectangles: Iterable[tuple[float, float, float, float]]) -> float:
    """Exact area of an axis-aligned rectangle union by coordinate sweep."""

    rects = tuple(rectangles)
    if not rects:
        return 0.0
    xs = sorted({edge for rect in rects for edge in (rect[0], rect[2])})
    area = 0.0
    for left, right in zip(xs, xs[1:]):
        if right <= left:
            continue
        intervals = sorted((rect[1], rect[3]) for rect in rects if rect[0] < right and rect[2] > left)
        covered = 0.0
        current_start = current_end = None
        for start, end in intervals:
            if current_start is None:
                current_start, current_end = start, end
            elif start > current_end:
                covered += current_end - current_start
                current_start, current_end = start, end
            else:
                current_end = max(current_end, end)
        if current_start is not None:
            covered += current_end - current_start
        area += (right - left) * covered
    return area


def _bbox(rectangles: Iterable[tuple[float, float, float, float]]) -> tuple[float, float, float, float] | None:
    rects = tuple(rectangles)
    if not rects:
        return None
    return (
        min(item[0] for item in rects),
        min(item[1] for item in rects),
        max(item[2] for item in rects),
        max(item[3] for item in rects),
    )


def _area_bbox(rect: tuple[float, float, float, float] | None) -> float | None:
    return None if rect is None else (rect[2] - rect[0]) * (rect[3] - rect[1])


def _status(value: float | None, unit: str, status: str = "ok", reason: str | None = None) -> dict[str, Any]:
    result = {"value": value, "unit": unit, "status": status}
    if reason is not None:
        result["reason"] = reason
    return result


def compute_geometry_metrics(
    artifact: Mapping[str, Any],
    *,
    reference_widths_um: Mapping[str, float],
) -> dict[str, Any]:
    """Compute Goal-R6 metrics from a provenance-carrying rectangle artifact.

    Required artifact fields are ``units`` (``nm`` or ``um``), ``node_boundary``
    and ``geometry``.  Each geometry record has ``kind`` (``metal`` or ``cut``),
    ``layer``, ``rect`` and ``source``.  Metal records also require
    ``net_class`` in ``signal``, ``power``, ``ground`` or ``unknown``.  Unknown
    classes are excluded from signal/power resource metrics and reported.
    """

    units = artifact.get("units")
    if units not in {"nm", "um"}:
        raise GeometryMetricError("artifact.units must be 'nm' or 'um'")
    scale = 1e-3 if units == "nm" else 1.0
    boundary_raw = _rect(artifact.get("node_boundary"), "node_boundary")
    halo = artifact.get("declared_halo")
    halo_raw = None if halo is None else _rect(halo, "declared_halo")
    boundary = tuple(value * scale for value in boundary_raw)
    halo_rect = None if halo_raw is None else tuple(value * scale for value in halo_raw)
    records = artifact.get("geometry")
    if not isinstance(records, list):
        raise GeometryMetricError("artifact.geometry must be a list")

    metal_by_class_layer: dict[tuple[str, str], list[tuple[float, float, float, float]]] = defaultdict(list)
    all_rects: list[tuple[float, float, float, float]] = []
    cut_keys: set[tuple[str, tuple[float, float, float, float]]] = set()
    unknown_count = 0
    provenance_missing = 0
    for index, record in enumerate(records):
        if not isinstance(record, Mapping):
            raise GeometryMetricError(f"geometry[{index}] must be an object")
        if not record.get("source"):
            provenance_missing += 1
        rect = _rect(record.get("rect"), f"geometry[{index}].rect")
        rect_um = tuple(value * scale for value in rect)
        kind = record.get("kind")
        layer = str(record.get("layer", ""))
        if kind == "metal":
            net_class = record.get("net_class")
            if net_class in {"signal", "power", "ground"}:
                group = "power" if net_class in {"power", "ground"} else "signal"
                metal_by_class_layer[(group, layer)].append(rect_um)
            else:
                unknown_count += 1
            all_rects.append(rect_um)
        elif kind == "cut":
            if layer.startswith("V") and layer[1:].isdigit() and int(layer[1:]) >= 1:
                cut_keys.add((layer, rect_um))
            # Contacts/V0 are intentionally excluded from intermetal count.
        else:
            raise GeometryMetricError(f"geometry[{index}].kind must be metal or cut")

    if provenance_missing:
        return {
            "metric_status": "invalid",
            "reason": "source_provenance_missing",
            "A_eval": _status(None, "um2", "invalid", "source_provenance_missing"),
            "L_eq_signal": _status(None, "um_equiv", "invalid", "source_provenance_missing"),
            "L_eq_power": _status(None, "um_equiv", "invalid", "source_provenance_missing"),
            "N_cut_intermetal": _status(None, "count", "invalid", "source_provenance_missing"),
        }

    geometry_bbox = _bbox(all_rects)
    eval_bbox = _bbox([boundary] + ([halo_rect] if halo_rect else []) + all_rects)
    widths: dict[str, float] = {}
    for layer, width in reference_widths_um.items():
        numeric = float(width)
        if numeric <= 0:
            raise GeometryMetricError(f"reference width for {layer} must be positive")
        widths[str(layer)] = numeric

    resources = {"signal": 0.0, "power": 0.0}
    per_layer: dict[str, dict[str, float]] = {"signal": {}, "power": {}}
    missing_width_layers: set[str] = set()
    for (group, layer), rects in metal_by_class_layer.items():
        area = _union_area(rects)
        if layer not in widths:
            missing_width_layers.add(layer)
            continue
        equivalent = area / widths[layer]
        resources[group] += equivalent
        per_layer[group][layer] = equivalent

    if missing_width_layers:
        missing = ",".join(sorted(missing_width_layers))
        return {
            "metric_status": "invalid",
            "reason": f"reference_width_missing:{missing}",
            "A_eval": _status(_area_bbox(eval_bbox), "um2", "invalid", "reference_width_missing"),
            "L_eq_signal": _status(None, "um_equiv", "invalid", "reference_width_missing"),
            "L_eq_power": _status(None, "um_equiv", "invalid", "reference_width_missing"),
            "N_cut_intermetal": _status(len(cut_keys), "count", "invalid", "reference_width_missing"),
        }

    power_status = "ok" if any(group == "power" for group, _ in metal_by_class_layer) else "not_applicable"
    result = {
        "metric_status": "ok",
        "unknown_geometry_count": unknown_count,
        "A_geom": _status(_area_bbox(geometry_bbox), "um2"),
        "A_eval": _status(_area_bbox(eval_bbox), "um2"),
        "L_eq_signal": _status(resources["signal"], "um_equiv"),
        "L_eq_power": _status(resources["power"] if power_status == "ok" else None, "um_equiv", power_status, "no_power_geometry" if power_status != "ok" else None),
        "N_cut_intermetal": _status(len(cut_keys), "count"),
        "per_layer_L_eq": per_layer,
        "cut_layer_count": len(cut_keys),
    }
    return result


def mask_ineligible_metrics(
    metrics: Mapping[str, Any],
    *,
    eligible: bool,
    reason: str,
) -> dict[str, Any]:
    """Separate diagnostic arithmetic from metrics eligible for effects.

    A serializer may be able to compute numbers from a partial artifact.  Those
    numbers are useful for debugging, but they are not observations of the
    declared final metric when ownership or stage provenance is incomplete.
    Keep them under ``diagnostic_metrics`` and mask the primary fields so a
    downstream effect collector cannot accidentally consume them.
    """
    result = dict(metrics)
    result["eligible_for_effect"] = bool(eligible)
    if eligible:
        result["metric_status"] = result.get("metric_status", "ok")
        return result
    metric_ids = ("A_eval", "L_eq_signal", "L_eq_power", "N_cut_intermetal")
    diagnostic = {metric_id: result.get(metric_id) for metric_id in metric_ids if metric_id in result}
    result["diagnostic_metrics"] = diagnostic
    result["metric_status"] = "partial_unavailable"
    result["metric_status_reason"] = reason
    for metric_id in metric_ids:
        current = result.get(metric_id)
        if not isinstance(current, Mapping):
            continue
        result[metric_id] = {
            "value": None,
            "unit": current.get("unit"),
            "status": "unavailable",
            "reason": reason,
        }
    return result
