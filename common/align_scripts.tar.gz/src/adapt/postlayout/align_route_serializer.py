"""Serialize ALIGN route JSON into the R6 provenance geometry contract.

ALIGN's final GDS JSON does not retain signal-net ownership.  The global-router
JSON does retain ``net_name`` and layer rectangles (including connected pin
rectangles), so it is the first observable signal source that can be measured
without guessing net classes.  ALIGN's PR GDS is separately tagged as power
route/grid provenance when supplied.  The resulting artifact remains
provisional unless signal and power come from one complete detail-route source.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable, Mapping


class AlignRouteSerializationError(ValueError):
    pass


DEFAULT_POWER_ALIASES = frozenset({"VDD", "VCC", "VPWR", "AVDD", "DVDD"})
DEFAULT_GROUND_ALIASES = frozenset({"VSS", "GND", "VGND", "AVSS", "DVSS"})


def _load_json(path: str | Path) -> Mapping[str, Any]:
    payload = json.loads(Path(path).read_text())
    if not isinstance(payload, Mapping):
        raise AlignRouteSerializationError(f"{path} must contain a JSON object")
    return payload


def _layer_table(layers: Mapping[str, Any]) -> tuple[dict[int, str], dict[str, float]]:
    by_gds: dict[int, str] = {}
    widths_um: dict[str, float] = {}
    for item in layers.get("Abstraction", []):
        if not isinstance(item, Mapping) or "Layer" not in item:
            continue
        name = str(item["Layer"])
        gds = item.get("GdsLayerNo")
        if isinstance(gds, int):
            by_gds[gds] = name
        if name.startswith("M") and "Width" in item:
            width = float(item["Width"])
            # ALIGN mock rules use nm coordinates and nm widths.  The metric
            # contract stores widths in um, so convert once here.
            widths_um[name] = width / 1000.0
    return by_gds, widths_um


def _rect(value: Any) -> list[float] | None:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return None
    try:
        x0, y0, x1, y1 = (float(v) for v in value)
    except (TypeError, ValueError):
        return None
    if x1 <= x0 or y1 <= y0:
        return None
    return [x0, y0, x1, y1]


def _boundary_rect(xy: Any) -> list[float] | None:
    """Convert a closed axis-aligned GDS boundary to its rectangle."""
    if not isinstance(xy, list) or len(xy) < 8 or len(xy) % 2:
        return None
    points = [(float(xy[i]), float(xy[i + 1])) for i in range(0, len(xy), 2)]
    # GDS JSON repeats the first point at the end.  Reject non-rectilinear
    # polygons rather than silently taking their bounding box.
    if points[0] == points[-1]:
        points = points[:-1]
    xs = {p[0] for p in points}
    ys = {p[1] for p in points}
    if len(xs) != 2 or len(ys) != 2:
        return None
    rect = [min(xs), min(ys), max(xs), max(ys)]
    return _rect(rect)


def _gds_diagnostics(gds_json: str | Path, by_gds: Mapping[int, str]) -> tuple[list[dict[str, Any]], int, dict[str, Any]]:
    payload = _load_json(gds_json)
    records: list[dict[str, Any]] = []
    unsupported = 0
    boundary_count = 0
    metal_boundary_count = 0
    net_label_count = 0
    metal_by_layer: dict[str, int] = {}
    for lib in payload.get("bgnlib", []):
        if not isinstance(lib, Mapping):
            continue
        for structure in lib.get("bgnstr", []):
            if not isinstance(structure, Mapping):
                continue
            for element in structure.get("elements", []):
                if not isinstance(element, Mapping) or element.get("type") != "boundary":
                    if isinstance(element, Mapping) and element.get("type") == "text" and element.get("string"):
                        net_label_count += 1
                    continue
                boundary_count += 1
                layer_num = element.get("layer")
                layer = by_gds.get(layer_num)
                if layer and layer.startswith("M"):
                    metal_boundary_count += 1
                    metal_by_layer[layer] = metal_by_layer.get(layer, 0) + 1
                if not layer or not layer.startswith("V") or layer == "V0":
                    continue
                rect = _boundary_rect(element.get("xy"))
                if rect is None:
                    unsupported += 1
                    continue
                records.append(
                    {
                        "kind": "cut",
                        "layer": layer,
                        "rect": rect,
                        "source": f"ALIGN:GDS:{Path(gds_json).name}:layer{layer_num}",
                        "source_kind": "final_gds_cut",
                    }
                )
    return records, unsupported, {
        "boundary_count": boundary_count,
        "metal_boundary_count": metal_boundary_count,
        "net_label_count": net_label_count,
        "metal_boundary_by_layer": metal_by_layer,
    }


def _gds_power_records(gds_json: str | Path, by_gds: Mapping[int, str]) -> tuple[list[dict[str, Any]], int]:
    """Read power-only M/V geometry from ALIGN's ``*_PR_*.gds.json``.

    ``router.py`` calls ``WriteJSON`` with ``includePowerNet=True`` and
    ``includePowerGrid=True`` for PR output.  The file does not carry net names,
    but its stage provenance is unambiguous, so every M/V boundary is tagged as
    power geometry.  Non-rectilinear boundaries are rejected rather than
    approximated.
    """
    payload = _load_json(gds_json)
    records: list[dict[str, Any]] = []
    unsupported = 0
    for lib in payload.get("bgnlib", []):
        for structure in lib.get("bgnstr", []) if isinstance(lib, Mapping) else []:
            for element in structure.get("elements", []) if isinstance(structure, Mapping) else []:
                if not isinstance(element, Mapping) or element.get("type") != "boundary":
                    continue
                layer = by_gds.get(element.get("layer"), "")
                if not (layer.startswith("M") or (layer.startswith("V") and layer != "V0")):
                    continue
                rect = _boundary_rect(element.get("xy"))
                if rect is None:
                    unsupported += 1
                    continue
                records.append({
                    "kind": "metal" if layer.startswith("M") else "cut",
                    "layer": layer,
                    "rect": rect,
                    "net_class": "power" if layer.startswith("M") else None,
                    "source": f"ALIGN:PowerRouteGDS:{Path(gds_json).name}",
                    "source_kind": "power_route_or_grid",
                })
    return records, unsupported


def _net_class(net_name: str, power_aliases: set[str], ground_aliases: set[str]) -> str:
    normalized = net_name.strip().upper()
    if normalized in power_aliases:
        return "power"
    if normalized in ground_aliases:
        return "ground"
    return "signal"


def serialize_global_route(
    route_json: str | Path,
    top_json: str | Path,
    layers_json: str | Path,
    *,
    gds_json: str | Path | None = None,
    power_gds_json: str | Path | None = None,
    power_aliases: Iterable[str] = DEFAULT_POWER_ALIASES,
    ground_aliases: Iterable[str] = DEFAULT_GROUND_ALIASES,
) -> dict[str, Any]:
    """Return a canonical R6 artifact from one ALIGN global-route result.

    A route wire contributes its positive rectangle and every positive
    ``connected_pins`` rectangle.  Zero-area route anchors are intentionally
    ignored.  Via geometry is not present in this ALIGN file and therefore
    cannot be fabricated; the artifact records ``via_provenance=unavailable``.
    """

    route = _load_json(route_json)
    top = _load_json(top_json)
    layers = _load_json(layers_json)
    by_gds, widths_um = _layer_table(layers)
    p_alias = {str(v).strip().upper() for v in power_aliases}
    g_alias = {str(v).strip().upper() for v in ground_aliases}
    bbox = top.get("bbox")
    if not isinstance(bbox, list) or len(bbox) != 4:
        raise AlignRouteSerializationError("top JSON must contain bbox=[x0,y0,x1,y1]")

    records: list[dict[str, Any]] = []
    wires = route.get("wires")
    if not isinstance(wires, list):
        raise AlignRouteSerializationError("route JSON must contain a wires list")
    for wi, wire in enumerate(wires):
        if not isinstance(wire, Mapping):
            continue
        net = str(wire.get("net_name", ""))
        if not net:
            continue
        layer = wire.get("layer")
        if not isinstance(layer, str):
            continue
        net_class = _net_class(net, p_alias, g_alias)
        candidates: list[tuple[str, Any, str]] = [("wire", wire.get("rect"), f"wire[{wi}]")]
        pins = wire.get("connected_pins", [])
        if isinstance(pins, list):
            for pi, pin in enumerate(pins):
                if isinstance(pin, Mapping):
                    candidates.append(("connected_pin", pin.get("rect"), f"wire[{wi}].connected_pins[{pi}]"))
        for source_kind, raw_rect, source_id in candidates:
            rect = _rect(raw_rect)
            if rect is None:
                continue
            records.append(
                {
                    "kind": "metal",
                    "layer": layer,
                    "rect": rect,
                    "net": net,
                    "net_class": net_class,
                    "source": f"ALIGN:GcellGlobalRoute:{Path(route_json).name}:{source_id}",
                    "source_kind": source_kind,
                }
            )

    unsupported_gds_boundaries = 0
    gds_diagnostics: dict[str, Any] = {}
    if gds_json is not None:
        cut_records, unsupported_gds_boundaries, gds_diagnostics = _gds_diagnostics(gds_json, by_gds)
        records.extend(cut_records)
    unsupported_power_boundaries = 0
    if power_gds_json is not None:
        power_records, unsupported_power_boundaries = _gds_power_records(power_gds_json, by_gds)
        records.extend(power_records)
    missing_layers = sorted({str(r["layer"]) for r in records if r["kind"] == "metal" and str(r["layer"]) not in widths_um})
    return {
        "schema": "adapt-r6-geometry-artifact-v1",
        "artifact_kind": "global_route_geometry",
        "source_stage": "ALIGN.GcellGlobalRoute",
        "source_file": str(Path(route_json).resolve()),
        "units": "nm",
        "node_boundary": [float(v) for v in bbox],
        "geometry": records,
        "reference_widths_um": widths_um,
        "via_provenance": "unavailable",
        "power_aliases": sorted(p_alias),
        "ground_aliases": sorted(g_alias),
        "missing_layer_widths": missing_layers,
        "record_count": len(records),
        "cut_record_count": sum(r["kind"] == "cut" for r in records),
        "unsupported_gds_boundaries": unsupported_gds_boundaries,
        "final_gds_diagnostics": gds_diagnostics,
        "power_gds_source": None if power_gds_json is None else str(Path(power_gds_json).resolve()),
        "unsupported_power_gds_boundaries": unsupported_power_boundaries,
        "power_provenance": "ALIGN_PR_GDS" if power_gds_json is not None else "unavailable",
    }


def _detail_top_structures(
    payload: Mapping[str, Any],
    gds_json: str | Path,
    top_structure_name: str | None,
) -> tuple[list[Mapping[str, Any]], dict[str, Any]]:
    """Select the physical top structure without flattening primitive SREFs.

    ALIGN final GDS stores primitive cells and the routed top cell in one
    library.  Primitive boundaries are local coordinates and are referenced by
    SREF; counting them directly would double count geometry and would ignore
    their transforms.  The routed top structure is identified by its exact
    name, then by the largest-SREF structure as a deterministic fallback.
    """
    structures = [
        structure
        for lib in payload.get("bgnlib", [])
        if isinstance(lib, Mapping)
        for structure in lib.get("bgnstr", [])
        if isinstance(structure, Mapping)
    ]
    expected = top_structure_name
    if expected is None:
        name = Path(gds_json).name
        expected = name[:-len(".gds.json")] if name.endswith(".gds.json") else Path(name).stem
    exact = [s for s in structures if str(s.get("strname", "")) == expected]
    if exact:
        chosen = exact
        method = "exact_strname"
    elif len(structures) == 1:
        chosen = structures
        method = "sole_structure_fixture"
    elif structures:
        # The top routed cell normally has the most SREFs.  Require a unique
        # maximum; an ambiguous fallback must remain unavailable, never guessed.
        counts = [sum(e.get("type") == "sref" for e in s.get("elements", []) if isinstance(e, Mapping)) for s in structures]
        maximum = max(counts)
        indices = [i for i, count in enumerate(counts) if count == maximum]
        chosen = [structures[indices[0]]] if maximum > 0 and len(indices) == 1 else []
        method = "unique_max_sref" if chosen else "ambiguous_structure_selection"
    else:
        chosen = []
        method = "no_structure"
    return chosen, {
        "requested_name": expected,
        "selected_names": [str(s.get("strname", "")) for s in chosen],
        "method": method,
        "all_structure_count": len(structures),
        "primitive_structures_omitted": max(0, len(structures) - len(chosen)),
    }


def serialize_detail_gds(
    gds_json: str | Path,
    top_json: str | Path,
    layers_json: str | Path,
    *,
    top_structure_name: str | None = None,
) -> dict[str, Any]:
    """Serialize only the routed ALIGN top structure's final geometry.

    Primitive cells remain hierarchy children and are intentionally omitted:
    their local coordinates are not final physical coordinates until SREF
    transforms are applied.  The top structure contains route/power metal and
    via boundaries emitted by the ownership patch.  Unknown top-level
    boundaries are retained and make the artifact ``partial_unavailable``.
    """

    payload = _load_json(gds_json)
    top = _load_json(top_json)
    layers = _load_json(layers_json)
    by_gds, widths_um = _layer_table(layers)
    bbox = top.get("bbox")
    if not isinstance(bbox, list) or len(bbox) != 4:
        raise AlignRouteSerializationError("top JSON must contain bbox=[x0,y0,x1,y1]")
    structures, selection = _detail_top_structures(payload, gds_json, top_structure_name)
    records: list[dict[str, Any]] = []
    metal_total = owned_metal = cut_total = owned_cut = 0
    for structure in structures:
        for element in structure.get("elements", []):
            if not isinstance(element, Mapping) or element.get("type") != "boundary":
                continue
            layer = by_gds.get(element.get("layer"), "")
            rect = _boundary_rect(element.get("xy"))
            if rect is None:
                continue
            source = f"ALIGN:WriteJSON:{Path(gds_json).name}:{structure.get('strname', 'unknown')}"
            has_owner = any(key in element for key in ("net_name", "net_class", "net"))
            if layer.startswith("V") and layer != "V0":
                cut_total += 1
                owned_cut += int(has_owner)
                records.append({"kind": "cut", "layer": layer, "rect": rect,
                                "source": source, "source_kind": "final_gds_cut"})
                continue
            if not layer.startswith("M"):
                continue
            source_kind_field = str(element.get("source_kind", ""))
            is_pin_contact = source_kind_field == "pin_contact"
            if not is_pin_contact:
                metal_total += 1
            net_class = element.get("net_class")
            net_name = element.get("net_name") or element.get("net")
            if net_class in {"signal", "power", "ground"} and not is_pin_contact:
                owned_metal += 1
                source_kind = "final_gds_owned"
            else:
                net_class = "unknown"
                source_kind = "pin_contact" if is_pin_contact else "final_gds_unowned"
            records.append({"kind": "metal", "layer": layer, "rect": rect,
                            "net": None if net_name is None else str(net_name),
                            "net_class": net_class, "source": source,
                            "source_kind": source_kind})
    coverage = {
        "metal_total": metal_total,
        "metal_owned": owned_metal,
        "metal_ownership_fraction": owned_metal / metal_total if metal_total else 0.0,
        "cut_total": cut_total,
        "cut_owned": owned_cut,
        "ownership_complete": bool(metal_total and owned_metal == metal_total and cut_total == owned_cut),
    }
    eligible = bool(structures) and coverage["ownership_complete"]
    return {
        "schema": "adapt-r6-detail-gds-geometry-v1",
        "artifact_kind": "detail_route_geometry",
        "source_stage": "ALIGN.WriteJSON.final.top_structure",
        "source_file": str(Path(gds_json).resolve()),
        "units": "nm",
        "node_boundary": [float(v) for v in bbox],
        "geometry": records,
        "reference_widths_um": widths_um,
        "via_provenance": "final_gds_boundary_layers",
        "structure_selection": selection,
        "ownership_coverage": coverage,
        "record_count": len(records),
        "metric_eligibility": "eligible" if eligible else "partial_unavailable",
    }


def serialize_global_route_files(
    route_json: str | Path,
    top_json: str | Path,
    layers_json: str | Path,
    output_json: str | Path,
    **kwargs: Any,
) -> dict[str, Any]:
    artifact = serialize_global_route(route_json, top_json, layers_json, **kwargs)
    Path(output_json).write_text(json.dumps(artifact, indent=2) + "\n")
    return artifact
