"""Narrow qualification of known mock Rvt diagnostic reclassification.

This is not FEOL DRC. Every affected marker must match its generator's Active
rectangle; unrelated VT layers or ambiguous geometry fail qualification.
"""
import hashlib
import json
from pathlib import Path

EXPECTED_PATCH_SHA256='08e853169bdeff0e579fd85a381c0bbfe8cef7d3a99d7032f173bfc0fcdf8d52'
VT={'Rvt','Lvt','Hvt','Slvt'}


def qualify_mock_marker_patch(top_json, pdk_path, patch_path):
    if patch_path is None:
        return {'status':'not_required','reason':'no_python_checker_patch'}
    patch=Path(patch_path);pdk_path=Path(pdk_path)
    report={'status':'blocked','patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),
            'physical_signoff':False,'policy':'rvt_active_correspondence_v1'}
    if report['patch_sha256']!=EXPECTED_PATCH_SHA256:
        return {**report,'reason':'unqualified_python_patch'}
    if pdk_path.name not in {'Bulk65nm_Mock_PDK','FinFET14nm_Mock_PDK'}:
        return {**report,'reason':'unqualified_mock_pdk'}
    path=Path(top_json)
    if not path.is_file():return {**report,'reason':'missing_final_top_json'}
    payload=json.loads(path.read_text());layers_path=pdk_path/'layers.json';pdk=json.loads(layers_path.read_text())
    enclosure=next((r.get('active_enclosure') for r in pdk['Abstraction'] if r.get('Layer')=='Active'),None)
    if enclosure is None:return {**report,'reason':'missing_generator_enclosure'}
    terminals=payload.get('terminals',[])
    markers=[t for t in terminals if t.get('layer') in VT]
    actives=[t.get('rect') for t in terminals if t.get('layer')=='Active']
    report.update(top_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                  pdk_layers_sha256=hashlib.sha256(layers_path.read_bytes()).hexdigest(),
                  marker_count=len(markers),active_enclosure=enclosure)
    for i,m in enumerate(markers):
        if m.get('layer')!='Rvt':return {**report,'reason':'unqualified_vt_layer','marker':m}
        if m.get('netName') is not None or m.get('netType')!='drawing':
            return {**report,'reason':'named_or_nondrawing_marker','marker':m}
        x0,y0,x1,y1=m['rect'];expected=[x0,y0+enclosure,x1,y1-enclosure]
        if actives.count(expected)!=1:return {**report,'reason':'nonunique_active_correspondence','marker':m}
        for previous in markers[:i]:
            a=previous['rect']
            if max(x0,a[0])<min(x1,a[2]) and max(y0,a[1])<min(y1,a[3]):
                return {**report,'reason':'overlapping_markers'}
    return {**report,'status':'qualified_mock_diagnostic','reason':'only_supported_rvt_shapes_or_no_affected_markers'}
