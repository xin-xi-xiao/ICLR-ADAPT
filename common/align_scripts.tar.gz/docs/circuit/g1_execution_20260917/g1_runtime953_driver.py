"""Isolated, fail-closed use of the S0-frozen runtime; never rebuild it.

The old private runtime and off-contract runs remain intact.  This driver
checks all S0 Python/native files before launching, not just the binary.
"""
from pathlib import Path
import hashlib
import json
import os
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RUNTIME = HERE / 'runtime_953/pythonpath'
NATIVE_SHA = '953242f473f836d0c4317a01a767f96fe3c44e7bbb351e9f4aaa0c8647fd7e52'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def verify_runtime():
    frozen = json.loads((HERE / 'runtime_manifest.json').read_text())
    mismatch = [x['path'] for x in frozen['copied_runtime_files']
                if not (RUNTIME / x['path']).is_file()
                or sha(RUNTIME / x['path']) != x['sha256']]
    if mismatch:
        raise RuntimeError('Frozen runtime mismatch: ' + repr(mismatch))
    return {'native_sha256': NATIVE_SHA, 'verified_files': len(frozen['copied_runtime_files']),
            'pythonpath': str(RUNTIME), 'manifest_sha256': sha(HERE / 'runtime_manifest.json')}


def install():
    evidence = verify_runtime()
    sys.path.insert(0, str(HERE))
    import runtime_setup
    import run_qualification
    original_environment = runtime_setup.environment

    def environment():
        verify_runtime()
        env = original_environment()
        env.update(PYTHONPATH=os.pathsep.join(map(str, [RUNTIME, ROOT / 'src', HERE])),
                   PYTHONDONTWRITEBYTECODE='1')
        return env

    # These are private launcher globals, not ALIGN parser/router/checker code.
    runtime_setup.PYTHONPATH = RUNTIME
    runtime_setup.environment = environment
    run_qualification.PYTHONPATH = RUNTIME
    run_qualification.environment = environment
    run_qualification.setup = verify_runtime
    original_phase = run_qualification.phase

    def phase(pair, name, flow, timeout=1200):
        actual = dict(pair)
        stage = run_qualification.resource_phase(name)
        limit = pair.get('_stage_address_space_gib', {}).get(stage)
        if limit is not None:
            actual['_address_space_limit_gib'] = limit
        return original_phase(actual, name, flow, timeout)

    run_qualification.phase = phase
    return evidence


if __name__ == '__main__':
    install()
    import run_qualification
    run_qualification.main()
