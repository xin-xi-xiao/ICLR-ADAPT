"""Staged, resumable reference qualification queue. All mutations stay here."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse, json, os, shutil, signal, subprocess, time, traceback, fcntl
from contextlib import contextmanager
from runtime_setup import ROOT, HERE, PYTHON, PYTHONPATH, setup, environment, sha

HIGHMEM_RESOURCE_RECOVERY_API='exclusive80-v1'
ACTIVE_MEMORY_SCHEDULER=None

def resource_phase(name):
    return name if name in ('compile','primitives','placement') else 'routing'

@contextmanager
def scheduled_admission(pair,name,limit):
    if ACTIVE_MEMORY_SCHEDULER is None:
        with phase_admission(limit) as inherited:yield inherited,None
    else:
        with ACTIVE_MEMORY_SCHEDULER.acquire(resource_phase(name),reserve_gib=limit,
                tag=f"{pair['case_id']}/{pair['pdk']}/{name}",
                profile_name=pair.get('_memory_profile_name')) as lease:
            yield lease.pass_fds,lease.metadata

def run_directory(pair):
    result = HERE / pair.get('_runset', 'runs') / pair['case_id'] / pair['pdk']
    if not result.resolve().is_relative_to(HERE): raise ValueError('runset outside selected')
    return result

def save(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(obj, indent=2, default=str) + '\n'); temp.replace(path)

@contextmanager
def align_slot():
    """One host-wide cooperative cap of TWO ALIGN children across runsets."""
    directory=HERE/'runtime/concurrency';directory.mkdir(parents=True,exist_ok=True)
    handle=None
    while handle is None:
        # Earlier unguarded invocations consume capacity until they drain.
        legacy=[]
        for status in HERE.glob('runs*/*/*/current_status.json'):
            try: row=json.loads(status.read_text())
            except (OSError,ValueError):continue
            if row.get('status')=='running' and row.get('resource_guard')!='global_two_ALIGN_processes_v1':legacy.append(status)
        capacity=max(0,2-len(legacy))
        if capacity==0:time.sleep(1);continue
        available=next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
        if available < 48*1024**2:time.sleep(1);continue
        for index in range(capacity):
            candidate=(directory/f'slot{index}.lock').open('a+')
            try:fcntl.flock(candidate.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);handle=candidate;break
            except BlockingIOError:candidate.close()
        if handle is None:time.sleep(.5)
    try:yield
    finally:fcntl.flock(handle.fileno(),fcntl.LOCK_UN);handle.close()

@contextmanager
def phase_admission(address_space_gib):
    if address_space_gib==40:
        with align_slot():yield ()
        return
    if address_space_gib!=80:raise ValueError('Qualification memory profile must be 40 or exclusive 80 GiB')
    directory=HERE/'runtime/concurrency';directory.mkdir(parents=True,exist_ok=True)
    held=[]
    while not held:
        available=next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
        if available<96*1024**2:time.sleep(1);continue
        candidates=[]
        for index in range(2):
            handle=(directory/f'slot{index}.lock').open('a+')
            try:fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:handle.close();break
            candidates.append(handle)
        if len(candidates)==2:
            available=next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
            if available>=96*1024**2:held=candidates;break
        for handle in candidates:handle.close()
        time.sleep(.5)
    try:yield tuple(handle.fileno() for handle in held)
    finally:
        # Child inherits both descriptors; an unexpected launcher exit cannot
        # release its reservation while the actual native process remains alive.
        for handle in held:handle.close()

def monitored_wait(proc,timeout):
    start=time.monotonic();peak=0;samples=0
    while proc.poll() is None:
        try:
            data=Path(f'/proc/{proc.pid}/status').read_text()
            rss=[int(line.split()[1]) for line in data.splitlines() if line.startswith(('VmRSS:','VmHWM:'))]
            peak=max([peak]+rss);samples+=1
        except (OSError,ValueError):pass
        if time.monotonic()-start>timeout:raise subprocess.TimeoutExpired(proc.args,timeout)
        try:proc.wait(timeout=.5)
        except subprocess.TimeoutExpired:pass
    return proc.returncode,{'sampled_max_rss_kib':peak,'samples':samples,'sampling_interval_s':.5}

def phase(pair, name, flow, timeout=1200):
    pairdir = run_directory(pair)
    pairdir.mkdir(parents=True, exist_ok=True)
    record = pairdir / f'{name}.json'
    if record.exists():
        return json.loads(record.read_text())
    work = pairdir / 'work'
    work.mkdir(exist_ok=True)
    pdk = pairdir / 'pdk'
    if not pdk.exists():
        shutil.copytree(ROOT / pair['pdk_path'], pdk)
        if pair.get('_restore_original_layers_from'):
            original=json.loads((ROOT/pair['_restore_original_layers_from']).read_text())
            save(pdk/'layers.json',original['pdk'])
        if pair.get('_stacked_diffusion_fix'):
            from pdk_fixes.stacked_diffusion_fix import apply_stacked_diffusion_fix
            apply_stacked_diffusion_fix(pdk)
    isolated_input = pairdir / 'input'
    if not isolated_input.exists():
        shutil.copytree(ROOT / pair['input_dir'], isolated_input)
        save(pairdir / 'input_manifest.json', pair)
    env = environment()
    runtime_path=ROOT/pair['_runtime_pythonpath'] if pair.get('_runtime_pythonpath') else PYTHONPATH
    if not runtime_path.resolve().is_relative_to(HERE.resolve()):raise ValueError('Private runtime outside selected')
    env['PYTHONPATH']=os.pathsep.join(map(str,[runtime_path,ROOT/'src',HERE]))
    envfile = pairdir / 'native_environment.json'
    if envfile.exists(): env.update(json.loads(envfile.read_text()))
    cmd = [str(PYTHON), str(ROOT / 'ALIGN-public/bin/schematic2layout.py'),
           str(isolated_input), '-p', str(pdk), '-w', str(work), '-s', pair['top'],
           '-n', '1', '-e', '0', '--nroutings', '1', '--lambda_coeff', '1', '--seed', '1']
    # A rescue may choose a globally fixed placer effort.  This is deliberately
    # a pair-independent runtime control (never a circuit-name special case)
    # and is recorded in the phase command for reproducibility.
    if pair.get('_placer_sa_iterations') is not None:
        cmd += ['--placer_sa_iterations', str(int(pair['_placer_sa_iterations']))]
    cmd += flow
    out = pairdir / f'{name}.stdout.log'; err = pairdir / f'{name}.stderr.log'
    start = time.time()
    as_gib=int(pair.get('_address_space_limit_gib',40))
    if ACTIVE_MEMORY_SCHEDULER is not None:
        as_gib=int(pair.get('_stage_address_space_gib',{}).get(resource_phase(name),as_gib))
    elif as_gib not in (40,80):raise ValueError('Unsupported qualification memory profile')
    execution_cmd=['/usr/bin/prlimit','--as='+str(as_gib*1024**3),'--',*cmd]
    row = {'phase': name, 'command': cmd, 'execution_command':execution_cmd,
           'address_space_limit_gib':as_gib, 'status': 'running', 'start_epoch': start,
           'stdout': str(out), 'stderr': str(err), 'timeout_s': timeout,
           'reference_sha256': sha(ROOT / 'docs/param/reference_vector_35d.json')}
    consumer_files = list((work/'3_pnr/inputs').glob('*.pnr.const.json')) + [work/'3_pnr/inputs/layers.json',
        work/'3_pnr/inputs'/f"{pair['top']}.verilog.json",work/'3_pnr/__placer_dump__.json',pdk/'layers.json']
    row['consumer_files_at_launch'] = {str(p):sha(p) for p in consumer_files if p.is_file()}
    row['native_environment_at_launch'] = {k:v for k,v in env.items() if k.startswith('ADAPT_R6_')}
    row['runtime_pythonpath']=str(runtime_path)
    row['runtime_module_sha256'] = sha(runtime_path/'align/PnR.cpython-312-x86_64-linux-gnu.so')
    row['runtime_python_source_sha256']={str(p):sha(p) for p in [runtime_path/'align/pnr/placer.py',runtime_path/'align/pnr/render_placement.py',runtime_path/'align/pnr/public_payload_copy.py'] if p.is_file()}
    row.update(status='waiting_for_resource',resource_guard='weighted_88gib_public_clone_v2' if ACTIVE_MEMORY_SCHEDULER is not None else 'global_two_ALIGN_processes_v1' if as_gib==40 else HIGHMEM_RESOURCE_RECOVERY_API)
    save(pairdir/'current_status.json',row)
    with scheduled_admission(pair,name,as_gib) as (inherited_slots,admission_receipt), out.open('w') as fo, err.open('w') as fe:
        start=time.time();row.update(status='running',start_epoch=start)
        row['memory_admission']=admission_receipt
        save(pairdir/'current_status.json',row)
        proc = subprocess.Popen(execution_cmd, cwd=pairdir, env=env, stdout=fo, stderr=fe, start_new_session=True,pass_fds=inherited_slots)
        row['pid_in_launcher_namespace']=proc.pid
        row['host_mem_available_kib_at_start']=next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
        save(pairdir/'current_status.json',row)
        try:
            rc, memory = monitored_wait(proc,timeout)
            row.update(returncode=rc, status='completed' if rc == 0 else 'failed',memory=memory)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired: os.killpg(proc.pid, signal.SIGKILL); proc.wait()
            row.update(returncode=proc.returncode, status='timeout')
    row['duration_s'] = time.time() - start
    row['log_tail'] = (err.read_text(errors='replace') + out.read_text(errors='replace'))[-5000:]
    save(record, row); save(pairdir / 'current_status.json', row)
    print(f"{pair['case_id']} {pair['pdk']} {name}: {row['status']} {row['duration_s']:.1f}s", flush=True)
    return row

def run_pair(pair, stop, timeout):
    if pair['status'] != 'adapted_pending_ALIGN': return {'pair': pair, 'status': pair['status']}
    signed = run_directory(pair)/'reference_binding_audit.json'
    if signed.exists(): return json.loads(signed.read_text())
    row = phase(pair, 'compile', ['--flow_stop', '1_topology'], timeout)
    if row['status'] != 'completed' or stop == 'compile': return row
    from grouped35_dispatch import bind_compiled
    pairdir = run_directory(pair)
    work, pdk = pairdir / 'work', pairdir / 'pdk'
    tp = work / '1_topology' / f"{pair['top']}.verilog.json"
    lp = work / '1_topology/__primitives_library__.json'
    pp = pdk / 'layers.json'
    cache = pairdir / 'grouped35_native_baseline.json'
    if not cache.exists():
        save(cache, {'top': pair['top'], 'pdk_dir': str(pdk), 'topology': json.loads(tp.read_text()),
                     'primitive_library': json.loads(lp.read_text()), 'pdk': json.loads(pp.read_text())})
    base = json.loads(cache.read_text())
    result = bind_compiled(base['topology'], base['primitive_library'], base['pdk'],
                           top=pair['top'], pdk_name={'65nm':'Bulk65nm_Mock_PDK','45nm':'Bulk45nm_Mock_PDK','14nm':'FinFET14nm_Mock_PDK'}[pair['pdk']])
    save(tp, result['topology']); save(lp, result['primitive_library']); save(pp, result['pdk'])
    save(pairdir / 'before_primitives_binding.json', result['receipt'])
    row = phase(pair, 'primitives', ['--flow_start', '2_primitives', '--flow_stop', '2_primitives'], timeout)
    if row['status'] != 'completed' or stop == 'primitives': return row
    from grouped35_dispatch import dispatch_files
    from adapt.action_space.native_tuning_config import NativeTuningConfig
    from adapt.action_space.native_r089_consumer_receipt import freeze_r09_unit_r, detail_environment
    from adapt.action_space.native_power_consumer_receipt import freeze_power_pitch, power_environment
    bound = dispatch_files(work, pdk, top=pair['top'], output_dir=pairdir,
        pdk_name={'65nm':'Bulk65nm_Mock_PDK','45nm':'Bulk45nm_Mock_PDK','14nm':'FinFET14nm_Mock_PDK'}[pair['pdk']], stage='after_primitives', ordinary_power_flow=True, apply=True)
    # Independent original resource intervals; normalized R09/W08 are not native defaults.
    frozen_pdk = pairdir / 'frozen_original_layers.json'
    save(frozen_pdk, base['pdk'])
    metals = [r['Layer'] for r in base['pdk']['Abstraction'] if r['Layer'].startswith('M')]
    info = base['pdk']['design_info']
    indices = lambda lo, hi: list(range(metals.index(info[lo]), metals.index(info[hi]) + 1))
    signal_resources = freeze_r09_unit_r(frozen_pdk, indices('bottom_signal_routing_layer', 'top_signal_routing_layer'))
    power_resources = freeze_power_pitch(frozen_pdk, indices('bottom_power_routing_layer', 'top_power_routing_layer'),
        resource_provenance={'policy': 'frozen_original_PDK_design_info_power_hookup_interval', 'before_action': True})
    config = NativeTuningConfig.create(bound['receipt']['native_requests'])
    native_env = {'ADAPT_R6_NATIVE_R05_ST_NUMBER': '5'}
    native_env.update(config.router_environment(['R06', 'R07']))
    native_env.update(detail_environment(config, ['R09'], signal_resources))
    native_env.update(power_environment(config, ['W08', 'W09', 'W10'], power_resources))
    save(pairdir / 'native_environment.json', native_env)
    save(pairdir / 'native_resources.json', {'signal': signal_resources, 'power': power_resources})
    save(pairdir / 'input_manifest.json', pair)
    # Pending hierarchy windows are resolved against routed child interfaces afterwards.
    # Such runs cannot qualify unless final decoded reference equals the executed fields.
    for name, flow in [('placement', ['--flow_start', '3_pnr:prep', '--flow_stop', '3_pnr:place']),
                       ('routing', ['--flow_start', '3_pnr:gui', '--flow_stop', '3_pnr:route'])]:
        row = phase(pair, name, flow, timeout)
        if row['status'] != 'completed': return row
    from qualification_validation import validate_pair
    log_paths = [pairdir / f'{name}.{stream}.log' for name in ('compile','primitives','placement','routing') for stream in ('stdout','stderr')]
    log_paths += list(work.rglob('LOG/align.log')) + list(pairdir.glob('LOG/align.log'))
    result = validate_pair(work, pair['top'], pdk, pairdir / 'validation', align_python=PYTHON,
        pythonpath=row.get('runtime_pythonpath',PYTHONPATH), run_logs={'paths': [str(p) for p in log_paths if p.exists()],
        'returncode': 0, 'power_profile': 'explicit_pdn'}, returncode=0)
    save(pairdir / 'validation_result.json', result)
    print(f"{pair['case_id']} {pair['pdk']} validation: {result['qualification_status']}", flush=True)
    return result

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--manifest', type=Path, default=HERE / 'adaptation_manifest.json')
    ap.add_argument('--jobs', type=int, default=6)
    ap.add_argument('--stop', choices=['compile', 'primitives', 'full'], default='full')
    ap.add_argument('--timeout', type=int, default=1200)
    ap.add_argument('--cases', nargs='*')
    ap.add_argument('--runset', default='runs')
    ap.add_argument('--stacked-diffusion-fix', action='store_true')
    args = ap.parse_args(); setup()
    pairs = json.loads(args.manifest.read_text())['pairs']
    if args.cases: pairs = [p for p in pairs if p['case_id'] in args.cases]
    for p in pairs: p.update(_runset=args.runset, _stacked_diffusion_fix=args.stacked_diffusion_fix)
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = {pool.submit(run_pair, p, args.stop, args.timeout): p for p in pairs}
        for f in as_completed(futures):
            try: f.result()
            except Exception as exc:
                pair = futures[f]
                save(run_directory(pair) / 'orchestrator_error.json',
                     {'error': str(exc), 'traceback': traceback.format_exc()})
                print(pair['case_id'], pair['pdk'], str(exc), flush=True)

if __name__ == '__main__': main()
