"""Flatten final ALIGN GDS hierarchy with recorded, scope-aware net ownership.

Coordinates are composed as rational numbers, then converted to the existing
nm rectangle contract once. Neither GDS labels nor supply-name heuristics are
ownership evidence. Selected placement instance/FA maps and exact primitive
rectangle matches establish the association to each physical instance.

Orthogonal SREF/AREF rotation, reflection and positive magnification are
supported. Nonorthogonal geometry, absolute STRANS flags, paths, unresolved
references and missing ownership remain explicit failures, never bounding-box
approximations. This function does not run ALIGN or modify any input artifact.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Mapping

from adapt.postlayout.align_route_serializer import AlignRouteSerializationError


class AlignHierarchySerializationError(AlignRouteSerializationError):
    pass


def _fraction(value: Any) -> Fraction:
    if isinstance(value, bool):
        raise ValueError("Boolean is not a coordinate")
    return Fraction(str(value))


def _number(value: Fraction) -> int | float:
    return value.numerator if value.denominator == 1 else float(value)


def _read(path: Path) -> Mapping[str, Any]:
    value = json.loads(path.read_text())
    if not isinstance(value, dict):
        raise AlignHierarchySerializationError(f"Expected JSON object: {path}")
    return value


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


_SERIALIZER_SOURCE_SHA256 = _sha(Path(__file__))
_POWER_GRID_ALIAS_POLICY = "ALIGN_WriteJSON_fixed_grid_labels_explicit_global_supply_v1"


@dataclass(frozen=True)
class _Affine:
    a: Fraction = Fraction(1)
    b: Fraction = Fraction(0)
    c: Fraction = Fraction(0)
    d: Fraction = Fraction(1)
    x: Fraction = Fraction(0)
    y: Fraction = Fraction(0)

    def hit(self, point):
        px, py = point
        return self.a * px + self.b * py + self.x, self.c * px + self.d * py + self.y

    def compose(self, child):
        x, y = self.hit((child.x, child.y))
        return _Affine(self.a * child.a + self.b * child.c,
                       self.a * child.b + self.b * child.d,
                       self.c * child.a + self.d * child.c,
                       self.c * child.b + self.d * child.d, x, y)

    def exact(self):
        return [str(v) for v in (self.a, self.b, self.c, self.d, self.x, self.y)]


def _references(element: Mapping[str, Any], unit: Fraction):
    """Yield per-instance transforms; AREF XY already encodes lattice direction.

    GDS AREF endpoints span COLROW counts, not count-1 intervals. Do not apply
    the reference rotation/reflection/magnification to the lattice a second
    time. Parent transforms will subsequently act on every array origin.
    """
    flags = int(element.get("strans", 0))
    if flags & ~0x8000:
        raise ValueError(f"unsupported_strans_flags:{flags}")
    angle = _fraction(element.get("angle", 0)) % 360
    if angle % 90:
        raise ValueError(f"nonorthogonal_reference_angle:{angle}")
    mag = _fraction(element.get("mag", 1))
    if mag <= 0:
        raise ValueError("nonpositive_magnification")
    rotation = {0: (1, 0, 0, 1), 90: (0, -1, 1, 0),
                180: (-1, 0, 0, -1), 270: (0, 1, -1, 0)}[int(angle)]
    a, b, c, d = (mag * v for v in rotation)
    if flags & 0x8000:
        b, d = -b, -d
    xy = [_fraction(v) * unit for v in element.get("xy", [])]
    if element["type"] == "sref":
        if len(xy) != 2:
            raise ValueError("invalid_sref_xy")
        yield _Affine(a, b, c, d, *xy), None
        return
    counts = element.get("colrow")
    if not isinstance(counts, list) or len(counts) != 2 or any(type(v) is not int or v <= 0 for v in counts):
        raise ValueError("invalid_aref_colrow")
    columns, rows = counts
    if len(xy) != 6:
        raise ValueError("invalid_aref_xy")
    if columns * rows > 1_000_000:
        raise ValueError("aref_instance_limit_exceeded")
    for column in range(columns):
        for row in range(rows):
            x = xy[0] + column * (xy[2] - xy[0]) / columns + row * (xy[4] - xy[0]) / rows
            y = xy[1] + column * (xy[3] - xy[1]) / columns + row * (xy[5] - xy[1]) / rows
            yield _Affine(a, b, c, d, x, y), [column, row]


def _rect(xy: Any, unit: Fraction, transform: _Affine):
    if not isinstance(xy, list) or len(xy) < 8 or len(xy) % 2:
        raise ValueError("invalid_boundary_xy")
    points = [transform.hit((_fraction(xy[i]) * unit, _fraction(xy[i + 1]) * unit)) for i in range(0, len(xy), 2)]
    if points[0] == points[-1]:
        points.pop()
    xs, ys = {p[0] for p in points}, {p[1] for p in points}
    if len(xs) == 1 or len(ys) == 1:
        return None  # ALIGN writes zero-area pin-contact placeholders.
    if len(points) != 4 or len(xs) != 2 or len(ys) != 2 or len(set(points)) != 4:
        raise ValueError("nonrectangular_boundary")
    if any(a[0] != b[0] and a[1] != b[1] for a, b in zip(points, points[1:] + points[:1])):
        raise ValueError("diagonal_or_self_crossing_boundary")
    return min(xs), min(ys), max(xs), max(ys)


def _metadata_transform(instance):
    value = instance.get("transformation", {})
    if not all(k in value for k in ("sX", "sY", "oX", "oY")):
        return None
    return _Affine(a=_fraction(value["sX"]), d=_fraction(value["sY"]),
                   x=_fraction(value["oX"]), y=_fraction(value["oY"]))


def serialize_hierarchical_final(gds_json, top_json, layers_json, *, workdir, top):
    """Return the full final hierarchy in the existing metric rectangle schema.

    ``top`` is the logical ALIGN top or its exact selected concrete name. The
    selected top JSON filename identifies a concrete variant when necessary.
    GDS DBU comes from UNITS[1]; ALIGN scaled-placement and primitive JSON
    coordinates are nm. Missing metadata never falls back to a sorted variant.

    ``metric_eligibility`` requires complete geometry and canonical ownership.
    Callers must mask metric arithmetic when it is not ``eligible``; unowned
    rectangles and a per-metric eligibility mask are retained for inspection.
    Net classes describe the recorded ALIGN routing/declaration class, not
    physical supply intent inferred from names such as VCC or VSS.
    """
    gds_json, top_json, layers_json, workdir = map(Path, (gds_json, top_json, layers_json, workdir))
    payload, viewer, layers = (_read(p) for p in (gds_json, top_json, layers_json))
    diagnostics, failures, records, visits, bindings = [], set(), [], [], []
    excluded_layers = Counter()
    inputs = {str(p.resolve()): _sha(p) for p in (gds_json, top_json, layers_json)}

    def issue(code, *, fatal=True, **details):
        diagnostics.append({"code": code, **details})
        if fatal:
            failures.add(code)

    by_gds, widths = {}, {}
    for layer in layers.get("Abstraction", []):
        name, number = layer.get("Layer"), layer.get("GdsLayerNo")
        if isinstance(number, int) and isinstance(name, str):
            if number in by_gds and by_gds[number] != name and (
                    re.fullmatch(r"[MV]\d+", name) or re.fullmatch(r"[MV]\d+", by_gds[number])):
                raise AlignHierarchySerializationError(f"Ambiguous GDS layer {number}")
            by_gds[number] = name
        if isinstance(name, str) and re.fullmatch(r"M\d+", name):
            value = layer.get("Width")
            if isinstance(value, (int, float)) and value > 0:
                widths[name] = float(_fraction(value) / 1000)
            else:
                issue("missing_or_ambiguous_frozen_width", layer=name)

    structures, units = {}, {}
    for library in payload.get("bgnlib", []):
        try:
            unit = _fraction(library["units"][1]) * 1_000_000_000
            if unit <= 0:
                raise ValueError("nonpositive DBU")
        except (KeyError, IndexError, TypeError, ValueError, ZeroDivisionError) as exc:
            raise AlignHierarchySerializationError("GDS requires positive UNITS[1] in meters") from exc
        for structure in library.get("bgnstr", []):
            name = structure.get("strname")
            if not isinstance(name, str) or name in structures:
                raise AlignHierarchySerializationError(f"Invalid or duplicate GDS structure: {name}")
            structures[name], units[name] = structure, unit
    physical_top = str(top) if str(top) in structures else top_json.stem
    if physical_top not in structures or not (physical_top == top or re.fullmatch(re.escape(str(top)) + r"_\d+", physical_top)):
        raise AlignHierarchySerializationError(f"Exact selected top {top!r} unavailable; no fallback selection")

    placement_path = workdir / "3_pnr" / "Results" / f"{physical_top}.scaled_placement_verilog.json"
    placement = _read(placement_path) if placement_path.is_file() else {}
    if placement:
        inputs[str(placement_path.resolve())] = _sha(placement_path)
    modules = {m["concrete_name"]: m for m in placement.get("modules", [])}
    leaves = {m["concrete_name"]: m for m in placement.get("leaves", [])}
    registry_path = workdir / "2_primitives" / "__primitives__.json"
    registry = _read(registry_path) if registry_path.is_file() else {}
    if registry:
        inputs[str(registry_path.resolve())] = _sha(registry_path)
    templates = set(modules) | set(leaves) | set(registry)
    template_by_structure = {}
    for name in structures:
        # ALIGN's recorded WriteJSON convention appends numeric uniqueness
        # suffixes. Name association alone never binds a physical instance:
        # its selected placement transform must match exactly as well.
        candidates = [candidate for candidate in templates if name == candidate or re.fullmatch(re.escape(candidate) + r"(?:_\d+)+", name)]
        template_by_structure[name] = candidates[0] if len(candidates) == 1 else None
    template_by_structure[physical_top] = physical_top

    local_indexes = {}

    def local_index(concrete):
        if concrete in local_indexes:
            return local_indexes[concrete]
        path = workdir / ("2_primitives" if concrete in registry or concrete in leaves else "3_pnr") / f"{concrete}.json"
        index = defaultdict(set)
        if path.is_file():
            value = _read(path)
            inputs[str(path.resolve())] = _sha(path)
            for term in value.get("terminals", []):
                rect = term.get("rect")
                if isinstance(rect, list) and len(rect) == 4:
                    index[(term.get("layer"), tuple(_fraction(v) for v in rect))].add(term.get("netName"))
        local_indexes[concrete] = (index, str(path.resolve()) if path.is_file() else None)
        return local_indexes[concrete]

    # Freeze class evidence from actual top routing or explicit declarations.
    # In signal_only mode VCC/VSS may correctly retain ALIGN class 'signal'.
    root_classes = defaultdict(set)
    class_sources = defaultdict(set)
    for element in structures[physical_top].get("elements", []):
        net, cls = element.get("net_name") or element.get("net"), element.get("net_class")
        if isinstance(net, str) and net and cls in {"signal", "power", "ground"}:
            root_classes[net].add(cls)
            class_sources[net].add("ALIGN.net_class")
    declarations = defaultdict(set)
    for entry in placement.get("global_signals", []):
        cls = {"supply0": "ground", "supply1": "power"}.get(entry.get("formal"))
        if cls and isinstance(entry.get("actual"), str):
            declarations[entry["actual"]].add(cls)
    for constraint in modules.get(physical_top, {}).get("constraints", []):
        cls = {"PowerPorts": "power", "GroundPorts": "ground"}.get(constraint.get("constraint"))
        if cls:
            for net in constraint.get("ports", []):
                declarations[net].add(cls)
    for net, classes in declarations.items():
        # Native WriteJSON labels both supply polarities as "power". A unique
        # explicit supply0/GroundPorts declaration refines that resource class;
        # it does not conflict with it. Signal-vs-supply and contradictory
        # supply declarations remain errors. Keep the refinement in provenance.
        if classes == {"ground"} and root_classes[net] and root_classes[net] <= {"power", "ground"}:
            root_classes[net] = {"ground"}
            class_sources[net].add("ALIGN.power_refined_by_explicit_ground_declaration")
        if root_classes[net] and root_classes[net] != classes:
            issue("root_net_class_conflict", net=net, gds_classes=sorted(root_classes[net]), declared_classes=sorted(classes))
        root_classes[net].update(classes)
        class_sources[net].add("selected_placement.power_declaration")

    # Nets without a routed boundary (for example an input landing directly
    # on a primitive pin) still have authoritative node.Nets membership.
    # Require agreement between loaded PnR topology and selected placement,
    # including an explicit global_signals list, before applying WriteJSON's
    # ordinary-node.Nets -> signal classification. Never infer it from a name.
    root_module = modules.get(physical_top, {})
    grid_aliases = {}
    logical_top = root_module.get("abstract_name", str(top))
    loaded_path = workdir / "3_pnr" / "inputs" / f"{logical_top}.verilog.json"
    if loaded_path.is_file():
        loaded = _read(loaded_path)
        inputs[str(loaded_path.resolve())] = _sha(loaded_path)
        loaded_roots = [m for m in loaded.get("modules", []) if m.get("name") == logical_top]

        def fa_signature(module):
            return {i.get("instance_name"): sorted((e.get("formal"), e.get("actual")) for e in i.get("fa_map", []))
                    for i in module.get("instances", [])}

        matching_topology = len(loaded_roots) == 1 and "global_signals" in loaded and "global_signals" in placement and (
                loaded["global_signals"] == placement["global_signals"] and fa_signature(loaded_roots[0]) == fa_signature(root_module))
        for concrete, selected_module in modules.items():
            candidates = [m for m in loaded.get("modules", []) if m.get("name") == selected_module.get("abstract_name")]
            if len(candidates) != 1 or fa_signature(candidates[0]) != fa_signature(selected_module):
                matching_topology = False
                issue("loaded_topology_placement_fa_map_mismatch", concrete_module=concrete)
        if not matching_topology:
            issue("loaded_topology_placement_provenance_mismatch", file=str(loaded_path.resolve()))
        if matching_topology:
            global_nets = {g.get("actual") for g in loaded["global_signals"]}
            actual_nets = global_nets | set(loaded_roots[0].get("parameters", [])) | {
                e.get("actual") for i in loaded_roots[0].get("instances", []) for e in i.get("fa_map", [])}
            # WriteJSON's node.Vdd/node.Gnd branches emit literal VDD/GND,
            # unlike PowerNets, which emit the actual net name. Resolve only
            # those source-defined grid labels, with explicit unique global
            # supply identity and no real net having the reserved label.
            for label, formal, cls in (("GND", "supply0", "ground"), ("VDD", "supply1", "power")):
                targets = {g.get("actual") for g in loaded["global_signals"] if g.get("formal") == formal}
                if label not in actual_nets and len(targets) == 1:
                    target = next(iter(targets))
                    if declarations.get(target) == {cls}:
                        grid_aliases[label] = {"actual_net": target, "net_class": cls,
                            "source_contract": "ALIGN.WriteJSON includePowerGrid node.Gnd/node.Vdd literal labels",
                            "source_locations": ["PlaceRouteHierFlow/PnRDB/WriteJSON.cpp:565-580",
                                                 "PlaceRouteHierFlow/router/PowerRouter.cpp:33-45"],
                            "identity_basis": "matching_loaded_selected_topology_unique_global_supply_and_no_real_label_net"}
            ordinary_nets = {e.get("actual") for i in loaded_roots[0].get("instances", []) for e in i.get("fa_map", [])} - global_nets
            for net in ordinary_nets:
                if isinstance(net, str) and not root_classes[net]:
                    root_classes[net].add("signal")
                    class_sources[net].add("ALIGN.node.Nets_from_loaded_fa_map")
    scoped_classes = defaultdict(set)

    def resolve(local, mapping, path, concrete, primitive=False):
        if not isinstance(local, str) or not local:
            return None
        if local in mapping:
            return mapping[local]
        if not path:
            return local
        if local in declarations:
            return local
        formals = {t.get("name") for t in leaves.get(concrete, {}).get("terminals", [])} if primitive else set(modules.get(concrete, {}).get("parameters", []))
        if local in formals or primitive:
            return None  # Cannot invent a missing primitive formal/actual edge.
        # Qualified internal net identifiers preserve an actually recorded local
        # name and its resolved instance path, not an inferred electrical net.
        return "/".join(path) + "::" + local

    def walk(name, transform, path, mapping, bound=True, ancestry=()):
        if name in ancestry:
            issue("cyclic_reference", structure=name, instance_path=list(path))
            return
        if len(ancestry) > 100:
            issue("hierarchy_depth_limit", structure=name)
            return
        concrete = template_by_structure.get(name)
        module = modules.get(concrete, {})
        primitive = concrete in leaves or concrete in registry
        visits.append({"structure": name, "concrete_template": concrete, "instance_path": list(path), "transform_nm_exact": transform.exact(), "instance_binding_verified": bound})
        consumed = set()
        for index, element in enumerate(structures[name].get("elements", [])):
            kind = element.get("type")
            source = {"file": str(gds_json.resolve()), "structure": name, "element_index": index,
                      "instance_path": list(path), "transform_nm_exact": transform.exact()}
            if kind in {"sref", "aref"}:
                child = element.get("sname")
                if child not in structures:
                    issue("unresolved_reference", child=child, **source)
                    continue
                try:
                    refs = list(_references(element, units[name]))
                except (ValueError, TypeError, ZeroDivisionError) as exc:
                    issue("unsupported_reference_transform", reason=str(exc), **source)
                    continue
                child_concrete = template_by_structure.get(child)
                for local_transform, array_index in refs:
                    candidates = []
                    for instance in module.get("instances", []):
                        if instance.get("concrete_template_name") == child_concrete and _metadata_transform(instance) == local_transform:
                            candidates.append(instance)
                    verified = bound and len(candidates) == 1 and candidates[0].get("instance_name") not in consumed
                    child_mapping = {}
                    if verified:
                        instance = candidates[0]
                        instance_name = instance["instance_name"]
                        consumed.add(instance_name)
                        for entry in instance.get("fa_map", []):
                            formal, actual = entry.get("formal"), entry.get("actual")
                            actual_net = resolve(actual, mapping, path, concrete)
                            if not isinstance(formal, str) or formal in child_mapping and child_mapping[formal] != actual_net:
                                issue("conflicting_formal_actual_mapping", formal=formal, **source)
                                child_mapping[formal] = None
                            else:
                                child_mapping[formal] = actual_net
                    else:
                        instance_name = f"@{kind}[{index}]" + (f"[{array_index[0]},{array_index[1]}]" if array_index else "")
                        issue("missing_unique_instance_binding", child=child, candidate_count=len(candidates),
                              required_fields=["selected_concrete_template", "matching_instance_transform", "fa_map"], **source)
                    child_path = (*path, instance_name)
                    bindings.append({"parent_structure": name, "child_structure": child, "instance_path": list(child_path),
                                     "array_index": array_index, "verified": verified, "canonical_fa_map": child_mapping,
                                     "source": str(placement_path.resolve())})
                    walk(child, transform.compose(local_transform), child_path, child_mapping, verified, (*ancestry, name))
                continue
            layer = by_gds.get(element.get("layer"), "")
            resource = bool(re.fullmatch(r"M\d+", layer) or re.fullmatch(r"V[1-9]\d*", layer))
            if not resource:
                if kind == "boundary":
                    # WriteJSON::addOABoundaries records its nonconducting
                    # instance outline on fixed layer 235, outside the PDK.
                    label = layer or ("ALIGN.OA_boundary" if element.get("layer") == 235 else "unmapped")
                    excluded_layers[label] += 1
                    if label == "unmapped":
                        issue("unmapped_gds_boundary_layer", gds_layer=element.get("layer"), **source)
                continue
            if kind != "boundary":
                if kind in {"path", "box"}:
                    issue("unsupported_resource_element", element_type=kind, layer=layer, **source)
                continue
            try:
                final_rect = _rect(element.get("xy"), units[name], transform)
                local_rect = _rect(element.get("xy"), units[name], _Affine())
            except (ValueError, TypeError, ZeroDivisionError) as exc:
                issue("unsupported_resource_boundary", layer=layer, reason=str(exc), xy=element.get("xy"), **source)
                continue
            if final_rect is None:
                issue("zero_area_boundary_omitted", fatal=False, layer=layer, **source)
                continue
            local_net = element.get("net_name") or element.get("net")
            owner_source = "ALIGN.net_name" if local_net else None
            metadata_path = None
            if not local_net and concrete:
                metadata_index, metadata_path = local_index(concrete)
                names = metadata_index.get((layer, local_rect), set())
                named = {v for v in names if isinstance(v, str) and v}
                if len(named) == 1 and None not in names:
                    local_net = next(iter(named))
                    owner_source = "exact_named_rectangle_metadata"
                elif len(named) > 1:
                    issue("ambiguous_rectangle_ownership", layer=layer, names=sorted(named), **source)
            net = resolve(local_net, mapping, path, concrete, primitive) if bound else None
            alias = grid_aliases.get(local_net) if not path else None
            if alias and element.get("net_class") == alias["net_class"]:
                net = alias["actual_net"]
                source.update(raw_net_name=local_net, raw_net_class=element["net_class"],
                              canonical_power_grid_alias=dict(alias))
                owner_source = "ALIGN.WriteJSON_fixed_grid_label_and_explicit_global_supply"
            if net and element.get("net_class") in {"signal", "power", "ground"}:
                scoped_classes[net].add(element["net_class"])
            classes = root_classes.get(net, set())
            sources = class_sources.get(net, set())
            if not classes and net and element.get("net_class") in {"signal", "power", "ground"}:
                classes, sources = {element["net_class"]}, {"ALIGN.net_class"}
            net_class = next(iter(classes)) if net and len(classes) == 1 else "unknown"
            records.append({"kind": "metal" if layer.startswith("M") else "cut", "layer": layer,
                            "rect": [_number(v) for v in final_rect], "rect_nm_exact": [str(v) for v in final_rect],
                            "net": net, "net_class": net_class, "local_net": local_net,
                            "source": f"ALIGN.final:{gds_json.name}:{name}:{index}:{'/'.join(path)}",
                            "source_kind": "full_layout_final_boundary", "class_source": sorted(sources),
                            "ownership_source": owner_source, "ownership_metadata_file": metadata_path,
                            "provenance": [source], "_exact_key": (layer, final_rect)})
        if bound and module:
            expected = {instance.get("instance_name") for instance in module.get("instances", [])}
            if expected - consumed:
                issue("placement_instances_missing_from_gds", structure=name, instance_path=list(path), missing=sorted(expected - consumed))

    walk(physical_top, _Affine(), (), {})
    # A descendant can supply an explicit class for a net whose parent has no
    # routed rectangle. Resolve this only after all verified instance maps are
    # composed, so traversal order does not affect ownership.
    for record in records:
        net = record["net"]
        classes = root_classes.get(net, set()) or scoped_classes.get(net, set())
        if net and len(classes) == 1:
            record["net_class"] = next(iter(classes))
            record["class_source"] = sorted(class_sources.get(net, set()) or {"ALIGN.net_class"})
            if "ALIGN.node.Nets_from_loaded_fa_map" in record["class_source"] and scoped_classes.get(net) == classes:
                record["class_source"] = sorted(set(record["class_source"]) | {"ALIGN.net_class"})
        else:
            record["net_class"] = "unknown"
            issue("unresolved_boundary_ownership", layer=record["layer"], local_net=record["local_net"], canonical_net=net,
                  missing_fields=(["local_rectangle_net_name"] if not record["local_net"] else []) +
                                 (["canonical_instance_fa_map"] if not net else []) +
                                 (["authoritative_net_class"] if len(classes) != 1 else []), **record["provenance"][0])
    # Exact physical duplicates from via enclosures or copied contacts retain
    # all provenance, but count only once. Conflicting names are never merged
    # into a supposedly known class.
    unique = {}
    for record in records:
        key = record.pop("_exact_key")
        if key not in unique:
            unique[key] = record
            continue
        previous = unique[key]
        previous["provenance"].extend(record["provenance"])
        if (previous["net"], previous["net_class"]) != (record["net"], record["net_class"]):
            issue("duplicate_geometry_ownership_conflict", layer=record["layer"], rect_nm_exact=record["rect_nm_exact"],
                  owners=[previous["net"], record["net"]])
            previous["net"], previous["net_class"] = None, "unknown"
    geometry = list(unique.values())
    counts = Counter(record["kind"] for record in geometry)
    unknown = Counter(record["kind"] for record in geometry if record["net_class"] == "unknown")
    geometry_failure_codes = {"cyclic_reference", "hierarchy_depth_limit", "unresolved_reference", "unsupported_reference_transform",
                              "unsupported_resource_element", "unsupported_resource_boundary", "placement_instances_missing_from_gds",
                              "unmapped_gds_boundary_layer"}
    geometry_complete = not failures.intersection(geometry_failure_codes)
    ownership_complete = not unknown and not failures.intersection({"missing_unique_instance_binding", "root_net_class_conflict", "conflicting_formal_actual_mapping",
                                                                  "loaded_topology_placement_fa_map_mismatch", "loaded_topology_placement_provenance_mismatch"})
    eligible = bool(counts["metal"]) and not failures and geometry_complete and ownership_complete
    bbox = viewer.get("bbox")
    if not isinstance(bbox, list) or len(bbox) != 4 or _fraction(bbox[2]) <= _fraction(bbox[0]) or _fraction(bbox[3]) <= _fraction(bbox[1]):
        raise AlignHierarchySerializationError("Top JSON requires a positive nm bbox")
    return {
        "schema": "adapt-r6-detail-gds-geometry-v1", "serializer_schema": "align-full-hierarchy-v1",
        "artifact_kind": "full_layout_geometry", "full_layout_geometry": True,
        "source_stage": "ALIGN.WriteJSON.final.full_hierarchy", "source_file": str(gds_json.resolve()),
        "units": "nm", "node_boundary": bbox, "geometry": geometry, "record_count": len(geometry),
        "reference_widths_um": widths, "reference_widths_source": {"file": str(layers_json.resolve()), "sha256": _sha(layers_json), "unit": "nm", "frozen": True},
        "via_provenance": "final_hierarchical_gds_boundaries_with_exact_transforms",
        "structure_selection": {"method": "exact_selected_top", "selected_names": [physical_top], "all_structure_count": len(structures),
                                "visited_instance_count": len(visits), "unreachable_definitions": sorted(set(structures) - {v['structure'] for v in visits})},
        "hierarchy_instances": visits, "instance_bindings": bindings, "source_artifact_sha256": inputs,
        "geometry_complete": geometry_complete, "ownership_coverage": {
            "metal_total": counts["metal"], "metal_owned": counts["metal"] - unknown["metal"],
            "cut_total": counts["cut"], "cut_owned": counts["cut"] - unknown["cut"], "ownership_complete": ownership_complete},
        "raw_boundary_record_count": len(records), "duplicate_boundary_count": len(records) - len(geometry),
        "excluded_nonresource_boundary_inventory": dict(excluded_layers),
        "metric_eligibility": "eligible" if eligible else "partial_unavailable",
        "metric_eligibility_mask": {name: eligible for name in ("A_eval", "L_eq_signal", "L_eq_power", "N_cut_intermetal")},
        "eligibility_reasons": sorted(failures), "diagnostics": diagnostics,
        "class_policy": "Recorded ALIGN net_class and frozen power declarations; no supply-name heuristics. Signal-only VCC/VSS can remain signal.",
        "power_grid_aliases": grid_aliases,
        "power_grid_alias_policy": _POWER_GRID_ALIAS_POLICY,
        "serializer_source_sha256": _SERIALIZER_SOURCE_SHA256,
        "limitations": ["Only rectangular resource boundaries and orthogonal relative SREF/AREF transforms are representable in the rectangle metric contract.",
                        "Metadata units follow ALIGN scaled-placement/primitive JSON's nm convention.",
                        "Flow DRC/LVS and parameter-consumer eligibility are separate gates; this artifact establishes geometry/ownership coverage only."],
    }
