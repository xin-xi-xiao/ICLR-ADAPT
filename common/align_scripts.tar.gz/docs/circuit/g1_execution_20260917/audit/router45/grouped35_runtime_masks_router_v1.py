"""Real reference binding and native-operation receipts for grouped35.

This reads one named completed routing invocation, never concatenates reruns,
and never interprets a decoded choice as an experimentally successful choice.
Existing strict protocol auditors run in isolated namespaces with their binary
identity explicitly adapted to the pinned cumulative native-power build.
"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import math
import sys

HERE = Path(__file__).resolve().parents[2]
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(ROOT/'src'))
from grouped35_dispatch import DIMS, REFERENCE, CONTRACT, _write_safe, sha
from adapt.action_space.native_r089_consumer_receipt import freeze_r09_unit_r
from adapt.action_space.native_power_consumer_receipt import freeze_power_pitch

JOINT_SHA = '953242f473f836d0c4317a01a767f96fe3c44e7bbb351e9f4aaa0c8647fd7e52'


def read(path): return json.loads(Path(path).read_text())
def file_sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _auditor(name):
    """No shared source/module globals are modified, even with parallel pairs."""
    path = ROOT/'src/adapt/action_space'/f'{name}.py'
    spec = importlib.util.spec_from_file_location('adapt.action_space._grouped35_' + name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    original = getattr(module, 'MODULE_SHA256', None)
    if original is not None: module.MODULE_SHA256 = JOINT_SHA
    return module, {'auditor_source': str(path), 'source_sha256': file_sha(path),
        'legacy_standalone_binary_sha256': original, 'accepted_cumulative_binary_sha256': JOINT_SHA,
        'policy': 'same versioned native log protocol; explicit cumulative build identity, no bypass of event/config/resource/call checks'}


def _binding_evidence(pair, coords):
    """Check serialized bindings and generated registry, not counterfactual runs."""
    work=pair/'work'
    top=read(pair/'grouped35_native_baseline.json')['top']
    frozen=read(pair/'grouped35_postroute_reference_frozen.json')
    reverse=frozen['source_to_prepared']
    library={x['name']:x for x in read(work/'1_topology/__primitives_library__.json')}
    registry=read(work/'2_primitives/__primitives__.json')
    variants={}
    for concrete,entry in registry.items():variants.setdefault(entry['abstract_template_name'],[]).append((concrete,entry))
    native={name:read(work/'3_pnr/inputs'/f'{name}.pnr.const.json')['constraints'] for name in frozen['prepared_to_original']}
    for row in coords:
        slot=row['parameter_id'];evidence=[]
        if slot in ('P04','P05','P07','P08','R01','R02'):
            for obj in row['objects']:
                source,net=obj['object_id'].split('/',1) if slot=='P08' else (obj['object_id'],None)
                for prepared in reverse.get(source,[]):
                    kind,field={'P04':('bias_Hgraph','distance'),'P05':('bias_Vgraph','distance'),
                        'P07':('Boundary','halo_vertical'),'P08':('CritNet','priority'),
                        'R01':('Route','min_layer'),'R02':('Route','max_layer')}[slot]
                    matches=[c for c in native[prepared] if c['const_name']==kind and (slot!='P08' or c.get('net_name')==net)]
                    value=matches[-1].get(field) if matches else None
                    evidence.append({'object_id':obj['object_id'],'prepared_module':prepared,
                        'consumer_json_value':value,'requested_raw':obj['raw_value'],'serialized_binding_matches':value==obj['raw_value'],
                        'path':str(work/'3_pnr/inputs'/f'{prepared}.pnr.const.json'),
                        'original_compiled_constraint_path':str(work/'1_topology'/f'{top}.verilog.json'),
                        'immutable_baseline_path':str(pair/'grouped35_native_baseline.json')})
        elif slot in ('G01','G02','G04'):
            field={'G01':'height','G02':'legal_sizes','G04':'shared_diff'}[slot]
            for obj in row['objects']:
                primitive=library[obj['object_id']]
                rows=[c for c in primitive['constraints'] if c['constraint']=='Generator']
                value=rows[-1].get('parameters',{}).get(field) if rows else None
                actual=variants.get(obj['object_id'],[])
                geometries=[{'name':n,'x_cells':e.get('x_cells'),'y_cells':e.get('y_cells'),
                    'json_exists':(work/'2_primitives'/f'{n}.json').is_file(),'lef_exists':(work/'2_primitives'/f'{n}.lef').is_file()} for n,e in actual]
                receipt={'object_id':obj['object_id'],'consumer_json_value':value,'requested_raw':obj['raw_value'],
                    'serialized_binding_matches':value==obj['raw_value'],'generated_variants':geometries,
                    'requested_abstract_was_generated':bool(geometries) and all(g['json_exists'] and g['lef_exists'] for g in geometries),
                    'raw_generator_consumption_from_registry':None,
                    'original_generator_path':str(work/'1_topology/__primitives_library__.json'),
                    'generated_registry_path':str(work/'2_primitives/__primitives__.json'),
                    'immutable_baseline_path':str(pair/'grouped35_native_baseline.json')}
                if slot=='G02':
                    allowed={(p['x'],p['y']) for p in obj['raw_value']}
                    receipt['raw_generator_consumption_from_registry']=bool(geometries) and all((g['x_cells'],g['y_cells']) in allowed for g in geometries)
                evidence.append(receipt)
        row['serialized_binding_evidence']=evidence
        row['serialized_binding_mask']=all(e['serialized_binding_matches'] for e in evidence) if evidence else None
        row['binding_scope_status']='inactive_no_eligible_object' if row['object_mask'] is False else (
            'verified_serialized_binding' if row['serialized_binding_mask'] is True else
            'binding_mismatch' if row['serialized_binding_mask'] is False else 'not_observed_by_serialized_binding_auditor')
        row['primitive_generated_mask']=all(e['requested_abstract_was_generated'] for e in evidence) if slot in ('G01','G02','G04') and evidence else None
        row['generator_shape_registry_mask']=all(e['raw_generator_consumption_from_registry'] for e in evidence) if slot=='G02' and evidence else None
    return coords


def collect_runtime_masks(pairdir, *, top, route_phase='routing_reference_v1', output_dir=None):
    pair = Path(pairdir).absolute(); out = Path(output_dir).absolute() if output_dir else pair/route_phase/'mask_audit'
    run = read(pair/f'{route_phase}.json')
    if run.get('returncode') != 0 or run.get('status') != 'completed':
        report = {'status': 'routing_phase_not_completed', 'route_phase': route_phase,
            'runtime_consumer_call_mask': [None]*35, 'runtime_operation_mask': [None]*35}
        _write_safe(out/'grouped35_masks.json', report); return report
    runtime_path = Path(run['runtime_pythonpath']) / 'align/PnR.cpython-312-x86_64-linux-gnu.so'
    runtime = {'module_path': str(runtime_path), 'module_sha256': file_sha(runtime_path)}
    if runtime['module_sha256'] != JOINT_SHA or file_sha(runtime['module_path']) != JOINT_SHA:
        raise ValueError('actual loaded cumulative native binary does not match pinned grouped35 runtime')
    env = read(pair/'native_environment.json'); resources = read(pair/'native_resources.json')
    launch_identity = {'formal_phase': route_phase.startswith('routing_reference')}
    if launch_identity['formal_phase']:
        launch_identity.update(binary_sha_matches=run.get('runtime_module_sha256')==JOINT_SHA,
            reference_sha_matches=run.get('reference_sha256')==file_sha(ROOT/'docs/param/reference_vector_35d.json'),
            native_environment_matches=run.get('native_environment_at_launch')==env)
        if not all(launch_identity.values()):
            raise ValueError('formal routing launch binary, reference or native environment identity changed or missing')
    # An output directory may retain provisional binding.json: prefer the
    # explicit full-window receipt, which records the requested reference.
    binding_path = pair/'grouped35_reference_binding_after_windows.json'
    if not binding_path.exists(): binding_path = pair/'binding.json'
    binding = read(binding_path)
    if (binding.get('vector') != REFERENCE or binding.get('contract_sha256') != sha(CONTRACT)
            or len(binding.get('coordinates',[])) != 35
            or any(len(binding.get(k,[])) != 35 for k in ('object_mask','choice_mask'))
            or [c.get('name') for c in binding['coordinates']] != [d['name'] for d in DIMS]
            or any(v is not None and type(v) is not bool for k in ('object_mask','choice_mask') for v in binding[k])):
        raise ValueError('frozen 35D reference, coordinate order or tri-state mask schema mismatch')
    selected_id = top+'_0'
    place = read(pair/'work/3_pnr/Results'/f'{selected_id}.scaled_placement_verilog.json')
    modules = {m['concrete_name']: m for m in place['modules']}; reached = set()
    def visit(name):
        if name in reached: return
        reached.add(name)
        for inst in modules[name]['instances']:
            if inst['concrete_template_name'] in modules: visit(inst['concrete_template_name'])
    visit(selected_id)
    expected = sorted({modules[n]['abstract_name'] for n in reached})
    logs = [pair/f'{route_phase}.{stream}.log' for stream in ('stdout', 'stderr')]
    if any(not p.is_file() for p in logs): raise ValueError('one exact phase stdout/stderr pair required')
    # Verify normalization from original, action-independent resources again.
    signal = resources['signal']; power = resources['power']
    checked_signal = freeze_r09_unit_r(signal['layers_path'], [r['native_index'] for r in signal['rows']])
    checked_power = freeze_power_pitch(power['layers_path'], [r['native_index'] for r in power['rows']], resource_provenance=power['resource_provenance'])
    baseline = read(pair/'grouped35_native_baseline.json')['pdk']
    original = read(signal['layers_path'])
    if original != baseline or read(power['layers_path']) != baseline:
        raise ValueError('R09/W08 resources are not the immutable original PDK payload')
    if checked_signal != signal or checked_power != power:
        raise ValueError('R09/W08 resource table or native unit conversion changed')
    values = {d['parameter_id']: binding['vector'][d['index_0based']] for d in DIMS if d['group'] is None}
    identity = {'module_path': runtime['module_path'], 'module_sha256': JOINT_SHA, 'manifest_env': env,
                'expected_modules': expected}
    profiles = {}; adapters = {}
    for name, key, slots in [('native_r05_consumer_receipt', 'R05', ['R05']),
                             ('native_r0467_consumer_receipt', 'R0467', ['R06','R07']),
                             ('native_r089_consumer_receipt', 'R089', ['R09']),
                             ('native_power_consumer_receipt', 'POWER', ['W08','W09','W10'])]:
        module, adapter = _auditor(name); adapters[key] = adapter
        ident = {**identity, 'patch_id': module.PATCH_ID}
        if key == 'R089': ident['frozen_resources'] = signal
        if key == 'POWER': ident.update(expected_modules=[top], frozen_resources=power)
        fn = getattr(module, {'R05':'readback_native_r05','R0467':'readback_native_r0467','R089':'readback_native_r089','POWER':'readback_native_power'}[key])
        profiles[key] = fn(logs, values['R05'] if key == 'R05' else {s:values[s] for s in slots}, ident)
        _write_safe(out/f'{key}_native_consumer_receipt.json', profiles[key])
    coords = _binding_evidence(pair, copy.deepcopy(binding['coordinates']))
    def assign(slot, evidence, hits, operations, explanation, choice_on_trace=None):
        row = next(r for r in coords if r['parameter_id'] == slot and r['group'] is None)
        valid = evidence.get('status') in ('observed', 'inapplicable')
        row.update(runtime_consumer_call_mask=(hits>0) if valid else None,
                   runtime_operation_mask=(operations>0) if valid else None,
                   completed_native_calls=hits, observed_operation_count=operations,
                   native_status=evidence.get('status'), runtime_basis=explanation,
                   different_allowed_choices_on_reference_trace=choice_on_trace if valid else None)
    e=profiles['R05']; assign('R05',e,e['completed_consumer_count'],e['applicable_net_call_count'],
        'completed FindSTs entries matched to candidate results; positive count does not prove unique candidate geometries')
    for slot in ('R06','R07'):
        e=profiles['R0467']['slots'][slot]
        n=e['operation_count'] if slot=='R06' else sum(int(c['exit']['fields'].get('changed_edges',0)) for c in e['calls'] if c['exit'])
        assign(slot,e,e['completed_call_count'],n,'actual directed_edges_updated' if slot=='R06' else 'actual capacity changed_edges, not function entry or zero-count adjustment')
    e=profiles['R089']['slots']['R09'];assign('R09',e,e['completed_call_count'],e['meaningful_call_count'],
        'searches with real reference segments and positive nonzero_cost_evaluations; empty reference is inactive in this run')
    e=profiles['POWER']['slots']['W08'];assign('W08',e,e['consumer_hit_count'],e.get('via_transitions_evaluated',0),
        'actual power A* via transitions evaluated; normalized beta maps to native round_half_up(beta*p_ref)')
    for slot in ('W09','W10'):
        e=profiles['POWER']['slots'][slot]; calls=[c['exit']['fields'] for c in e['calls'] if c['exit']]
        domain=next(d['allowed_values'] for d in DIMS if d['parameter_id']==slot); distinct=[]
        for c in calls:
            if slot=='W09':
                variants=[min(v,c['distance_map_records']) for v in domain]
            else:
                b,p,extent=c['source_target_bbox'],c['margin_pitch'],c['layout_extent']
                variants=[[max(0,b[0]-v*p[0]),max(0,b[1]-v*p[1]),min(extent[0],b[2]+v*p[0]),min(extent[1],b[3]+v*p[1])] for v in domain]
            distinct.append(len({sha(v) for v in variants})>=2)
        count=sum(distinct)
        assign(slot,e,e['consumer_hit_count'],count,
            'reference-trace distance-map record count permits distinct selected-count choices' if slot=='W09' else 'reference-trace clipping permits distinct window rectangles under the fixed domain',
            choice_on_trace=bool(count))
    # Explicit ordinary-power Python observer verifies W01/W02/W03 arguments
    # and nonempty returned grid objects. Signal native range evidence resides
    # in the detailed R04/R08 markers but this receipt does not infer effects.
    observed_power=[]
    for path in logs:
        for number,line in enumerate(path.read_text(errors='replace').splitlines(),1):
            if 'ADAPT_R6_POWER_ROUTE_V1 ' in line:
                observed_power.append({'fields':json.loads(line.split('ADAPT_R6_POWER_ROUTE_V1 ',1)[1]),'path':str(path),'line':number})
    power_exits=[r for r in observed_power if r['fields'].get('module')==top and r['fields'].get('mode')==2 and r['fields'].get('phase')=='exit']
    for slot in ('W01','W02','W03'):
        row=next(r for r in coords if r['parameter_id']==slot)
        verified=len(power_exits)==1
        if verified and slot in ('W01','W02'):
            verified=power_exits[0]['fields'].get('h_skip_factor' if slot=='W01' else 'v_skip_factor')==values[slot]
        if verified and slot=='W03':
            fields=power_exits[0]['fields'];obj=row['objects'][0];raw=obj['raw_value']
            verified=[fields['metal_l'],fields['metal_u']]==[fields['metalmap'][raw[0]],fields['metalmap'][raw[1]]]
        count=sum(power_exits[0]['fields']['grid_counts'].values()) if verified else None
        row.update(runtime_consumer_call_mask=True if verified else None,
                   runtime_operation_mask=(count>0) if verified else None,
                   observed_operation_count=count,completed_native_calls=1 if verified else None,
                   runtime_basis='actual ordinary-PDN RouteWork arguments and returned metal/via object counts')
        if not verified:row['runtime_argument_status']='missing_or_mismatched_completed_native_power_arguments'
    for row in coords:
        row.setdefault('runtime_consumer_call_mask', None)
        row.setdefault('runtime_operation_mask', None)
        row.setdefault('runtime_basis','binding and generated output presence are separate from native operation instrumentation')
    report={'schema':'grouped35-reference-mask-evidence-v1','status':'reference_trace_inventory_complete','route_phase':route_phase,'top':top,
        'launch_identity':launch_identity,
        'object_mask':binding['object_mask'],'decoded_choice_mask':binding['choice_mask'],
        'serialized_binding_mask':[r['serialized_binding_mask'] for r in coords],
        'primitive_generated_mask':[r['primitive_generated_mask'] for r in coords],
        'generator_shape_registry_mask':[r['generator_shape_registry_mask'] for r in coords],
        'runtime_consumer_call_mask':[r['runtime_consumer_call_mask'] for r in coords],
        'runtime_operation_mask':[r['runtime_operation_mask'] for r in coords],
        'metric_effect_mask':[None]*35,'coordinates':coords,
        'object_count':sum(v is True for v in binding['object_mask']),
        'decoded_choice_count':sum(v is True for v in binding['choice_mask']),
        'runtime_operation_count':sum(r['runtime_operation_mask'] is True for r in coords),
        'native_normalization':{'R09':{'normalized':values['R09'],'r_ref':signal['r_ref'],'effective_raw':values['R09']*signal['r_ref']},
            'W08':{'normalized':values['W08'],'p_ref':power['p_ref'],'effective_raw':math.floor(values['W08']*power['p_ref']+.5)},
            'resources_equal_original_immutable_PDK':True,
            'native_source_conversion_and_actual_marker_rows_verified_in_profiles':all(
                p['status'] in ('observed','inapplicable') for p in
                [profiles['R089']['slots']['R09'],profiles['POWER']['slots']['W08']])},
        'protocol_auditor_adapters':adapters,'ordinary_power_events':observed_power,
        'artifacts':[{'path':str(p),'sha256':file_sha(p)} for p in [pair/f'{route_phase}.json',*logs,binding_path,pair/'native_environment.json',pair/'native_resources.json']],
        'limitations':['Decoded choices are distinct serialized native inputs, not a claim that every choice completed routing.',
            'Operation masks describe this one reference trace; false does not prune a dimension or establish zero effect at other actions.',
            'A missing/incomplete marker remains unknown. Call entry alone is insufficient.',
            'No parameter-to-final-metric sensitivity is measured by this baseline receipt.',
            'Geometry legality and full reference vector execution are signed off separately by the runner.']}
    _write_safe(out/'grouped35_masks.json',report);return report


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pairdir',required=True,type=Path);parser.add_argument('--top',required=True)
    parser.add_argument('--route-phase',default='routing_reference_v1')
    parser.add_argument('--output-dir',type=Path)
    args=parser.parse_args()
    result=collect_runtime_masks(args.pairdir,top=args.top,route_phase=args.route_phase,output_dir=args.output_dir)
    print(json.dumps({k:result.get(k) for k in ['status','object_count','decoded_choice_count','runtime_operation_count','native_normalization']},indent=2))
