"""Unchanged checker decisions plus SKY130 datatype-aware metric observation."""
from pathlib import Path
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT/'src'))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base = load('_sky953_validation_original', HERE/'qualification_validation.py')
ground = load('_sky953_ground_observer', HERE/'audit/metric_repair/align_hierarchy_serializer_v2.py')
from sky130_postroute_sidecar import _layer_datatype_map, _normalise_gds


def serializer(gds_json, top_json, layers_json, *, workdir, top):
    work = Path(workdir)
    destination = work.parent/'sky130_datatype_observation953'
    destination.mkdir(exist_ok=True)
    layers = json.loads(Path(layers_json).read_text())
    normalized, mapping, policy = _layer_datatype_map(layers)
    normalized_layers = destination/'layers.json'
    normalized_layers.write_text(json.dumps(normalized,indent=2)+'\n')
    normalized_gds = destination/Path(gds_json).name
    manifest = _normalise_gds(Path(gds_json),normalized_gds,mapping)
    manifest.update(policy=policy,original_pdk_rules_unchanged=True,
                    checker_errors_unchanged=True,
                    scope='Private geometry observation only, never launched as a PDK.')
    (destination/'normalization_receipt.json').write_text(json.dumps(manifest,indent=2)+'\n')
    result = ground.serialize_hierarchical_final(normalized_gds,top_json,normalized_layers,workdir=workdir,top=top)
    result['sky130_datatype_observation_receipt']=str(destination/'normalization_receipt.json')
    return result


base.serialize_hierarchical_final=serializer


def validate_pair(*args,**kwargs):
    result = base.validate_pair(*args,**kwargs)
    result['pdk_metric_adapter']='SKY130 layer/datatype observation plus explicit declared ground refinement'
    result['checker_policy']='Original raw selected-hierarchy errors, no suppression or waiver added'
    out = Path(args[3] if len(args)>3 else kwargs['outdir'])
    (out/'qualification_result.json').write_text(json.dumps(result,indent=2)+'\n')
    return result
