"""Strict selected-hierarchy ALIGN mock-layout qualification and four metrics.

No ALIGN run is launched. Raw .errors files remain immutable. The sole
diagnostic exception is an individually proven, unnamed Rvt width-marker
record; no metal, connectivity, DRC or postprocessor error is suppressed.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ROOT=Path(__file__).absolute().parents[3]
sys.path.insert(0,str(ROOT/'src'))
from adapt.postlayout.align_hierarchy_serializer import serialize_hierarchical_final
from adapt.postlayout.geometry_metrics import compute_geometry_metrics, mask_ineligible_metrics
from adapt.postlayout.mock_marker_gate import qualify_mock_marker_patch

METRICS=('A_eval','L_eq_signal','L_eq_power','N_cut_intermetal')
SUPPORTED_RVT={'Bulk65nm_Mock_PDK','FinFET14nm_Mock_PDK'}
REVIEWED_GENERATOR_PROFILES={
    # Independently reproduced primitive geometry fix; see pdk_fixes/
    # geometry_fix_evidence.json. This never enables Bulk45 by default.
    '4c4d9b7b63f36b9b74f8adf58069ba3c70fc349b555adb714df5f5595be8ac9c':
        ('Bulk45nm_Mock_PDK','bulk45_shared_diffusion_stacked_grid_v1'),
}

def _read(path):
    return json.loads(Path(path).read_text())

def _sha(path):
    p=Path(path)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def _receipt(path):
    p=Path(path)
    return {'path':str(p.absolute()),'exists':p.is_file(),'sha256':_sha(p)}

def selected_leaf_metadata(workdir, leaf):
    """Resolve native primitive or cap_placer output by exact concrete identity."""
    workdir=Path(workdir);direct=workdir/'2_primitives'/f'{leaf}.json'
    if direct.is_file():return {'kind':'primitive_generator','artifacts':[_receipt(direct)]}
    pnr=workdir/'3_pnr';mapping=pnr/'__cap_map__.json'
    if not mapping.is_file():return None
    matches=[]
    for abstract,relative in _read(mapping):
        source=(pnr/relative).resolve()
        if not source.is_relative_to(pnr.resolve()):raise ValueError('cap map path outside selected PnR directory')
        if source.stem==leaf:matches.append((abstract,source))
    if len(matches)!=1:return None
    abstract,source=matches[0]
    # cap_placer writes a GDS JSON representation; the map uses the .gds name.
    artifacts=[source.with_suffix('.json'),source.with_suffix('.lef'),source.with_suffix('.gds.json')]
    if not all(p.is_file() for p in artifacts):return None
    return {'kind':'native_cap_placer','abstract':abstract,'concrete':leaf,
            'map':_receipt(mapping),'artifacts':[_receipt(p) for p in artifacts]}

def _rect(rect):
    if not isinstance(rect,(tuple,list)) or len(rect)!=4:
        raise ValueError('rectangle_requires_four_coordinates')
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in rect):
        raise ValueError('nonfinite_or_nonnumeric_rectangle')
    if rect[2]<=rect[0] or rect[3]<=rect[1]:
        raise ValueError('nonpositive_rectangle')
    return tuple(rect)

def _overlap(a,b):
    return max(a[0],b[0])<min(a[2],b[2]) and max(a[1],b[1])<min(a[3],b[3])

def qualify_rvt_geometry(viewer_path,pdk_path,*,allow_rvt45=False):
    """Prove marker correspondence, not FEOL manufacturing-rule correctness."""
    pdk=Path(pdk_path)
    report={'status':'blocked','policy':'raw_rvt_width_active_correspondence_v2',
        'viewer':_receipt(viewer_path),'layers':_receipt(pdk/'layers.json'),
        'mos_generator':_receipt(pdk/'mos.py'),'physical_signoff':False}
    # Check the actual private generator against the source version inspected
    # for this exact PDK. Private directories may simply be called ``pdk``;
    # identify the implementation by a unique source hash, never its dirname.
    actual_sha=_sha(pdk/'mos.py')
    matches=[name for name in sorted(SUPPORTED_RVT|{'Bulk45nm_Mock_PDK'})
        if actual_sha is not None and actual_sha==_sha(ROOT/'ALIGN-public/pdks'/name/'mos.py')]
    if actual_sha in REVIEWED_GENERATOR_PROFILES:
        name,profile=REVIEWED_GENERATOR_PROFILES[actual_sha]
        matches.append(name);report['reviewed_generator_profile']=profile
    report['canonical_generator_matches']=matches
    if len(matches)!=1:
        return {**report,'reason':'unreviewed_mos_generator'}
    pdk_name=matches[0];report['canonical_pdk_name']=pdk_name
    supported=pdk_name in SUPPORTED_RVT or (pdk_name=='Bulk45nm_Mock_PDK' and allow_rvt45)
    if not supported:return {**report,'reason':'pdk_not_authorized_for_marker_exception'}
    try:
        layers=_read(pdk/'layers.json');payload=_read(viewer_path)
        enc=next(r.get('active_enclosure') for r in layers['Abstraction'] if r.get('Layer')=='Active')
        if not isinstance(enc,(int,float)) or not math.isfinite(enc) or enc<0:
            raise ValueError('invalid_active_enclosure')
        terms=payload.get('terminals',[])
        markers=[t for t in terms if t.get('layer') in {'Rvt','Lvt','Hvt','Slvt'}]
        active=Counter(tuple(t['rect']) for t in terms if t.get('layer')=='Active')
        rects=[]
        for term in markers:
            if term.get('layer')!='Rvt' or term.get('netName') is not None or term.get('netType')!='drawing':
                raise ValueError('non_rvt_or_named_or_nondrawing_marker')
            r=_rect(term.get('rect'))
            target=_rect((r[0],r[1]+enc,r[2],r[3]-enc))
            if active[target]!=1:raise ValueError('missing_or_nonunique_active_correspondence')
            if any(_overlap(r,x) for x in rects):raise ValueError('overlapping_rvt_markers')
            rects.append(r)
        return {**report,'status':'qualified_mock_marker_geometry','reason':'all_rvt_rectangles_have_unique_active_correspondence',
            'active_enclosure':enc,'marker_count':len(rects),'marker_rectangles':[list(x) for x in rects],
            'bulk45_explicitly_enabled':pdk_name=='Bulk45nm_Mock_PDK'}
    except (OSError,ValueError,KeyError,TypeError,StopIteration) as exc:
        return {**report,'reason':str(exc)}

def classify_error_line(line,marker_evidence):
    """Fail closed for every diagnostic other than the exact proven tuple."""
    result={'raw':line,'classification':'unexplained_error','accepted':False}
    if not line.strip():return {**result,'classification':'empty','accepted':True}
    for prefix in ('SHORT','OPEN','DRC ERROR','POSTPROCESSOR ERROR','DIFFERENT WIDTH'):
        if line.startswith(prefix):result['classification']=prefix.lower().replace(' ','_');break
    if not line.startswith('DIFFERENT WIDTH '):return result
    if marker_evidence.get('status')!='qualified_mock_marker_geometry':return result
    try:
        message,(indices,items)=ast.literal_eval(line[len('DIFFERENT WIDTH '):])
        if not re.fullmatch(r'Rectangles on layer Rvt with the same 2x centerline -?\d+(?:\.\d+)? but different widths \{[^}]+\}:',message):return result
        if list(indices)!=[1,3] or not items:return result
        known={tuple(v) for v in marker_evidence['marker_rectangles']}
        for rect,net,net_type,is_ported in items:
            if _rect(rect) not in known or net is not None or net_type!='drawing' or is_ported is not False:return result
        return {**result,'classification':'proven_rvt_marker_width_diagnostic','accepted':True,
            'evidence_policy':marker_evidence['policy'],'diagnostic_rectangles':len(items)}
    except (ValueError,TypeError,SyntaxError,KeyError):return result

def selected_hierarchy(placement,selected_id):
    modules={m['concrete_name']:m for m in placement.get('modules',[])}
    leaves={m['concrete_name']:m for m in placement.get('leaves',[])}
    if len(modules)!=len(placement.get('modules',[])) or len(leaves)!=len(placement.get('leaves',[])):
        raise ValueError('duplicate_concrete_metadata_definition')
    used_modules=set();used_leaves=set();occurrences=[];overlaps=[]
    def visit(name,path,chain):
        if name in chain:raise ValueError('cyclic_selected_placement_hierarchy')
        if name in leaves:
            used_leaves.add(name);_rect(leaves[name]['bbox']);return
        if name not in modules:raise ValueError('selected_reference_missing:'+name)
        used_modules.add(name);mod=modules[name];_rect(mod['bbox']);boxes=[]
        for inst in mod.get('instances',[]):
            child=inst['concrete_template_name'];child_data=modules.get(child,leaves.get(child))
            if child_data is None:raise ValueError('selected_reference_missing:'+child)
            r=_rect(child_data['bbox']);t=inst['transformation']
            if t.get('sX') not in (-1,1) or t.get('sY') not in (-1,1):raise ValueError('unsupported_placement_transform')
            xs=[t['oX']+t['sX']*r[i] for i in (0,2)];ys=[t['oY']+t['sY']*r[i] for i in (1,3)]
            box=_rect((min(xs),min(ys),max(xs),max(ys)))
            for prev,pbox in boxes:
                if _overlap(box,pbox):overlaps.append({'module':name,'instances':[prev,inst['instance_name']],'rectangles':[list(pbox),list(box)]})
            boxes.append((inst['instance_name'],box))
            fullpath=path+'/'+inst['instance_name'];occurrences.append({'path':fullpath,'concrete_name':child})
            visit(child,fullpath,chain+(name,))
    visit(selected_id,selected_id,())
    return {'selected_id':selected_id,'used_modules':sorted(used_modules),'used_leaves':sorted(used_leaves),
        'selected_instance_occurrences':occurrences,'positive_area_placement_overlaps':overlaps}

def validate_pair(workdir,top,pdk,outdir,align_python=None,pythonpath=None,run_logs=(),*,
                  returncode=None,selected_id=None,require_explicit_pdn=True,allow_rvt45=False,
                  python_checker_patch=None):
    """Validate selected ALIGN artifacts, return JSON-safe qualification result.

    `run_logs` may be paths, or {paths:[...], returncode:0, power_profile:
    'explicit_pdn'}. `returncode` must be supplied; unknown is never success.
    Existing R6 output may be checked via `validate_run_manifest` below.
    """
    workdir,pdk,outdir=map(lambda x:Path(x).absolute(),(workdir,pdk,outdir))
    outdir.mkdir(parents=True,exist_ok=True)
    selected_id=selected_id or f'{top}_0';pnr=workdir/'3_pnr';results=pnr/'Results'
    failures=[];checks={};diagnostic_metrics=None;geometry=None
    def fail(code,**details):failures.append({'code':code,**details})
    if isinstance(run_logs,dict):
        if returncode is None:returncode=run_logs.get('returncode')
        logpaths=run_logs.get('paths',[]);declared_power=run_logs.get('power_profile')
    else:logpaths=run_logs;declared_power=None
    if isinstance(logpaths,(str,Path)):logpaths=[logpaths]
    if returncode!=0:fail('flow_not_completed',returncode=returncode)
    checks['run_logs']=[_receipt(x) for x in logpaths]
    if not logpaths or any(not Path(x).is_file() for x in logpaths):fail('run_log_evidence_missing')
    # Logs retain exceptions even when a wrapper mistakenly returns zero.
    fatal=[]
    for p in logpaths:
        if not Path(p).is_file():continue
        for num,line in enumerate(Path(p).read_text(errors='replace').splitlines(),1):
            if re.search(r'Traceback \(most recent call last\)|Segmentation fault|terminate called after|AssertionError',line):
                fatal.append({'path':str(p),'line':num,'text':line[:400]})
    if fatal:fail('fatal_runtime_diagnostic',examples=fatal[:20])
    viewer=pnr/f'{selected_id}.json';final=results/f'{selected_id}.gds.json'
    layers=results/'layers.json'
    if not layers.is_file():layers=pnr/'inputs/layers.json'
    placement_file=results/f'{selected_id}.scaled_placement_verilog.json'
    required={'viewer':viewer,'final_gds_json':final,'layers':layers,'placement':placement_file,
        'primitive_registry':workdir/'2_primitives/__primitives__.json'}
    checks['required_artifacts']={k:_receipt(v) for k,v in required.items()}
    for k,path in required.items():
        if not path.is_file():fail('missing_required_artifact',artifact=k,path=str(path))
    if layers.is_file() and (pdk/'layers.json').is_file() and _sha(layers)!=_sha(pdk/'layers.json'):
        fail('run_layers_differ_from_declared_pdk')
    selection=None;placement=None
    if placement_file.is_file():
        try:
            placement=_read(placement_file);selection=selected_hierarchy(placement,selected_id)
            checks['selected_hierarchy']=selection
            if selection['positive_area_placement_overlaps']:fail('selected_placement_overlap',count=len(selection['positive_area_placement_overlaps']))
        except (KeyError,TypeError,ValueError,OSError) as exc:fail('selected_hierarchy_unverified',reason=str(exc))
    if selection:
        module_checks=[]
        for name in selection['used_modules']:
            jp=pnr/f'{name}.json';ep=pnr/f'{name}.errors'
            marker=qualify_rvt_geometry(jp,pdk,allow_rvt45=allow_rvt45)
            if python_checker_patch:
                legacy=qualify_mock_marker_patch(jp,pdk,python_checker_patch)
                if legacy.get('status')!='qualified_mock_diagnostic':fail('legacy_checker_patch_not_qualified',module=name,reason=legacy.get('reason'))
            else:legacy=None
            if not jp.is_file():fail('selected_module_viewer_missing',module=name)
            if not ep.is_file():
                fail('selected_module_error_receipt_missing',module=name);lines=[]
            else:lines=[classify_error_line(x,marker) for x in ep.read_text().splitlines() if x.strip()]
            bad=[r for r in lines if not r['accepted']]
            if bad:fail('selected_module_unexplained_errors',module=name,count=len(bad))
            module_checks.append({'module':name,'error_file':_receipt(ep),'viewer':_receipt(jp),
                'raw_error_count':len(lines),'unexplained_error_count':len(bad),'diagnostics':lines,
                'rvt_geometry_evidence':marker,'legacy_checker_patch':legacy})
        checks['selected_module_checks']=module_checks
        checks['unselected_error_files_not_used_for_qualification']=[str(p) for p in pnr.glob('*.errors') if p.stem not in selection['used_modules']]
        checks['selected_primitive_metadata']={}
        for leaf in selection['used_leaves']:
            try:metadata=selected_leaf_metadata(workdir,leaf)
            except (OSError,ValueError,TypeError) as exc:
                metadata=None;fail('selected_primitive_metadata_invalid',primitive=leaf,reason=str(exc))
            checks['selected_primitive_metadata'][leaf]=metadata
            if metadata is None:fail('selected_primitive_metadata_missing',primitive=leaf)
    if placement and require_explicit_pdn:
        decl={k:set() for k in ('power','ground')}
        for item in placement.get('global_signals',[]):
            kind={'supply0':'ground','supply1':'power'}.get(item.get('formal'))
            if kind and isinstance(item.get('actual'),str):decl[kind].add(item['actual'])
        topmod=next((m for m in placement.get('modules',[]) if m.get('concrete_name')==selected_id),{})
        for constraint in topmod.get('constraints',[]):
            kind={'PowerPorts':'power','GroundPorts':'ground'}.get(constraint.get('constraint'))
            if kind:decl[kind].update(constraint.get('ports',[]))
        checks['explicit_power_declarations']={k:sorted(v) for k,v in decl.items()}
        if not decl['power'] or not decl['ground'] or decl['power']&decl['ground']:fail('explicit_power_ground_declarations_missing_or_conflicting')
        if declared_power not in (None,'explicit_pdn'):fail('signal_only_profile_not_four_metric_qualification')
    if all(p.is_file() for p in required.values()):
        try:
            geometry=serialize_hierarchical_final(final,viewer,layers,workdir=workdir,top=top)
            if geometry.get('structure_selection',{}).get('selected_names')!=[selected_id]:fail('selected_final_identity_mismatch')
            if geometry.get('metric_eligibility')!='eligible' or geometry.get('geometry_complete') is not True or geometry.get('ownership_coverage',{}).get('ownership_complete') is not True:
                fail('full_hierarchy_geometry_or_ownership_incomplete',reasons=geometry.get('eligibility_reasons',[]))
            diagnostic_metrics=compute_geometry_metrics(geometry,reference_widths_um=geometry['reference_widths_um'])
            if diagnostic_metrics.get('metric_status')!='ok' or diagnostic_metrics.get('unknown_geometry_count',0):fail('invalid_geometry_metric_contract')
            for key in METRICS:
                metric=diagnostic_metrics.get(key,{})
                if metric.get('status')!='ok' or not isinstance(metric.get('value'),(int,float)) or not math.isfinite(metric['value']) or metric['value']<0:
                    fail('required_metric_unavailable',metric=key,status=metric.get('status'))
            if diagnostic_metrics.get('A_eval',{}).get('value',0)<=0:fail('nonpositive_evaluation_area')
            if require_explicit_pdn and diagnostic_metrics.get('L_eq_power',{}).get('value') in (None,0):fail('explicit_pdn_has_no_owned_power_geometry')
            (outdir/'qualification_full_layout_geometry.json').write_text(json.dumps(geometry,indent=2)+'\n')
        except (KeyError,TypeError,ValueError,OSError) as exc:fail('full_hierarchy_serializer_or_metric_failure',reason=f'{type(exc).__name__}:{exc}')
    legal=not failures
    primary=mask_ineligible_metrics(diagnostic_metrics or {},eligible=legal,reason='strict_selected_hierarchy_qualification_failed')
    if not diagnostic_metrics:
        for k in METRICS:primary[k]={'value':None,'status':'unavailable','reason':'geometry_unavailable'}
    (outdir/'qualification_metrics.json').write_text(json.dumps(primary,indent=2)+'\n')
    result={'schema':'adapt-formal35-selected-hierarchy-qualification-v1','workdir':str(workdir),'top':top,
        'selected_id':selected_id,'pdk':str(pdk),'returncode':returncode,'legal':legal,
        'qualification_status':'qualified_under_align_mock_checks' if legal else 'rejected_or_incomplete',
        'physical_signoff':False,'new_align_runs_launched_by_validator':0,
        'scope':'Selected routed hierarchy, ALIGN connectivity/DRC diagnostics, exact resource geometry and ownership; not foundry FEOL signoff or post-layout electrical validation.',
        'checks':checks,'failures':failures,'four_metrics':{k:primary.get(k) for k in METRICS},
        'metric_vector':[primary.get(k,{}).get('value') for k in METRICS],
        'requested_runtime':{'align_python':str(align_python) if align_python else None,'pythonpath':str(pythonpath) if pythonpath else None},
        'validator_sha256':_sha(__file__),'serializer_sha256':_sha(ROOT/'src/adapt/postlayout/align_hierarchy_serializer.py'),
        'metric_implementation_sha256':_sha(ROOT/'src/adapt/postlayout/geometry_metrics.py'),
        'raw_error_files_modified':False}
    (outdir/'qualification_result.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def validate_run_manifest(manifest_path,outdir,*,allow_rvt45=False):
    """Read an old/new R6-style runner manifest. Revalidation is not a new run."""
    mp=Path(manifest_path);m=_read(mp);command=m.get('command',[])
    def arg(name):return command[command.index(name)+1] if name in command else None
    pdk=arg('-p');top=arg('-s')
    if not pdk or not top:raise ValueError('run_manifest_missing_explicit_top_or_pdk_command')
    return validate_pair(m['align_workdir'],top,pdk,outdir,command[0] if command else None,
        m.get('patched_pythonpath'),{'paths':[str(mp.parent/'stdout.log'),str(mp.parent/'stderr.log')],
            'returncode':m.get('returncode'),'power_profile':m.get('power_profile')},
        python_checker_patch=m.get('align_python_patch'),allow_rvt45=allow_rvt45)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest',type=Path)
    ap.add_argument('--workdir',type=Path);ap.add_argument('--top');ap.add_argument('--pdk',type=Path)
    ap.add_argument('--outdir',type=Path,required=True);ap.add_argument('--returncode',type=int)
    ap.add_argument('--run-log',action='append',default=[]);ap.add_argument('--selected-id')
    ap.add_argument('--allow-rvt45',action='store_true',help='Only enables exact same-generator Active-correspondence proof; never metal/DRC exception.')
    a=ap.parse_args()
    if a.manifest:r=validate_run_manifest(a.manifest,a.outdir,allow_rvt45=a.allow_rvt45)
    else:
        if not all((a.workdir,a.top,a.pdk)):ap.error('manifest or workdir/top/pdk required')
        r=validate_pair(a.workdir,a.top,a.pdk,a.outdir,run_logs=a.run_log,returncode=a.returncode,selected_id=a.selected_id,allow_rvt45=a.allow_rvt45)
    print(json.dumps({'legal':r['legal'],'metric_vector':r['metric_vector'],'failures':r['failures']},ensure_ascii=False))
    raise SystemExit(0 if r['legal'] else 2)
