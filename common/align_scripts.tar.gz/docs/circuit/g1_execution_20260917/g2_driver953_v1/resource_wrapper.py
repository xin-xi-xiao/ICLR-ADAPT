"""Set exact reference stack, attest AS/seed, then exec the actual native command.

No default resources, admission policy or task dispatch live in this module.
Import has no side effects; the executable entry requires a G2 phase profile.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import resource
import sys
import time

from contracts import OUTPUT_ROOT, digest, require


def stack_target(stack, inherited):
    """Pure validation used before any setrlimit or native execution."""
    soft, hard = inherited
    if stack['mode'] == 'default_unmodified':
        require(stack.get('soft_bytes') is None, 'Default stack cannot override soft limit')
        return soft, hard
    require(stack['mode'] == 'explicit_soft_limit', 'Unsupported reference stack mode')
    target = stack['soft_bytes']
    require(type(target) is int and target > 0, 'Invalid stack soft limit')
    require(hard == resource.RLIM_INFINITY or target <= hard, 'Reference stack exceeds inherited hard limit')
    if stack.get('hard_bytes') is not None:
        require(hard == stack['hard_bytes'], 'Inherited hard stack differs from recorded reference')
    return target, hard


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    profile, receipt = args.profile.resolve(), args.receipt.resolve()
    require(profile.is_relative_to(OUTPUT_ROOT.resolve()) and receipt.is_relative_to(OUTPUT_ROOT.resolve()),
            'Resource artifacts must stay in independent G2 namespace')
    require(profile.parent == receipt.parent and not receipt.exists(), 'Fresh same-run resource receipt required')
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    spec = json.loads(profile.read_text())
    require(command == spec['command'], 'Native command differs from frozen phase plan')
    require(os.environ.get('PYTHONHASHSEED') == str(spec['align_seed']), 'Python hash seed not propagated')
    limits = spec['resource']
    before = resource.getrlimit(resource.RLIMIT_STACK)
    target = stack_target(limits['stack'], before)
    if limits['stack']['mode'] == 'explicit_soft_limit':
        resource.setrlimit(resource.RLIMIT_STACK, target)
    actual = resource.getrlimit(resource.RLIMIT_STACK)
    actual_as = resource.getrlimit(resource.RLIMIT_AS)
    require(actual == target, 'Stack limit was not applied exactly')
    require(actual_as[0] == limits['address_space_gib'] * 1024**3, 'prlimit AS was not applied exactly')
    observed = {
        'schema': 'g2-native-resource-exec-profile953-v1', 'phase': spec['phase'],
        'resource_signature': spec['resource_signature'], 'reference_contract_sha256': spec['reference_contract_sha256'],
        'request_canonical_sha256': spec['request_canonical_sha256'],
        'execution_identity_sha256': spec['execution_identity_sha256'],
        'native_command_sha256': digest(command), 'align_seed': spec['align_seed'],
        'PYTHONHASHSEED': os.environ['PYTHONHASHSEED'], 'stack_mode': limits['stack']['mode'],
        'parent_soft_hard_before': list(before), 'stack_soft_bytes': actual[0], 'stack_hard_bytes': actual[1],
        'child_inheritance_probe': list(actual),
        'stack_evidence_kind': 'same_process_exec_preserves_verified_RLIMIT_not_separate_child_probe',
        'reference_numeric_default_stack_known': limits['stack']['mode'] != 'default_unmodified',
        'AS_GiB': limits['address_space_gib'], 'observed_RLIMIT_AS_bytes': list(actual_as),
        'timeout_s': limits['timeout_s'], 'pid_before_same_process_native_exec': os.getpid(),
        'prepared_native_exec_epoch': time.time(), 'profile_is_not_native_completion_receipt': True,
        'exec_failure': None,
    }
    with receipt.open('x') as stream:
        json.dump(observed, stream, indent=2, allow_nan=False)
        stream.write('\n')
    try:
        os.execvpe(command[0], command, os.environ)
    except OSError as exc:
        observed['exec_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        temp = receipt.with_suffix('.failed.tmp')
        with temp.open('x') as stream:
            json.dump(observed, stream, indent=2)
            stream.write('\n')
        temp.replace(receipt)
        raise


if __name__ == '__main__':
    main()
