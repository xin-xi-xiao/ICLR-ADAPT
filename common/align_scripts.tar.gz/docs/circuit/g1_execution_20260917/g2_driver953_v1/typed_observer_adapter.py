"""Seed-aware G2 adapter around unchanged SKY130 typed-contact observation.

This process never starts native. Frozen geometry/checker/metric operations are
reused; only the legacy seed=1 identity assumption gets an explicit G2 context.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys
import types

from contracts import (G, ROOT, HERE, OUTPUT_ROOT, PHASES, sha, require, validate_request,
                       seeded_native_identity, verify_seed_receipts, resource_for_phase)

sys.dont_write_bytecode = True


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class SeedAwareRunner:
    """A private proxy, leaving the imported frozen runner module untouched."""
    def __init__(self, frozen, request):
        self.frozen, self.request = frozen, request

    def __getattr__(self, name):
        return getattr(self.frozen, name)

    def effective_configuration(self, binding, masks, environment, identity, **kwargs):
        return self.frozen.effective_configuration(binding, masks, environment,
                seeded_native_identity(self.request, identity), **kwargs)


def observe(run, output):
    run, output = Path(run).resolve(), Path(output).resolve()
    require(run.is_relative_to(OUTPUT_ROOT.resolve()) and output.is_relative_to(run) and not output.exists(),
            'Fresh derived observation under the actual G2 run required')
    request = json.loads((run / 'request.json').read_text())
    validate_request(request)
    require(Path(request['output_directory']).resolve() == run and request['pair']['pdk'] == 'SKY130',
            'Typed adapter only handles its declared SKY130 G2 run')
    for p in (G, ROOT / 'src'):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))
    support = load('_g2_frozen_typed_support', G / 'sky130_s5_derived_observation_support_v1.py')
    support.runner = SeedAwareRunner(support.runner, request)
    receipts = {p: json.loads((run / (p + '.json')).read_text()) for p in PHASES}
    launch = json.loads((run / 'launch_contract.json').read_text())
    verify_seed_receipts(request, receipts, launch)
    for phase, receipt in receipts.items():
        profile_evidence = receipt['actual_resource_profile']
        profile_path = Path(profile_evidence['path']).resolve()
        require(profile_path.is_relative_to(run) and sha(profile_path) == profile_evidence['sha256'],
                'Actual resource/seed profile changed')
        profile = json.loads(profile_path.read_text())
        expected = resource_for_phase(request, phase)
        require(profile.get('exec_failure') is None and profile['align_seed'] == request['align_seed']
                and profile['PYTHONHASHSEED'] == str(request['align_seed']), 'Executed resource wrapper seed mismatch')
        require(profile['AS_GiB'] == expected['address_space_gib'] and profile['timeout_s'] == expected['timeout_s'],
                'Actual resources differ from matched reference')
        require(profile['stack_mode'] == expected['stack']['mode'], 'Stack mode mismatch')
        if expected['stack']['mode'] == 'explicit_soft_limit':
            require(profile['stack_soft_bytes'] == expected['stack']['soft_bytes'], 'Exact stack mismatch')
    protected = [run / name for name in ('result.json', 'request.json', 'launch_contract.json',
                  'effective_configuration.json', 'validation_result.json')] + [run / (p + '.json') for p in PHASES]
    before = {str(p): sha(p) for p in protected}
    # The frozen observer imports this name inside observe(); substitute only
    # in this fresh observer process, never modify the original support file.
    adapter = types.ModuleType('sky130_s5_derived_observation_support_v1')
    adapter.verify_s5 = support.verify_s5
    sys.modules[adapter.__name__] = adapter
    observer = load('_g2_frozen_typed_observer', G / 'sky130_device_contact_observer_v4.py')
    observer.observe(run, output)
    require(all(sha(p) == h for p, h in before.items()), 'Derived observation changed raw evidence')
    evidence = {'schema': 'g2-seeded-typed-observer-adapter953-v1',
                'adapter': {'path': str(Path(__file__).resolve()), 'sha256': sha(__file__)},
                'frozen_observer': {'path': str(G / 'sky130_device_contact_observer_v4.py'),
                                    'sha256': sha(G / 'sky130_device_contact_observer_v4.py')},
                'align_seed': request['align_seed'], 'python_hash_seed': str(request['align_seed']),
                'all_five_CLI_and_resource_seed_receipts_verified': True, 'raw_artifacts_sha256': before,
                'legacy_artifact_names_are_compatibility_only': True,
                'native_runs_started': 0, 'physical_geometry_and_checker_implementation_changed': False}
    with (output / 'g2_adapter_receipt.json').open('x') as stream:
        json.dump(evidence, stream, indent=2)
        stream.write('\n')
    return evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    observe(args.run, args.out)


if __name__ == '__main__':
    main()
