"""Fresh G2 full-flow adapter. Default plan is read-only; run needs explicit gates.

Frozen S5 flow/dispatcher/checker/metric functions are reused in a private module.
No S5 output namespace, seed constant, admission approval or registration is reused.
"""
from __future__ import annotations

import argparse
import contextlib
import copy
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
import uuid

from contracts import (G, HERE, ROOT, OUTPUT_ROOT, NATIVE_SHA, PHASES, FLOWS, digest, sha, require,
                       validate_request, phase_plan, run_identity, seed_environment,
                       seeded_native_identity, normalize_observation, verify_seed_receipts, reference_contract_digest)

sys.dont_write_bytecode = True


def read(path):
    return json.loads(Path(path).read_text())


def atomic(path, value, root):
    path, root = Path(path), Path(root).resolve()
    require(path.resolve().is_relative_to(root), 'Write escaped this fresh G2 attempt')
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex)
    with temp.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')
    temp.replace(path)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def implementation_paths():
    paths = [HERE / name for name in ('contracts.py', 'driver.py', 'resource_wrapper.py', 'typed_observer_adapter.py')] + [
        G / name for name in ('s5_reference_resource_contract953_v2.py', 'sky130_device_contact_observer_v4.py',
                             'sky130_s5_derived_observation_support_v1.py', 'observer953_parameterized_v1.py',
                             'audit/metric_repair/align_hierarchy_serializer_v2.py')]
    new_resource = G / 'g2_execution953_v1/reference_resources.py'
    if new_resource.is_file():
        paths.append(new_resource)
    return paths


def implementation_pins():
    return {str(p.resolve()): sha(p) for p in implementation_paths()}


def verify_g1_final(request):
    proof = request.get('g1_final_assembly_proof')
    require(isinstance(proof, dict) and proof.get('G1_complete') is True, 'Final G1 assembly proof required')
    directory = Path(proof['assembly_directory']).resolve()
    require(directory.is_relative_to(G), 'G1 assembly must be in the private evidence workspace')
    receipt_evidence = proof['receipt']
    receipt_path = Path(receipt_evidence['path']).resolve()
    require(receipt_path == directory / 'assembly_receipt.json' and sha(receipt_path) == receipt_evidence['sha256'],
            'G1 final receipt path/SHA mismatch')
    receipt = read(receipt_path)
    require(receipt.get('schema') == 'g1-s6-assembly-receipt-v1' and receipt.get('G1_complete') is True,
            'G1 is not formally complete')
    require(type(receipt.get('final_DUT_count')) is int and 35 <= receipt['final_DUT_count'] <= 40
            and receipt.get('final_pair_count') == 3 * receipt['final_DUT_count'], 'G1 final pool denominator invalid')
    published = {Path(e['path']).name: e for e in receipt['files']}
    for name in ('canonical_inventory.json', 'final_pair_matrix.json', 'selected_pdks.json', 'split_manifest.json',
                 'dependency_manifest.json', 'replay_index.json'):
        ev = proof['files'][name]
        require(Path(ev['path']).resolve() == directory / name and sha(directory / name) == ev['sha256']
                and published.get(name, {}).get('sha256') == ev['sha256'], 'G1 published artifact mismatch: ' + name)
    rows = read(directory / 'final_pair_matrix.json')
    require(len(rows) == receipt['final_pair_count'] and
            set(read(directory / 'selected_pdks.json')['selected_pdks']) == {'14nm', '65nm', 'SKY130'},
            'Published pair count or domains mismatch')
    selected = [r for r in rows if r['case_id'] == request['pair']['case_id'] and r['pdk'] == request['pair']['pdk']]
    require(len(selected) == 1, 'Request pair not uniquely present in final G1 matrix')
    row = selected[0]
    require(row['input_version'] == request['input_version'], 'Request input version differs from final G1 selection')
    require(Path(row['reference_run']).resolve() == Path(request['bundle_path']).resolve(),
            'Request source reference differs from final G1 selection')
    return {'receipt': receipt_evidence, 'selected_pair': row}


def verify_execution_contract(request, path):
    path = Path(path).resolve()
    require(request.get('execution_contract_sha256') == sha(path), 'Execution contract was not frozen in request')
    contract = read(path)
    require(contract.get('schema') == 'g2-execution-contract953-v1'
            and contract.get('native_execution_authorized') is True, 'Separate authorized G2 execution contract required')
    require(contract.get('max_observers') == 2, 'G2 typed observer concurrency must be frozen at two')
    cap = contract.get('max_execution_attempts_per_logical_sample')
    require(type(cap) is int and cap > 0, 'Finite retry/attempt cap required')
    require(int(request['execution_attempt_id'].split('_')[1]) < cap, 'Execution attempt exceeds preregistered retry cap')
    entry = contract['admission_implementation']
    implementation = Path(entry['path']).resolve()
    require(implementation.is_relative_to(G) and implementation.suffix == '.py'
            and sha(implementation) == entry['sha256'], 'Private G2 admission implementation pin mismatch')
    require('s5_parallel_execution953_v2' not in implementation.parts, 'G1 admission approval cannot be reused for G2')
    module = load('_g2_admission_' + sha(path)[:16], implementation)
    require(callable(getattr(module, 'admit', None)), 'G2 admission provider must implement admit')
    require(callable(getattr(module, 'admit_observer', None)), 'G2 admission provider must implement admit_observer')
    return contract, module.admit, module.admit_observer


def verify_registration(request):
    require(request.get('plan_only') is False and request.get('execution_admitted') is True,
            'Draft requests cannot enter native execution')
    evidence = request.get('registration_receipt')
    require(isinstance(evidence, dict), 'Durable G2 registration receipt required')
    path = Path(evidence['path']).resolve()
    require(path.is_relative_to(G) and path.relative_to(G).parts[0].startswith('g2_')
            and sha(path) == evidence['sha256'], 'G2 registration receipt identity mismatch')
    registered = read(path)
    require(registered.get('schema') == 'g2-registration-receipt953-v1' and registered.get('registered') is True,
            'Registration evidence is only a draft')
    selected = [r for r in registered['requests'] if r.get('logical_sample_id') == request['logical_sample_id']
                and r.get('execution_attempt_id') == request['execution_attempt_id']]
    core = {k: v for k, v in request.items() if k != 'registration_receipt'}
    require(len(selected) == 1 and selected[0]['canonical_request_sha256'] == digest(core),
            'Actual G2 request differs from preregistered identity/vector/seed/resources')
    return evidence


def verify_and_consume_release(request, execution_contract):
    """Registered requests additionally need a single-use scheduler release."""
    entry = execution_contract.get('release_implementation', {})
    path = Path(entry.get('path', '')).resolve()
    require(path == G / 'g2_campaign953_v1/campaign.py' and sha(path) == entry.get('sha256'),
            'Frozen independent G2 release implementation required')
    module = load('_g2_release_' + entry['sha256'][:16], path)
    require(callable(getattr(module, 'consume_release', None)), 'Release provider must implement consume_release')
    return module.consume_release(request, execution_contract)


def verify_inputs(request):
    require(request.get('driver_dependency_sha256') == implementation_pins(), 'Driver/observer implementation pins missing or changed')
    require(sha(G / 'runtime_manifest.json') == request['runtime_manifest_sha256'], 'Runtime manifest changed')
    for artifact in request['source_artifacts']:
        require(sha(artifact['path']) == artifact['sha256'], 'Original source artifact changed')
    resource_schema = request['resource_contract'].get('schema')
    verifiers = {'g1-s5-receipt-backed-resource-contract953-v2': G / 's5_reference_resource_contract953_v2.py',
                 'g2-reference-resource-contract953-v1': G / 'g2_execution953_v1/reference_resources.py'}
    require(resource_schema in verifiers and verifiers[resource_schema].is_file(), 'Reference resource verifier unavailable')
    resource_module = load('_g2_reference_resource_contract', verifiers[resource_schema])
    resource_module.verify_request(request)
    return resource_module


def native_samples(group_leader):
    """Only actual schematic2layout Python processes; never timeout-parent RSS."""
    rows = []
    for entry in Path('/proc').glob('[0-9]*'):
        try:
            text = (entry / 'stat').read_text(); fields = text[text.rfind(')') + 2:].split()
            if int(fields[2]) != group_leader:
                continue
            argv = [x.decode(errors='replace') for x in (entry / 'cmdline').read_bytes().split(b'\0') if x]
            if not (argv and 'python' in Path(argv[0]).name
                    and str(ROOT / 'ALIGN-public/bin/schematic2layout.py') in argv[1:4]):
                continue
            mem = {x.split(':')[0]: int(x.split()[1]) for x in (entry / 'status').read_text().splitlines()
                   if x.startswith(('VmRSS:', 'VmHWM:'))}
            rows.append({'pid': int(entry.name), 'start_ticks': int(fields[19]), **mem})
        except (OSError, ValueError, IndexError):
            pass
    return rows


def monitor(process, timeout):
    start = time.monotonic(); peak = None; identities = {}; count = 0
    while process.poll() is None:
        samples = native_samples(process.pid)
        for row in samples:
            identities[str(row['pid']) + ':' + str(row['start_ticks'])] = row
        if samples:
            observed = sum(max(r.get('VmRSS', 0), r.get('VmHWM', 0)) for r in samples)
            peak = max(peak or 0, observed); count += 1
        if time.monotonic() - start > timeout:
            raise subprocess.TimeoutExpired(process.args, timeout)
        try:
            process.wait(timeout=.5)
        except subprocess.TimeoutExpired:
            pass
    return process.returncode, {'sampled_native_peak_rss_kib': peak, 'native_sample_count': count,
                               'native_identities': list(identities.values()), 'interval_s': .5,
                               'peak_is_sampled_not_exact': True, 'parent_RSS_used': False}


def make_attempt(request, admission, execution_contract, execution_contract_sha):
    """Load frozen implementation only after final-G1, resource and request gates."""
    for p in (G, ROOT / 'src'):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))
    frozen = load('_g2_frozen_s5_' + uuid.uuid4().hex, G / 'g1_s5_runner953_v2.py')
    out = Path(request['output_directory']).resolve()
    frozen.atomic = lambda path, value: atomic(path, value, out)
    original_effective = frozen.effective_configuration
    frozen.effective_configuration = lambda binding, masks, env, identity, **kwargs: original_effective(
        binding, masks, env, seeded_native_identity(request, identity), **kwargs)

    class Attempt(frozen.Attempt):
        def __init__(self):
            self.request = request; self.pair = request['pair']; self.top = self.pair['top']
            self.vector = list(request['vector']); self.bundle = Path(request['bundle_path']).resolve()
            self.out = out; self.work = out / 'work'; self.pdk = out / 'pdk'
            self.current = 'prepare'; self.native_env = {}; self.binding = None; self.base = None
            self.stages = {}; self.created_output = False; self.started = time.time()
            self.identity = frozen.install()
            self.result = {'schema': 'g2-native-attempt953-v1', 'request_sha256': digest(request),
                'config_id': request['config_id'], 'pair': self.pair, 'requested35': self.vector,
                'align_seed': request['align_seed'], 'sampling_seed': request['sampling_seed'],
                'execution_identity_sha256': digest(run_identity(request)), 'status': 'running',
                'G': None, 'C': None, 'L': None, 'metrics4': None,
                'connectivity_and_DRC': None, 'diagnostic_arithmetic_metrics4': None}
            import run_qualification
            self.admitted = run_qualification
            self.gd = frozen.load('_g2_dispatch_' + uuid.uuid4().hex,
                                  G / ('sky130_dispatch953.py' if self.pair['pdk'] == 'SKY130' else 'grouped35_dispatch.py'))
            self.gd.validate_vector(self.vector)
            if self.pair['pdk'] == 'SKY130':
                from sky130_validation953 import validate_pair
            else:
                import qualification_validation
                serializer = frozen.load('_g2_frozen_serializer_' + uuid.uuid4().hex,
                                          G / 'audit/metric_repair/align_hierarchy_serializer_v2.py')
                # Existing isolated GroundPorts serializer adapter; checker stays frozen.
                qualification_validation.serialize_hierarchical_final = serializer.serialize_hierarchical_final
                validate_pair = qualification_validation.validate_pair
            self.validator = validate_pair
            self.baseline_reference = list(self.gd.REFERENCE)

        def snapshot_sources(self):
            snapshot = self.out / 'source_snapshot'; snapshot.mkdir()
            for name in ('input', 'pdk'):
                shutil.copytree(self.bundle / name, snapshot / name,
                                ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            shutil.copy2(self.bundle / 'grouped35_native_baseline.json', snapshot / 'grouped35_native_baseline.json')
            originals = snapshot / 'original_sources'; originals.mkdir()
            sources = []
            for index, artifact in enumerate(request['source_artifacts']):
                destination = originals / (str(index) + '_' + Path(artifact['path']).name)
                shutil.copy2(artifact['path'], destination)
                sources.append({**artifact, 'preserved_copy': str(destination), 'copy_sha256': sha(destination)})
            atomic(self.out / 'source_provenance.json', {'original_source_artifacts': sources,
                   'adapted_input_tree_hash': self.input_hash, 'copied_source_PDK_tree_hash': request['source_pdk_tree_hash'],
                   'restored_original_PDK_tree_hash': self.pdk_hash}, self.out)
            atomic(self.out / 'resource_contract.json', request['resource_contract'], self.out)
            atomic(self.out / 'execution_contract.json', execution_contract, self.out)
            atomic(self.out / 'formal_contract.json', read(frozen.CONTRACT_PATH), self.out)
            launch = read(self.out / 'launch_contract.json')
            launch.update(schema='g2-fresh-launch-contract953-v1', align_seed=request['align_seed'],
                          sampling_seed=request['sampling_seed'], python_hash_seed=str(request['align_seed']),
                          execution_identity=run_identity(request), execution_identity_sha256=digest(run_identity(request)),
                          cache_reuse_allowed=False, execution_contract_sha256=execution_contract_sha,
                          driver_dependency_sha256=implementation_pins(), source_artifacts=sources)
            atomic(self.out / 'launch_contract.json', launch, self.out)

        def phase(self, name, flow):
            self.current = name
            require(flow == FLOWS[name], 'Frozen full-flow phase boundary changed')
            runtime = frozen.verify_runtime()
            require(frozen.source_hashes(self.pair['pdk']) == request['runner_dependency_sha256'],
                    'Frozen dispatcher/checker/metric dependencies changed')
            verify_inputs(request)
            if name == 'compile':
                self.snapshot_sources()
            plan = phase_plan(request, name)
            env = seed_environment(request, self.admitted.environment(), self.native_env)
            row = {**plan, 'status': 'waiting_for_resource', 'runtime_module_sha256': NATIVE_SHA,
                   'runtime_pythonpath': str(frozen.RUNTIME), 'runtime_check': runtime,
                   'reference_sha256': sha(ROOT / 'docs/param/reference_vector_35d.json'),
                   'applied_vector': self.vector, 'applied_vector_sha256': digest(self.vector),
                   'consumer_files_at_launch': self.launch_files(),
                   'native_environment_at_launch': dict(self.native_env),
                   'environment_seed': {'PYTHONHASHSEED': env['PYTHONHASHSEED']},
                   'binding_sha256': digest(self.binding['receipt']) if self.binding else None,
                   'address_space_limit_gib': plan['resource']['address_space_gib'],
                   'timeout_s': plan['resource']['timeout_s'], 'execution_contract_sha256': execution_contract_sha,
                   'resource_guard': 'explicit_G2_phase_admission', 'returncode': None}
            stdout = self.out / (name + '.stdout.log'); stderr = self.out / (name + '.stderr.log')
            row.update(stdout=str(stdout), stderr=str(stderr))
            row.pop('native_launch_performed', None)
            row['native_launch_requested'] = False
            expected = {**plan, 'request_canonical_sha256': digest(request),
                        'resource_signature': request['resource_contract']['resource_signature'],
                        'reference_contract_sha256': reference_contract_digest(request['resource_contract'])}
            atomic(Path(plan['expected_resource_profile']), expected, self.out)
            atomic(self.out / 'current_status.json', row, self.out)
            waiting = time.monotonic(); process = None
            try:
                with admission(request=request, phase=name, resource=plan['resource'],
                               execution_contract=execution_contract) as lease:
                    fds, metadata = lease
                    require(metadata.get('execution_contract_sha256') == execution_contract_sha,
                            'Admission lease does not bind this G2 execution contract')
                    require(all(type(fd) is int and fd >= 0 for fd in fds), 'Invalid admission lease descriptors')
                    row.update(admission=metadata, admission_wait_s=time.monotonic() - waiting,
                               status='running', start_epoch=time.time())
                    with stdout.open('x') as fo, stderr.open('x') as fe:
                        process = subprocess.Popen(plan['execution_command'], cwd=self.out, env=env,
                                                   stdout=fo, stderr=fe, start_new_session=True, pass_fds=tuple(fds))
                        frozen.ACTIVE_PROCESS = process; row['launcher_pid'] = process.pid
                        row['native_launch_requested'] = True
                        atomic(self.out / 'current_status.json', row, self.out)
                        code, memory = monitor(process, plan['resource']['timeout_s'] + 15)
                        row.update(returncode=code, memory=memory,
                                   status='completed' if code == 0 else 'timeout' if code == 124 else 'failed')
            except subprocess.TimeoutExpired:
                frozen.terminate(process); row.update(status='timeout', returncode=process.returncode)
            except BaseException as exc:
                frozen.terminate(process)
                row.update(status='failed', failure_class='phase_prelaunch' if process is None else 'phase_infrastructure',
                           error_type=type(exc).__name__, error=str(exc))
                raise
            finally:
                frozen.ACTIVE_PROCESS = None
                row['duration_s'] = time.time() - row['start_epoch'] if 'start_epoch' in row else None
                row['resource_exec_profile_present'] = Path(plan['resource_receipt']).is_file()
                if row['resource_exec_profile_present']:
                    row['actual_resource_profile'] = {'path': plan['resource_receipt'], 'sha256': sha(plan['resource_receipt'])}
                row['log_tail'] = ''.join(p.read_text(errors='replace')[-3000:] for p in (stderr, stdout) if p.exists())[-5000:]
                atomic(self.out / (name + '.json'), row, self.out)
                atomic(self.out / 'current_status.json', row, self.out)
                self.stages[name] = row
            if row['status'] != 'completed':
                raise frozen.StageFailure(name, row['status'] + ': ' + row['log_tail'][-1600:])
            require(row['resource_exec_profile_present'], 'Missing actual resource exec profile')
            return row

    return Attempt(), frozen


def final_row(request, raw, derived=None):
    observed = normalize_observation(raw, derived)
    gates = observed.get('gates') or {}
    peaks = [r.get('memory', {}).get('sampled_native_peak_rss_kib') for r in raw.get('stages', {}).values()
             if isinstance(r.get('memory'), dict)]
    peaks = [v for v in peaks if v is not None]
    return {'schema': 'g2-final-observation953-v1', 'dataset_version': request['dataset_version'],
            'campaign_id': request['campaign_id'], 'logical_sample_id': request['logical_sample_id'],
            'execution_attempt_id': request['execution_attempt_id'], 'input_version': request['input_version'],
            'pair': request['pair'], 'align_seed': request['align_seed'], 'sampling_seed': request['sampling_seed'],
            'matched_block_id': request.get('matched_block_id'), 'requested35': request['vector'],
            'status': raw['status'], 'failure_stage': raw.get('failure_stage'),
            'failure_class': raw.get('failure_class'), 'native_status_preserved': True,
            'flow_complete': all(raw.get('stages', {}).get(p, {}).get('status') == 'completed' for p in PHASES),
            'geometry_complete': gates.get('complete_owned_geometry'), 'binding_verified': gates.get('binding_verified'),
            'runtime_hash': request['runtime_sha256'], 'adapted_input_hash': request['source_input_tree_hash'],
            'source_artifacts': request['source_artifacts'], 'original_pdk_source_hash': request['source_pdk_tree_hash'],
            'sampled_native_peak_rss_kib': max(peaks) if peaks else None,
            'runtime_s': raw.get('wall_time_s'), 'stage_status': raw.get('stages'),
            'effective_configuration': raw.get('effective_configuration'), 'masks35': raw.get('masks'),
            'effective35': None, 'effective35_status': 'object-specific raw bindings retained; scalar inversion not claimed',
            'per_rule_DRC': None, 'per_rule_DRC_status': 'not_yet_aggregated',
            'execution_identity_sha256': digest(run_identity(request)),
            'artifact_paths': {'raw_result': str(Path(request['output_directory']) / 'result.json'),
                               'run': request['output_directory'],
                               'group_object_map': str(Path(request['output_directory']) / 'binding.json')}, **observed}


def run_typed_observer(request, execution_contract, observer_admission):
    """Independent derived observation holds every admission FD until child exit."""
    out = Path(request['output_directory']).resolve()
    command = [str(ROOT / 'ALIGN-public/general/bin/python'), '-B', str(HERE / 'typed_observer_adapter.py'),
               '--run', str(out), '--out', str(out / 'typed_observation')]
    observer_cwd = out / 'typed_observer_cwd'; observer_cwd.mkdir()
    waiting = time.monotonic()
    receipt = {'schema': 'g2-typed-observer-admission953-v1', 'status': 'waiting', 'command': command,
               'execution_contract_sha256': request['execution_contract_sha256'],
               'native_runs_started': 0, 'is_native_process': False, 'returncode': None}
    atomic(out / 'typed_observer_admission.json', receipt, out)
    try:
        require(execution_contract.get('max_observers') == 2 and callable(observer_admission),
                'Explicit two-observer admission required')
        with observer_admission(request=request, execution_contract=execution_contract) as (fds, metadata):
            require(metadata.get('execution_contract_sha256') == request['execution_contract_sha256'],
                    'Observer lease does not bind this G2 execution contract')
            require(bool(fds) and all(type(fd) is int and fd >= 0 for fd in fds),
                    'Observer lease descriptors required')
            receipt.update(status='running', admission=metadata, admission_wait_s=time.monotonic() - waiting,
                           start_epoch=time.time(), inherited_lease_descriptor_count=len(fds))
            atomic(out / 'typed_observer_admission.json', receipt, out)
            with (out / 'typed_observer.stdout.log').open('x') as fo, (out / 'typed_observer.stderr.log').open('x') as fe:
                code = subprocess.run(command, cwd=observer_cwd, env=seed_environment(request, os.environ),
                                      stdout=fo, stderr=fe, pass_fds=tuple(fds)).returncode
            receipt.update(status='completed' if code == 0 else 'failed', returncode=code)
        require(code == 0, 'Typed observer returned ' + str(code))
        return read(out / 'typed_observation/dataset_observation.json')
    except BaseException as exc:
        receipt.update(status='unresolved', error_type=type(exc).__name__, error=str(exc))
        raise
    finally:
        receipt.update(finished_epoch=time.time(),
                       duration_s=time.time() - receipt['start_epoch'] if 'start_epoch' in receipt else None)
        atomic(out / 'typed_observer_admission.json', receipt, out)


def execute_request(request, ledger_dir, execution_contract_path):
    """Every submitted attempt gets a durable ledger, including constructor errors."""
    ledger_root = Path(ledger_dir).resolve()
    require(ledger_root.is_relative_to(G) and ledger_root != G
            and ledger_root.relative_to(G).parts[0].startswith('g2_'),
            'Submission ledger must be a new private G2 directory')
    ledger_root.mkdir(parents=True, exist_ok=True)
    ledger = ledger_root / ('submission_' + uuid.uuid4().hex); ledger.mkdir()
    record = {'schema': 'g2-submission-ledger953-v1', 'created_epoch': time.time(),
              'logical_sample_id': request.get('logical_sample_id') if isinstance(request, dict) else None,
              'execution_attempt_id': request.get('execution_attempt_id') if isinstance(request, dict) else None,
              'status': 'received', 'native_attempt_count': 0, 'retained_in_attempt_denominator': True}
    atomic(ledger / 'submission.json', record, ledger)
    try:
        atomic(ledger / 'received_request.json', request, ledger)
    except (TypeError, ValueError):
        (ledger / 'unserializable_request.txt').write_text(repr(request))
    attempt = None; frozen = None; old_cwd = Path.cwd(); saved_signals = {}
    try:
        validate_request(request)
        verify_registration(request)
        verify_g1_final(request)
        verify_inputs(request)
        require(os.environ.get('PYTHONHASHSEED') == str(request['align_seed']),
                'Driver interpreter must start with request PYTHONHASHSEED; use the run CLI bootstrap')
        contract, admission, observer_admission = verify_execution_contract(request, execution_contract_path)
        out = Path(request['output_directory']).resolve()
        require(not out.exists(), 'Fresh G2 output required; existing results are never overwritten')
        record['execution_release_consumed'] = verify_and_consume_release(request, contract)
        cwd = ledger / 'import_cwd'; cwd.mkdir(); os.chdir(cwd)
        attempt, frozen = make_attempt(request, admission, contract, sha(execution_contract_path))
        for sig in (signal.SIGTERM, signal.SIGINT):
            saved_signals[sig] = signal.signal(sig, frozen.interrupted)
        try:
            attempt.run()  # Frozen five-stage dispatch/mask/checker/metric flow, overridden phase/identity only.
        except frozen.StageFailure as exc:
            attempt.result.update(status='failed', G=False, C=False, L=False, metrics4=None,
                                  failure_stage=exc.stage, failure_reason=exc.reason,
                                  failure_class='timeout' if exc.reason.startswith('timeout') else 'native_or_binding_failure')
        except Exception as exc:
            attempt.result.update(status='failed', G=False, C=False, L=False, metrics4=None,
                                  failure_stage=attempt.current, failure_reason=str(exc),
                                  failure_class='infrastructure_or_interface', traceback=traceback.format_exc())
        raw = attempt.result
        raw.update(wall_time_s=time.time() - attempt.started,
                   stages={k: {f: v.get(f) for f in ('status', 'returncode', 'duration_s', 'runtime_module_sha256', 'memory')}
                           for k, v in attempt.stages.items()})
        if not attempt.created_output:
            raise RuntimeError('Attempt failed before owning a fresh output directory')
        atomic(out / 'result.json', raw, out)
        raw_hash = sha(out / 'result.json'); derived = None; observation_error = None
        if request['pair']['pdk'] == 'SKY130' and raw.get('status') in ('G_complete', 'incomplete'):
            try:
                derived = run_typed_observer(request, contract, observer_admission)
            except Exception as exc:
                observation_error = {'status': 'typed_observation_unresolved', 'error_type': type(exc).__name__,
                                     'error': str(exc), 'raw_native_status_unchanged': True}
        require(sha(out / 'result.json') == raw_hash, 'Independent observation changed raw result')
        final = final_row(request, raw, derived)
        final['raw_result_sha256'] = raw_hash
        final['observation_error'] = observation_error
        if observation_error:
            final.update(G=None, C=None, L=None, metrics4=None, geometry_training_eligible=False,
                         high_quality_reward_eligible=False, observation_source='unresolved_typed_observer')
        atomic(out / 'final_observation.json', final, out)
        record.update(status='terminal', output_directory=str(out), result_sha256=raw_hash,
                      final_observation_sha256=sha(out / 'final_observation.json'),
                      native_attempt_count=int(any(r.get('native_launch_requested') for r in attempt.stages.values())),
                      native_phase_launch_count=sum(bool(r.get('native_launch_requested')) for r in attempt.stages.values()),
                      native_status=raw['status'], G=final['G'], C=final['C'], L=final['L'])
        return final
    except BaseException as exc:
        record.update(status='prelaunch_failure' if attempt is None else 'driver_failure',
                      error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc(),
                      G=None, C=None, L=None, metrics4=None,
                      native_attempt_count=int(any(r.get('native_launch_requested') for r in attempt.stages.values())) if attempt else 0,
                      native_phase_launch_count=sum(bool(r.get('native_launch_requested')) for r in attempt.stages.values()) if attempt else 0)
        return copy.deepcopy(record)
    finally:
        for sig, handler in saved_signals.items():
            signal.signal(sig, handler)
        os.chdir(old_cwd)
        record['finished_epoch'] = time.time()
        atomic(ledger / 'submission.json', record, ledger)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    plan = sub.add_parser('plan'); plan.add_argument('--request', type=Path, required=True)
    run = sub.add_parser('run'); run.add_argument('--request', type=Path, required=True)
    run.add_argument('--ledger-dir', type=Path, required=True)
    run.add_argument('--execution-contract', type=Path, required=True)
    sub.add_parser('implementation-pins')
    args = parser.parse_args()
    if args.command == 'implementation-pins':
        result = implementation_pins()
    elif args.command == 'plan':
        request = read(args.request)
        result = {'schema': 'g2-execution-plan953-v1', 'native_execution_performed': False,
                  'phases': [phase_plan(request, phase) for phase in PHASES],
                  'readiness_not_asserted': True, 'cache_reuse_allowed': False}
    else:
        # Malformed JSON also enters the submission ledger as a retained input error.
        try:
            request = read(args.request)
        except Exception as exc:
            request = {'schema': 'invalid-request-file', 'request_path': str(args.request),
                       'read_error': str(exc), 'raw_text': args.request.read_text(errors='replace') if args.request.is_file() else None}
        seed = request.get('align_seed')
        if type(seed) is int and 0 <= seed <= 2**32 - 1 and os.environ.get('PYTHONHASHSEED') != str(seed):
            # Environment changes alone cannot reseed an already running Python
            # interpreter. Re-exec before importing any dispatcher/validator.
            env = dict(os.environ, PYTHONHASHSEED=str(seed), PYTHONDONTWRITEBYTECODE='1')
            os.execvpe(sys.executable, [sys.executable, '-B', str(Path(__file__).resolve()), *sys.argv[1:]], env)
        result = execute_request(request, args.ledger_dir, args.execution_contract)
    print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
    if args.command == 'run' and result.get('status') in ('prelaunch_failure', 'driver_failure'):
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
