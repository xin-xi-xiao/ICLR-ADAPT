"""Pure G2 request, resource and command interfaces. Import starts no work."""
from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
G = HERE.parent
ROOT = G.parents[2]
OUTPUT_ROOT = G / 'g2_runtime953_v1'
NATIVE_SHA = '953242f473f836d0c4317a01a767f96fe3c44e7bbb351e9f4aaa0c8647fd7e52'
SCHEMA = 'g2-run-request953-v1'
PHASES = ('compile', 'primitives', 'placement', 'routing_bootstrap', 'routing_reference_s5')
FLOWS = {
    'compile': ['--flow_stop', '1_topology'],
    'primitives': ['--flow_start', '2_primitives', '--flow_stop', '2_primitives'],
    'placement': ['--flow_start', '3_pnr:prep', '--flow_stop', '3_pnr:place'],
    'routing_bootstrap': ['--flow_start', '3_pnr:gui', '--flow_stop', '3_pnr:route'],
    'routing_reference_s5': ['--flow_start', '3_pnr:gui', '--flow_stop', '3_pnr:route'],
}
BASE_PHASES = ('compile', 'primitives', 'placement', 'routing')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    if isinstance(value, float):
        require(math.isfinite(value), 'Nonfinite identity value')
        return int(value) if value.is_integer() else value
    if isinstance(value, dict):
        return {str(k): canonical(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [canonical(v) for v in value]
    return value


def digest(value):
    data = json.dumps(canonical(value), sort_keys=True, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(data.encode()).hexdigest()


def reference_contract_digest(value):
    """Byte-compatible with frozen resource V2, including 1200.0 versus 1200."""
    if value.get('schema') == 'g2-reference-resource-contract953-v1':
        return digest(value)
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def base_phase(phase):
    require(phase in PHASES, 'Unknown native phase')
    return 'routing' if phase.startswith('routing') else phase


def resource_for_phase(request, phase):
    """Never supply default AS/timeout/stack where a contract is missing."""
    contract = request.get('resource_contract')
    require(isinstance(contract, dict) and contract.get('required') is True
            and contract.get('full_flow_receipts_verified') is True, 'Receipt-backed resource contract required')
    base = base_phase(phase)
    per_phase = contract.get('schema') == 'g2-reference-resource-contract953-v1'
    resource_key = phase if per_phase else base
    resource = copy.deepcopy(contract['phase_resources'][resource_key])
    timeout, address_space = resource['timeout_s'], resource['address_space_gib']
    require(type(timeout) in (int, float) and math.isfinite(timeout) and timeout > 0, 'Invalid exact timeout')
    require(type(address_space) is int and address_space > 0, 'Invalid exact AS')
    require(request.get('stage_timeouts', {}).get(resource_key) == timeout, 'Request timeout differs from reference')
    require(request.get('stage_address_space_gib', {}).get(resource_key) == address_space, 'Request AS differs from reference')
    require(request.get('resource_policy') == contract.get('resource_policy'), 'Resource policy mismatch')
    stack = resource['stack']
    require(stack.get('mode') in ('explicit_soft_limit', 'default_unmodified'), 'Unknown reference stack mode')
    if stack['mode'] == 'explicit_soft_limit':
        require(type(stack.get('soft_bytes')) is int and stack['soft_bytes'] > 0, 'Explicit stack value missing')
        require((per_phase and request.get('stack_soft_limit_bytes') is None)
                or request.get('stack_soft_limit_bytes') == stack['soft_bytes'], 'Exact reference stack mismatch')
    else:
        require(stack.get('soft_bytes') is None and request.get('stack_soft_limit_bytes') is None,
                'Default-unmodified stack cannot acquire a numeric override')
    require(isinstance(contract.get('resource_signature'), str) and contract['resource_signature'],
            'Reference resource signature missing')
    return resource


def validate_request(request):
    require(isinstance(request, dict) and request.get('schema') == SCHEMA, 'Explicit G2 request schema required')
    for field in ('dataset_version', 'campaign_id', 'input_version', 'logical_sample_id', 'execution_attempt_id', 'config_id'):
        require(isinstance(request.get(field), str) and request[field], 'Missing ' + field)
    for field in ('campaign_id', 'logical_sample_id', 'execution_attempt_id'):
        require(re.fullmatch(r'[A-Za-z0-9_.-]+', request[field]) and request[field] not in ('.', '..'),
                'Unsafe identity path component: ' + field)
    require(re.fullmatch(r'attempt_[0-9]{3}', request['execution_attempt_id']), 'Explicit attempt_NNN identity required')
    seed = request.get('align_seed')
    require(type(seed) is int and 0 <= seed <= 2**32 - 1, 'Explicit uint32 ALIGN seed required; bool is not a seed')
    require(type(request.get('sampling_seed')) is int and request['sampling_seed'] >= 0, 'Separate sampling_seed required')
    pair = request.get('pair', {})
    require(pair.get('pdk') in ('14nm', '65nm', 'SKY130'), 'Only final three PDKs supported')
    for field in ('case_id', 'top', 'circuit_name'):
        require(isinstance(pair.get(field), str) and pair[field], 'Missing pair.' + field)
    for field in ('case_id', 'pdk'):
        require(request.get(field, pair[field]) == pair[field], 'Top-level/pair identity conflict: ' + field)
    vector = request.get('vector')
    require(isinstance(vector, list) and len(vector) == 35, 'Exactly 35 requested coordinates required')
    require(all(type(v) in (int, float) and math.isfinite(v) for v in vector), 'Coordinates must be finite numeric values')
    require(request.get('runtime_sha256') == NATIVE_SHA, 'Frozen runtime identity missing or changed')
    for field in ('runtime_manifest_sha256', 'contract_sha256', 'source_input_tree_hash',
                  'source_pdk_tree_hash', 'source_baseline_sha256'):
        require(isinstance(request.get(field), str) and re.fullmatch(r'[a-f0-9]{64}', request[field]),
                'Missing/invalid hash: ' + field)
    out = Path(request['output_directory']).resolve()
    allowed = (OUTPUT_ROOT / request['campaign_id']).resolve()
    require(allowed.is_relative_to(OUTPUT_ROOT.resolve()) and out.is_relative_to(allowed) and out != allowed,
            'G2 output must stay in its independent campaign namespace')
    require(out.name == request['execution_attempt_id'] and out.parent.name == request['logical_sample_id'],
            'Output path must encode logical sample and execution attempt')
    require(Path(request['bundle_path']).is_absolute(), 'Absolute reference bundle path required')
    require(isinstance(request.get('source_artifacts'), list) and request['source_artifacts'], 'Raw source artifacts required')
    for artifact in request['source_artifacts']:
        require(Path(artifact['path']).is_absolute() and re.fullmatch(r'[a-f0-9]{64}', artifact['sha256']),
                'Raw source artifact requires absolute path and SHA')
    for phase in PHASES:
        resource_for_phase(request, phase)
    return request


def run_identity(request):
    """Seed-sensitive execution/cache candidate identity; reuse remains disabled."""
    validate_request(request)
    return {
        'case_id': request['pair']['case_id'], 'pdk': request['pair']['pdk'], 'top': request['pair']['top'],
        'input_version': request['input_version'], 'adapted_input_tree_hash': request['source_input_tree_hash'],
        'source_artifacts': request['source_artifacts'], 'source_pdk_tree_hash': request['source_pdk_tree_hash'],
        'source_baseline_sha256': request['source_baseline_sha256'],
        'runtime_sha256': request['runtime_sha256'], 'runtime_manifest_sha256': request['runtime_manifest_sha256'],
        'formal_contract_sha256': request['contract_sha256'], 'requested35': list(request['vector']),
        'align_seed': request['align_seed'], 'python_hash_seed': str(request['align_seed']),
        'resource_contract_sha256': reference_contract_digest(request['resource_contract']),
        'runner_dependency_sha256': request.get('runner_dependency_sha256'),
        'driver_dependency_sha256': request.get('driver_dependency_sha256'),
        'observation_protocol': request.get('observation_protocol', 'frozen_GCL_plus_SKY_typed_v4'),
    }


def seed_environment(request, base_environment, native_environment=None):
    validate_request(request)
    env = {k: v for k, v in base_environment.items() if not k.startswith('ADAPT_R6_')}
    env.update(native_environment or {})
    env.update(PYTHONHASHSEED=str(request['align_seed']), PYTHONDONTWRITEBYTECODE='1',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    return env


def seeded_native_identity(request, identity):
    """Keep matched-action context independent of the requested action vector."""
    require(identity['case_id'] == request['pair']['case_id'] and identity['pdk'] == request['pair']['pdk'],
            'Frozen observation supplied a different pair identity')
    return {**identity, 'align_seed': request['align_seed'], 'python_hash_seed': str(request['align_seed']),
            'input_version': request['input_version'], 'runtime_manifest_sha256': request['runtime_manifest_sha256'],
            'resource_contract_sha256': reference_contract_digest(request['resource_contract'])}


def phase_plan(request, phase):
    validate_request(request)
    resource = resource_for_phase(request, phase)
    out = Path(request['output_directory']).resolve()
    python = ROOT / 'ALIGN-public/general/bin/python'
    command = [str(python), str(ROOT / 'ALIGN-public/bin/schematic2layout.py'), str(out / 'input'),
               '-p', str(out / 'pdk'), '-w', str(out / 'work'), '-s', request['pair']['top'],
               '-n', '1', '-e', '0', '--nroutings', '1', '--lambda_coeff', str(request['vector'][0]),
               '--seed', str(request['align_seed']), *FLOWS[phase]]
    profile = out / 'resource_profiles' / (phase + '.expected.json')
    observed = out / 'resource_profiles' / (phase + '.json')
    execution = ['/usr/bin/timeout', '--signal=TERM', '--kill-after=10s', str(float(resource['timeout_s'])) + 's',
                 '/usr/bin/prlimit', '--as=' + str(resource['address_space_gib'] * 1024**3), '--',
                 str(python), '-B', str(HERE / 'resource_wrapper.py'), '--profile', str(profile),
                 '--receipt', str(observed), '--', *command]
    return {'phase': phase, 'command': command, 'execution_command': execution,
            'resource': resource, 'expected_resource_profile': str(profile), 'resource_receipt': str(observed),
            'align_seed': request['align_seed'], 'PYTHONHASHSEED': str(request['align_seed']),
            'execution_identity_sha256': digest(run_identity(request)), 'cache_reuse_allowed': False,
            'native_launch_performed': False}


def verify_seed_receipts(request, receipts, launch):
    """Fail closed before reusing a frozen observer that formerly assumed seed=1."""
    seed = request['align_seed']
    require(launch.get('align_seed') == seed and launch.get('python_hash_seed') == str(seed), 'Launch seed mismatch')
    for phase in PHASES:
        row = receipts[phase]
        command = row['command']
        require(command.count('--seed') == 1 and command[command.index('--seed') + 1] == str(seed),
                'Actual phase CLI seed mismatch: ' + phase)
        require(row.get('align_seed') == seed and row.get('environment_seed', {}).get('PYTHONHASHSEED') == str(seed),
                'Actual phase environment/seed receipt mismatch: ' + phase)
    return True


def normalize_observation(raw, derived=None):
    """G/C/L remain independent of strict legal; unknown stays null."""
    authoritative = derived if derived is not None else raw
    result = {k: authoritative.get(k) for k in ('G', 'C', 'L', 'gates', 'connectivity_and_DRC',
              'metrics4', 'diagnostic_arithmetic_metrics4', 'strict_validator_legal')}
    metrics = result['metrics4']
    if result['G'] is True:
        require(isinstance(metrics, list) and len(metrics) == 4 and
                all(type(v) in (int, float) and math.isfinite(v) for v in metrics), 'G requires finite metrics4')
    else:
        result['metrics4'] = None
    require(result['C'] is not True or result['G'] is True, 'C cannot bypass G')
    require(result['L'] is not True or result['C'] is True, 'L cannot bypass C')
    result.update(geometry_training_eligible=result['G'] is True,
                  high_quality_reward_eligible=result['C'] is True,
                  observation_source='typed_derived' if derived is not None else 'raw')
    return result
