"""Read-only, selected-hierarchy G/C/L audit of the runtime953 reference batch.

Does not import ALIGN, run layout, modify a receipt, or mask checker errors.
Only the two new aggregate report files are written, with exclusive creation.
"""
from __future__ import annotations

import collections
import hashlib
import json
import math
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "src"))
from adapt.postlayout.geometry_metrics import compute_geometry_metrics

SHA953 = "953242f473f836d0c4317a01a767f96fe3c44e7bbb351e9f4aaa0c8647fd7e52"
METRICS = ("A_eval", "L_eq_signal", "L_eq_power", "N_cut_intermetal")
PHASES = ("compile", "primitives", "placement", "routing", "routing_reference_v1")
SOURCE = HERE / "s4_fixed14_65_run_runtime953"
FINAL = HERE / "s4_reference_runtime953_v1"


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def evidence(path):
    path = Path(path)
    return {"path": str(path), "exists": path.is_file(),
            "sha256": sha(path) if path.is_file() else None}


def verify_record(record):
    p = Path(record.get("path", "/nonexistent"))
    return record.get("exists") is True and p.is_file() and sha(p) == record.get("sha256")


def classify(gates, counts):
    """Unknown rule semantics cannot be silently promoted to C or L."""
    g = all(gates.values())
    c = g and counts["OPEN"] == 0 and counts["SHORT"] == 0 and counts["unknown"] == 0
    l = c and counts["DRC"] == 0
    return {"G": g, "C": c, "L": l,
            "tier": "L" if l else "C" if c else "G" if g else "incomplete"}


def runtime_identity():
    manifest = read(HERE / "runtime_manifest.json")
    runtime = HERE / "runtime_953/pythonpath"
    mismatches = [x["path"] for x in manifest["copied_runtime_files"]
                  if not (runtime / x["path"]).is_file() or sha(runtime / x["path"]) != x["sha256"]]
    return {"native_sha256": SHA953, "manifest": evidence(HERE / "runtime_manifest.json"),
            "runtime_pythonpath": str(runtime), "verified_files": len(manifest["copied_runtime_files"]),
            "mismatches": mismatches, "matches_S0": not mismatches}


def earliest_failure(pair):
    directory = Path(pair.get("source_directory", SOURCE / pair["case_id"] / pair["pdk"]))
    for phase in PHASES[:4]:
        path = directory / f"{phase}.json"
        if not path.is_file():
            return {"stage": phase, "reason": "missing stage receipt", "receipt": str(path)}
        receipt = read(path)
        if receipt.get("status") != "completed" or receipt.get("returncode") != 0:
            tail = receipt.get("log_tail", "")
            terminal = [s for s in tail.splitlines() if any(t in s for t in
                        ("AssertionError:", "RuntimeError:", "Reflection is not supported", "0 placement solution", "ValidationError:"))]
            return {"stage": phase, "status": receipt.get("status"), "returncode": receipt.get("returncode"),
                    "reason": "\n".join(terminal[-5:]) or tail[-1200:],
                    "receipt": evidence(path), "stdout": receipt.get("stdout"), "stderr": receipt.get("stderr")}
    return None


def observe(pair, runtime_ok):
    directory = Path(pair.get("reference_directory", FINAL / pair["case_id"] / pair["pdk"]))
    result = {k: pair.get(k) for k in ("case_id", "circuit_name", "pdk", "lineage_id", "source_path")}
    result.update({"run_directory": str(directory), "source_run_directory": str(pair.get("source_directory", SOURCE / pair["case_id"] / pair["pdk"])),
                   "data_generation_ready": False, "other_effective_configuration_count": 0,
                   "qualification_note": "Reference only; two additional distinct effective full-flow configurations remain required."})
    result["earliest_failure"] = earliest_failure(pair)
    if not directory.is_dir():
        result.update({"G": False, "C": False, "L": False, "tier": "incomplete", "reference_finalized": False,
                       "metrics4": None, "missing": "reference full-flow was not reached"})
        return result

    vpath = Path(pair.get("validation_path", directory / "validation_result.json"))
    v = read(vpath)
    binding = read(directory / "reference_binding_audit.json")
    masks = read(directory / "actual35_masks.json")
    geompath = Path(pair.get("geometry_path", directory / "validation_reference/qualification_full_layout_geometry.json"))
    geom = read(geompath)
    checks = v.get("checks", {})
    stage_receipts = {}
    phases_complete = True
    runtime_match = runtime_ok
    for phase in PHASES:
        path = directory / f"{phase}.json"
        d = read(path) if path.is_file() else {}
        ok = d.get("status") == "completed" and d.get("returncode") == 0
        native_ok = d.get("runtime_module_sha256") == SHA953
        phases_complete &= ok
        runtime_match &= native_ok
        stage_receipts[phase] = {**evidence(path), "completed": ok, "native_sha_matches": native_ok,
                                 "runtime_module_sha256": d.get("runtime_module_sha256"),
                                 "duration_s": d.get("duration_s"), "returncode": d.get("returncode")}

    required = checks.get("required_artifacts", {})
    artifact_checks = {name: verify_record(rec) for name, rec in required.items()}
    artifact_checks["primitive_library"] = (directory / "work/1_topology/__primitives_library__.json").is_file()
    module_checks = checks.get("selected_module_checks", [])
    used_modules = set(checks.get("selected_hierarchy", {}).get("used_modules", []))
    checked_modules = {m["module"] for m in module_checks}
    counts = {"OPEN": 0, "SHORT": 0, "DRC": 0, "unknown": 0, "accepted_explained_diagnostics": 0}
    classified = collections.Counter()
    per_module = []
    errors_verified = True
    for module in module_checks:
        diagnostics = module.get("diagnostics", [])
        verified = verify_record(module.get("error_file", {})) and verify_record(module.get("viewer", {}))
        raw = Path(module["error_file"]["path"])
        lines = [line for line in raw.read_text().splitlines() if line.strip()] if raw.is_file() else []
        # These are exact selected .errors entries, not a broad log search.
        verified &= len(lines) == module.get("raw_error_count") == len(diagnostics)
        verified &= lines == [d.get("raw") for d in diagnostics]
        errors_verified &= verified
        mc = collections.Counter()
        for diag in diagnostics:
            kind = diag.get("classification", "unknown")
            classified[kind] += 1
            if diag.get("accepted") is True and kind == "proven_rvt_marker_width_diagnostic":
                key = "accepted_explained_diagnostics"
            elif kind == "open":
                key = "OPEN"
            elif kind == "short":
                key = "SHORT"
            elif kind == "drc_error":
                key = "DRC"
            else:
                key = "unknown"
            counts[key] += 1
            mc[key] += 1
        per_module.append({"module": module["module"], "evidence_verified": verified,
                           "error_file": module["error_file"], "counts": dict(mc)})

    metrics = compute_geometry_metrics(geom, reference_widths_um=geom["reference_widths_um"])
    vector = [metrics.get(k, {}).get("value") for k in METRICS]
    finite = all(type(x) in (int, float) and math.isfinite(x) for x in vector)
    finite &= all(metrics.get(k, {}).get("status") == "ok" for k in METRICS)
    geometry_complete = (geom.get("geometry_complete") is True and geom.get("full_layout_geometry") is True
                         and geom.get("ownership_coverage", {}).get("ownership_complete") is True
                         and geom.get("metric_eligibility") == "eligible"
                         and metrics.get("unknown_geometry_count") == 0)
    binding_ok = binding.get("reference_binding_verified") is True
    binding_ok &= all(binding.get(k) is True for k in
                      ("consumer_inputs_unchanged_since_launch", "native_environment_exact",
                       "placement_primitive_requests_unchanged_from_executed_first_stages",
                       "primitive_library_matches_bound_input", "required_consumer_snapshot_complete",
                       "PGR_serialized_bindings_match", "P01_placement_CLI_matches"))
    binding_ok &= binding.get("native_consumer_verification") == "verified"
    mask_ok = masks.get("route_phase") == "routing_reference_v1"
    mask_ok &= all(masks.get("launch_identity", {}).get(k) is True for k in
                   ("formal_phase", "binary_sha_matches", "reference_sha_matches", "native_environment_matches"))
    mask_names = ("object_mask", "decoded_choice_mask", "serialized_binding_mask", "primitive_generated_mask",
                  "generator_shape_registry_mask", "runtime_consumer_call_mask", "runtime_operation_mask", "metric_effect_mask")
    mask_ok &= all(len(masks.get(k, [])) == 35 for k in mask_names)
    gates = {"all_five_phases_completed": phases_complete, "frozen_runtime953": runtime_match,
             "reference_binding_verified": binding_ok, "postroute_masks_with_launch_identity": mask_ok,
             "required_artifacts_intact": len(required) >= 5 and all(artifact_checks.values()),
             "checker_selected_hierarchy_complete": bool(used_modules) and used_modules == checked_modules and errors_verified,
             "complete_owned_geometry": geometry_complete, "four_metrics_finite": finite,
             "explicit_power_and_ground": bool(checks.get("explicit_power_declarations", {}).get("power"))
              and bool(checks.get("explicit_power_declarations", {}).get("ground"))}
    result.update(classify(gates, counts))
    result.update({"reference_finalized": True, "gates": gates, "strict_validator_legal": v.get("legal"),
                   "stages": stage_receipts, "selected_id": v.get("selected_id"), "validation": evidence(vpath),
                   "binding": evidence(directory / "reference_binding_audit.json"), "geometry": evidence(geompath),
                   "geometry_eligibility_reasons": geom.get("eligibility_reasons", []),
                   "metrics4": vector if result["G"] else None,
                   "diagnostic_arithmetic_metrics4": vector, "metric_names": list(METRICS),
                   "metric_implementation_sha256": sha(ROOT / "src/adapt/postlayout/geometry_metrics.py"),
                   "connectivity_and_DRC": counts, "diagnostic_classifications": dict(classified),
                   "selected_module_checks": per_module, "validator_failures": v.get("failures", []),
                   "masks": {k: masks.get(k) for k in mask_names},
                   "mask_counts": {k: {"true": masks[k].count(True), "false": masks[k].count(False),
                                       "unknown": masks[k].count(None)} for k in mask_names},
                   "mask_evidence": evidence(directory / "actual35_masks.json")})
    return result


def main():
    identity = runtime_identity()
    pairs = read(HERE / "s4_fixed14_65_manifest_runtime953.json")["pairs"]
    rows = [observe(pair, identity["matches_S0"]) for pair in pairs]
    # Three focused acceptance checks: DRC alone is not flow failure; ownership
    # failure remains rejected; removing route proof must reject valid geometry.
    drc = next(x for x in rows if x["circuit_name"] == "TELESCOPIC_OTA_WITH_BIAS" and x["pdk"] == "14nm")
    assert drc["G"] and drc["C"] and not drc["L"] and drc["connectivity_and_DRC"]["DRC"] == 1
    owned = next(x for x in rows if x["circuit_name"] == "REFERENCE_BUFFER_CORE" and x["pdk"] == "14nm")
    assert not owned["G"] and not owned["gates"]["complete_owned_geometry"] and owned["metrics4"] is None
    missing = dict(drc["gates"], all_five_phases_completed=False)
    assert not classify(missing, drc["connectivity_and_DRC"])["G"]
    counts = {k: sum(x.get(k) is True for x in rows) for k in ("reference_finalized", "G", "C", "L")}
    intersection = [name for name in sorted({x["circuit_name"] for x in rows})
                    if sum(x["G"] for x in rows if x["circuit_name"] == name) == 2]
    report = {"schema": "g1-reference953-readonly-observation-v2", "runtime_identity": identity,
              "all_pair_attempt_denominator": len(rows), "counts": counts,
              "by_pdk": {pdk: {k: sum(x.get(k) is True for x in rows if x["pdk"] == pdk)
                                 for k in ("reference_finalized", "G", "C", "L")} for pdk in ("14nm", "65nm")},
              "two_fixed_domain_G_reference_intersection": intersection,
              "G1_qualified_pairs": 0, "G1_qualified_three_domain_circuits": 0,
              "new_ALIGN_runs_launched": 0, "existing_artifacts_modified": False,
              "tests": {"nonzero_DRC_preserved": True, "incomplete_ownership_rejected": True, "missing_routing_rejected": True},
              "limitations": ["Reference observations only, no additional effective configs counted.",
                              "No third-PDK selection or circuit-size/lineage acceptance is implied.",
                              "Counts use exact selected hierarchy error records; they are not de-duplicated physical defect counts.",
                              "Explained Rvt markers retain the frozen validator evidence policy; no new waiver was introduced.",
                              "Unknown/postprocessor diagnostic categories remain unknown rather than DRC=0."],
              "rows": rows}
    out = HERE / "REFERENCE953_OBSERVATION_PARAMETERIZED_V1.json"
    with out.open("x") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
        f.write("\n")
    lines = ["# Runtime953 reference 的 G/C/L 观测（V2）", "",
             f"这批完整分母是 **{len(rows)} 次 pair 尝试**，不是只统计有结果的 17 条。"
             f"其中 {counts['reference_finalized']} 条完成五阶段与 reference binding；"
             f"**G={counts['G']}、C={counts['C']}、L={counts['L']}**（包含关系 L⊆C⊆G）。", "",
             "G 表示完整、可归属、四指标可用的布线几何；C 再要求 OPEN=SHORT=0 且没有未知检查语义；"
             "L 再要求 DRC=0。DRC 非零不删除 G/C，但 SHORT 非零只能保留几何诊断。", "",
             "**这不是 G1 完成或正式数据生成资格声明**：本报告每 pair 只有 reference，"
             "还没有计入另外两个不同 effective 配置；第三域、三域交集和规模/lineage 最终验收也没有因此完成。", "",
             f"冻结身份：native SHA `{SHA953}`；当前私有 runtime 的 {identity['verified_files']} 个文件"
             f"对 S0 manifest 不匹配数 {len(identity['mismatches'])}。逐阶段收据也逐条核对 SHA。", "",
             "| Circuit | PDK | 层级 | OPEN / SHORT / DRC / unknown | 四指标（仅 G 输出） | 最早失败或剩余问题 |", "|---|---|---|---|---|---|"]
    for x in rows:
        c = x.get("connectivity_and_DRC")
        cn = " / ".join(str(c[k]) for k in ("OPEN", "SHORT", "DRC", "unknown")) if c else "未到最终检查"
        vec = ", ".join(f"{n:.6g}" for n in x["metrics4"]) if x["metrics4"] else "null"
        failure = x.get("earliest_failure")
        reason = (failure["stage"] + ": " + failure["reason"]) if failure else "; ".join(x.get("geometry_eligibility_reasons", []))
        if not reason:
            reason = "SHORT>0，仅几何诊断" if c and c["SHORT"] else "reference 可观测；待不同 effective 配置"
        lines.append(f"| {x['circuit_name']} | {x['pdk']} | {x['tier']} | {cn} | {vec} | {reason.replace(chr(10), '<br>').replace('|', '/')} |")
    lines += ["", "四指标顺序：A_eval、L_eq_signal、L_eq_power、N_cut_intermetal；单位依次为 μm²、μm-equivalent、μm-equivalent、cut 数。", "",
              "14/65 两个固定域都达到 G reference 的电路：" + "、".join(intersection) + "。这仍不是三域交集。", "",
              "## 错误计数和证据边界", "",
              "- 仅使用 validator 所选 hierarchy 的 `.errors`，逐个核对 SHA 和诊断条目；不扫描全部 log 的 ERROR 字串。",
              "- TELESCOPIC/14、UNITY/65、TEST_VGA/65 的非零错误是明确 DRC，仍可纳入 C 几何观测。",
              "- COMPARATOR/14 有 4 条 SHORT 诊断，不能给高质量连通布局回报。诊断条目数不等于四个独立物理短路。",
              "- SWITCHED_CAPACITOR_FILTER/14 和 REFERENCE_BUFFER_CORE/14 几何归属不完整，哪怕能算出数字也不进 G。前者 6690 条 postprocessor_error 保留为 unknown。",
              "- Rvt marker 已解释条目沿用冻结 validator 的几何证据分类，另列数量；本后处理没有关闭检查或添加 waiver。",
              "- 历史 strict validation 与原始几何、日志、输入均只读。本程序仅新增本报告与 JSON；没有启动 ALIGN。", "",
              "## 复核与复用", "",
              "程序：[observer953_v2.py](./observer953_v2.py)。完整 24 行证据、stage receipts、实际 35D masks、逐模块错误、四指标和 hash："
              "[REFERENCE953_OBSERVATION_PARAMETERIZED_V1.json](./REFERENCE953_OBSERVATION_PARAMETERIZED_V1.json)。输出采用独占新建，避免覆盖。", "",
              "三个必要检查已通过：真实非零 DRC 结果保留 G/C；真实 ownership 不完整结果拒绝 G；移除 routing 完成证据时拒绝 G。", "",
              "本表 supersede 旧 `audit_geometry_observation.py` 的宽泛错误扫描结果；旧文件与历史结果未改动。"]
    with (HERE / "REFERENCE953_OBSERVATION_PARAMETERIZED_V1.md").open("x") as f:
        f.write("\n".join(lines) + "\n")
    print(json.dumps({"denominator": len(rows), "counts": counts, "two_domain_intersection": intersection}, ensure_ascii=False))


if __name__ == "__main__":
    main()
