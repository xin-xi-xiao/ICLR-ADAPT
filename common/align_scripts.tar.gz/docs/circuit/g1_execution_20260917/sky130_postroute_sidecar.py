"""SKY130 post-route observation sidecar.

This module consumes the *already completed* ``sky130_formal35_ref_v6`` runs;
it never launches ALIGN and never edits the PDK, router, checker, or shared
runtime.  SKY130 uses GDS layer/datatype pairs (metal and via layers reuse the
same GDS layer numbers), whereas the existing generic serializer intentionally
fails closed on ambiguous layer numbers.  We make a private, provenance
recorded layer/datatype-normalised copy solely for geometry observation.  The
original GDS, PDK and logs remain untouched and are hashed in the report.

The sidecar then feeds the real runtime marker logs to
``grouped35_runtime_masks.collect_runtime_masks`` and computes the four
geometry metrics from the normalised final hierarchy.  A successful sidecar
observation is not a G1 qualification: it records whether metrics and native
operations are observable, while legality/DRC and the S5 two-effective-run
gate remain independent.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import re
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
# ``HERE`` is the execution directory (not the Python file).  Its parents are
# ``circuit``, ``docs``, then the repository root.
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "src"))

import grouped35_dispatch as gd  # isolated dispatcher, never production output
from grouped35_runtime_masks import collect_runtime_masks
from adapt.postlayout.align_hierarchy_serializer import serialize_hierarchical_final
from adapt.postlayout.geometry_metrics import compute_geometry_metrics

RUNTIME_RECEIPT = HERE / "runtime" / "runtime_receipt.json"
REFERENCE_VECTOR = ROOT / "docs" / "param" / "reference_vector_35d.json"
METRICS = ("A_eval", "L_eq_signal", "L_eq_power", "N_cut_intermetal")


def _sha(path: Path) -> str | None:
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _read(path: Path):
    return json.loads(path.read_text())


def _write(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def _copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _layer_datatype_map(layers: dict):
    """Return a private unique GDS layer map keyed by (layer,datatype).

    Official SKY130 intentionally reuses numbers: e.g. M1=(67,20),
    V1=(67,44).  Datatype is the discriminator.  We select the routing layer
    for an ambiguous routing pair (V4 vs CapMIMContact, etc.) and retain every
    original row in the synthetic PDK copy for width metadata.
    """
    rows = layers.get("Abstraction", [])
    candidates = defaultdict(list)
    for idx, row in enumerate(rows):
        number = row.get("GdsLayerNo")
        if not isinstance(number, int):
            continue
        for _, datatype in (row.get("GdsDatatype") or {}).items():
            candidates[(number, datatype)].append((idx, row))

    def pick(number, datatype):
        cands = candidates.get((number, datatype), [])
        if not cands:
            return None
        if datatype == 44:
            via = [x for x in cands if re.fullmatch(r"V\d+", str(x[1].get("Layer")))]
            if via:
                return via[0]
        if datatype in (5, 16, 20):
            metal = [x for x in cands if re.fullmatch(r"M\d+", str(x[1].get("Layer")))]
            if metal:
                return metal[0]
        # For non-resource duplicates, a stable source order is the least
        # surprising fallback; such geometry is excluded by the serializer.
        return cands[0]

    # Assign IDs outside the source range and preserve all row fields.  The
    # transformed GDS is separately hashed, so this cannot be mistaken for a
    # real PDK payload.
    synthetic_rows = copy.deepcopy(rows)
    uid_by_row = {}
    for idx, row in enumerate(synthetic_rows):
        uid = 10000 + idx
        uid_by_row[idx] = uid
        row["GdsLayerNo"] = uid
    pair_to_uid = {}
    for pair in candidates:
        selected = pick(*pair)
        if selected is not None:
            pair_to_uid[pair] = uid_by_row[selected[0]]
    out_layers = copy.deepcopy(layers)
    out_layers["Abstraction"] = synthetic_rows
    return out_layers, pair_to_uid, {
        "source_layer_count": len(rows),
        "synthetic_layer_count": len(synthetic_rows),
        "ambiguous_pairs": {
            f"{number}:{datatype}": [r.get("Layer") for _, r in cands]
            for (number, datatype), cands in candidates.items() if len(cands) > 1
        },
        "policy": "GDS layer/datatype disambiguation; datatype 20/16/5 prefers Mx, datatype 44 prefers Vx; source PDK unchanged",
    }


def _normalise_gds(source: Path, destination: Path, pair_to_uid: dict):
    payload = _read(source)
    changed = 0
    unresolved = Counter()
    for library in payload.get("bgnlib", []):
        for structure in library.get("bgnstr", []):
            for element in structure.get("elements", []):
                # Text/path records are never resource geometry in the metric
                # contract.  Give them an unmapped synthetic number to avoid
                # interpreting a text label as a route boundary.
                if element.get("type") != "boundary":
                    if "layer" in element:
                        element["layer"] = 30000
                        changed += 1
                    continue
                key = (element.get("layer"), element.get("datatype"))
                uid = pair_to_uid.get(key)
                if uid is None:
                    unresolved[str(key)] += 1
                    # ALIGN's OA boundary convention is an out-of-PDK fixed
                    # GDS layer 235.  Preserve that sentinel so the existing
                    # serializer excludes it as ``ALIGN.OA_boundary`` rather
                    # than classifying it as an unexplained geometry failure.
                    element["layer"] = 235 if element.get("layer") == 235 else 30001
                else:
                    element["layer"] = uid
                changed += 1
    _write(destination, payload)
    return {"source": str(source), "destination": str(destination), "transformed_elements": changed,
            "unresolved_layer_datatype_pairs": dict(unresolved), "source_sha256": _sha(source),
            "destination_sha256": _sha(destination)}


def _error_inventory(work: Path):
    count = Counter()
    samples = []
    for path in sorted((work / "3_pnr").glob("*.errors")):
        lines = path.read_text(errors="replace").splitlines()
        for number, line in enumerate(lines, 1):
            text = line.strip()
            if not text:
                continue
            up = text.upper()
            if up.startswith("OPEN"):
                kind = "OPEN"
            elif up.startswith("SHORT"):
                kind = "SHORT"
            elif up.startswith("DRC ERROR") or "DRC" in up:
                kind = "DRC"
            elif "DIFFERENT WIDTH" in up:
                kind = "DIFFERENT_WIDTH"
            else:
                kind = "OTHER"
            count[kind] += 1
            if len(samples) < 20:
                samples.append({"path": str(path), "line": number, "text": text[:500], "kind": kind})
    return {"counts": dict(count), "samples": samples,
            "error_files": [str(p) for p in sorted((work / "3_pnr").glob("*.errors"))]}


def _stage_pair(out: Path, stage: Path, top: str):
    """Create the read-only input aliases expected by collect_runtime_masks."""
    stage.mkdir(parents=True, exist_ok=True)
    # Symlink the large immutable work tree; all sidecar writes go to stage.
    work_link = stage / "work"
    if not work_link.exists():
        work_link.symlink_to(out / "work", target_is_directory=True)
    for name in ("grouped35_postroute_reference_frozen.json",
                 "grouped35_reference_binding_after_windows.json", "formal35_native_environment.json",
                 "formal35_native_resources.json"):
        source = out / name
        if not source.is_file():
            raise FileNotFoundError(source)
        target = stage / {"formal35_native_environment.json": "native_environment.json",
                          "formal35_native_resources.json": "native_resources.json"}.get(name, name)
        _copy(source, target)
    # The SKY130 dispatcher performs a PDK-specific formal binding (notably
    # its power-grid lower layer), so its executed PDK payload can differ from
    # the pre-dispatch snapshot.  The runtime-mask auditor intentionally
    # requires resource equality with its baseline; give it an isolated
    # formal-bound baseline and retain the original baseline hash in the
    # report.  This does not overwrite the run's original baseline.
    original_baseline = _read(out / "grouped35_native_baseline.json")
    formal_baseline = copy.deepcopy(original_baseline)
    formal_baseline["pdk"] = _read(out / "pdk" / "layers.json")
    _write(stage / "grouped35_native_baseline.json", formal_baseline)

    # A route receipt with the exact fields checked by the existing mask
    # auditor.  Runtime identity is derived from the frozen receipt and the
    # actual launch env captured by run_sky_formal_ref.py; no event is invented.
    pnr = _read(out / "formal35_pnr.json")
    env = _read(out / "formal35_native_environment.json")
    runtime = _read(RUNTIME_RECEIPT)
    route = dict(pnr)
    route.update({"status": pnr.get("status"), "returncode": pnr.get("returncode"),
                  "runtime_module_sha256": runtime.get("module_sha256"),
                  "reference_sha256": _sha(REFERENCE_VECTOR),
                  "native_environment_at_launch": env,
                  "runtime_identity_basis": "frozen runtime receipt + formal35 launch env captured before subprocess"})
    _write(stage / "routing_reference_v1.json", route)
    for stream in ("stdout", "stderr"):
        source = out / f"formal35_pnr.{stream}.log"
        if not source.is_file():
            raise FileNotFoundError(source)
        _copy(source, stage / f"routing_reference_v1.{stream}.log")
    return stage


def observe_case(case: str, runset: str = "sky130_formal35_ref_v6", sidecar_name: str = "postroute_sidecar_v1"):
    out = HERE / runset / case / "SKY130"
    if not out.is_dir():
        return {"case": case, "status": "missing_formal35_run", "run_dir": str(out)}
    top = _read(out / "grouped35_native_baseline.json")["top"]
    side = out / sidecar_name
    side.mkdir(parents=True, exist_ok=True)
    report = {"schema": "sky130-postroute-observation-v1", "case": case, "top": top,
              "pdk": "SKY130", "run_dir": str(out), "status": "started",
              "qualification": "not_G_until_S5_two_effective_runs_and_native_contract_gate"}
    try:
        # Freeze/check windows from the completed route without applying route
        # updates. This writes only sidecar metadata under the isolated runset.
        pre = gd.postroute_reference_check(out / "work", out / "pdk", top=top,
            output_dir=out, selected_id=top + "_0", pdk_name="SKY130",
            ordinary_power_flow=True, apply=False)
        report["postroute_reference_check"] = {k: pre.get(k) for k in
            ("status", "requires_reroute", "current_consumer_inputs_match_formal_reference_raw",
             "frozen_window_file", "physical_qualification_status")}
        stage = _stage_pair(out, side / "mask_staging", top)
        masks = collect_runtime_masks(stage, top=top, route_phase="routing_reference_v1",
                                       output_dir=side / "mask_audit")
        report["runtime_masks"] = masks
        report["runtime_mask_path"] = str(side / "mask_audit" / "grouped35_masks.json")

        # Build a private GDS layer/datatype normalisation for geometry metrics.
        pdk_layers = _read(out / "pdk" / "layers.json")
        synthetic_layers, pair_to_uid, layer_policy = _layer_datatype_map(pdk_layers)
        metric_in = side / "metric_staging"
        metric_in.mkdir(parents=True, exist_ok=True)
        _write(metric_in / "layers.json", synthetic_layers)
        work = out / "work"; selected = top + "_0"
        final = work / "3_pnr" / "Results" / f"{selected}.gds.json"
        viewer = work / "3_pnr" / f"{selected}.json"
        gds_report = _normalise_gds(final, metric_in / f"{selected}.gds.json", pair_to_uid)
        report["gds_layer_datatype_normalization"] = {**layer_policy, **gds_report,
            "legality_implication": "observation-only; synthetic mapping does not alter ALIGN output or checker decisions"}
        geometry = None; metrics = None; geometry_error = None
        try:
            geometry = serialize_hierarchical_final(metric_in / f"{selected}.gds.json", viewer,
                                                    metric_in / "layers.json", workdir=work, top=top)
            metrics = compute_geometry_metrics(geometry, reference_widths_um=geometry["reference_widths_um"])
            _write(side / "geometry_observation.json", geometry)
            _write(side / "metrics_observation.json", metrics)
        except Exception as exc:  # observation is fail-closed and explicit
            geometry_error = f"{type(exc).__name__}: {exc}"
        report["geometry"] = {"complete": bool(geometry and geometry.get("geometry_complete")),
                               "ownership_complete": bool(geometry and geometry.get("ownership_coverage", {}).get("ownership_complete")),
                               "metric_eligibility": geometry.get("metric_eligibility") if geometry else "unavailable",
                               "record_count": geometry.get("record_count") if geometry else None,
                               "error": geometry_error,
                               "observation_path": str(side / "geometry_observation.json") if geometry else None}
        report["four_metrics"] = {k: (metrics.get(k) if metrics else None) for k in METRICS}
        report["finite_four_metrics"] = bool(metrics and all(isinstance(metrics.get(k, {}).get("value"), (int, float))
                                                               and math.isfinite(metrics[k]["value"]) for k in METRICS))
        report["error_inventory"] = _error_inventory(work)
        report["status"] = "observed" if report["finite_four_metrics"] else "geometry_or_metric_unavailable"
        report["g_qualified"] = False
        report["limitations"] = [
            "SKY130 layer/datatype disambiguation is a private metric observer; official PDK and GDS remain immutable.",
            "Native consumer masks are reference-trace observations only; a false slot is not evidence of zero effect.",
            "No S5 alternate effective configurations were run by this sidecar.",
            "DRC/connectivity counts are reported from raw ALIGN .errors and never waived.",
        ]
    except Exception as exc:
        report.update(status="sidecar_error", error=f"{type(exc).__name__}: {exc}", g_qualified=False)
    _write(side / "sky130_postroute_observation.json", report)
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runset", default="sky130_formal35_ref_v6")
    ap.add_argument("--case", action="append")
    ap.add_argument("--sidecar-name", default="postroute_sidecar_v1")
    args = ap.parse_args()
    cases = args.case or [p.name for p in sorted((HERE / args.runset).iterdir())
                          if p.is_dir() and (p / "SKY130").is_dir()]
    for case in cases:
        print(json.dumps(observe_case(case, args.runset, args.sidecar_name), ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
