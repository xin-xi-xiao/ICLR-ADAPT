"""G1 S5 only: isolated arbitrary-Formal35 full-flow attempts.

Read-only source design evidence may be reused to prepare inputs; no ALIGN
stage outputs are reused. One OS process owns one attempt. All expensive
children share the existing G1 admission locks. G2 is deliberately absent.
"""
from __future__ import annotations
import argparse
import collections
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import random
import shutil
import signal
import subprocess
import sys
import time
import traceback

from g1_runtime953_driver import HERE,ROOT,RUNTIME,NATIVE_SHA,verify_runtime,install

CONTRACT_PATH=ROOT/'docs/param/adapt_formal_grouped_space_v1.json'
CONTRACT=json.loads(CONTRACT_PATH.read_text())
DIMS=CONTRACT['dimensions']
REFERENCE=CONTRACT['reference_vector']
METRICS=('A_eval','L_eq_signal','L_eq_power','N_cut_intermetal')
PDKS={'14nm':'FinFET14nm_Mock_PDK','45nm':'Bulk45nm_Mock_PDK',
      '65nm':'Bulk65nm_Mock_PDK','SKY130':'SKY130'}
PHASES=('compile','primitives','placement','routing_bootstrap','routing_reference_s5')
ACTIVE_PROCESS=None


def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(value):
    if isinstance(value,float):
        if not math.isfinite(value):raise ValueError('nonfinite configuration')
        return int(value) if value.is_integer() else value
    if isinstance(value,dict):return {str(k):canonical(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [canonical(v) for v in value]
    return value
def digest(value):return hashlib.sha256(json.dumps(canonical(value),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def atomic(path,value):
    path=Path(path)
    if not path.resolve().is_relative_to(HERE.resolve()):raise ValueError('Writes restricted to new G1 root')
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n');tmp.replace(path)
def tree_hash(path):
    path=Path(path)
    return digest({str(p.relative_to(path)):sha(p) for p in sorted(path.rglob('*'))
       if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'})
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


def source_hashes(pdk):
    names=[Path(__file__).name,'g1_runtime953_driver.py','run_qualification.py','runtime_setup.py',
      'grouped35_dispatch.py','qualification_validation.py','observer953_v2.py',
      'audit/router45/grouped35_runtime_masks_router_v1.py']
    if pdk=='SKY130':names+=['sky130_dispatch953.py','sky130_contract953.py','sky130_validation953.py',
      'sky130_postroute_sidecar.py','audit/metric_repair/align_hierarchy_serializer_v2.py']
    return {str(HERE/n):sha(HERE/n) for n in names}


class StageFailure(Exception):
    def __init__(self,stage,reason):super().__init__(reason);self.stage=stage;self.reason=reason


def terminate(proc):
    if proc and proc.poll() is None:
        try:os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError:return
        try:proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);proc.wait()


def interrupted(sig,frame):
    terminate(ACTIVE_PROCESS)
    raise StageFailure('interrupted',f'Runner received signal {sig}')


def decoded_choice(row,value):
    result={}
    for obj in row.get('objects',[]):
        choices=obj.get('decoded_choices')
        if choices is None:return None
        matches=[v for k,v in choices.items() if float(k)==value]
        if len(matches)!=1:return None
        result[obj['object_id']]=matches[0]
    return result or None


def preregister(bundle,pair,output,seed=20260917):
    """Metric-blind reference + eight singles + three balanced joint actions."""
    bundle=Path(bundle).resolve();receipt=read(bundle/'grouped35_reference_binding_after_windows.json')
    if receipt['vector']!=REFERENCE:raise ValueError('S5 preregistration requires reference binding')
    if not read(bundle/'reference_binding_audit.json').get('reference_binding_verified'):
        raise ValueError('Reference has not passed actual binding verification')
    rows=receipt['coordinates'];eligible=[];domains={};reasons={}
    for i,(d,row) in enumerate(zip(DIMS,rows)):
        if row.get('object_mask') is not True or row.get('choice_mask') is not True:
            reasons[d['name']]='no proven object and distinct decoded choice';continue
        seen={};options=[]
        # Keep reference as representative of its equivalence class.
        order=[REFERENCE[i]]+[v for v in d['allowed_values'] if v!=REFERENCE[i]]
        for v in order:
            native=decoded_choice(row,v)
            if native is None:continue
            key=digest(native)
            if key not in seen:seen[key]=v;options.append(v)
        if len(options)<2:
            reasons[d['name']]='no two locally decoded native choices';continue
        eligible.append(i);domains[i]=options
    selected=[]
    for family in 'PGRW':selected.extend([i for i in eligible if DIMS[i]['parameter_id'].startswith(family)][:2])
    selected.extend(i for i in eligible if i not in selected)
    selected=selected[:8]
    attempts=[{'config_id':'reference','kind':'reference','vector':list(REFERENCE),'reuse_bundle':str(bundle)}]
    seen={digest([decoded_choice(r,v) for r,v in zip(rows,REFERENCE)])}
    for i in selected:
        candidates=[v for v in domains[i] if v!=REFERENCE[i]]
        v=min(candidates,key=lambda x:(abs(x-REFERENCE[i]),x))
        vector=list(REFERENCE);vector[i]=v
        native_key=digest([decoded_choice(r,x) for r,x in zip(rows,vector)])
        attempts.append({'config_id':'single_'+DIMS[i]['name'],'kind':'single','coordinate_0based':i,
           'coordinate_1based':i+1,'vector':vector,'decoded_preregistration_hash':native_key})
        seen.add(native_key)
    rng=random.Random(seed)
    # Three Latin-style balanced strata per eligible discrete coordinate.
    # Discrete bins only: no Boolean/categorical interpolation or result feedback.
    joint=[list(REFERENCE) for _ in range(3)]
    for i in eligible:
        strata=[(j+0.5)/3 for j in range(3)];rng.shuffle(strata)
        domain=sorted(domains[i]);offset=rng.randrange(len(domain))
        for j,u in enumerate(strata):joint[j][i]=domain[(min(len(domain)-1,int(u*len(domain)))+offset)%len(domain)]
    for j,vector in enumerate(joint):
        key=digest([decoded_choice(r,v) for r,v in zip(rows,vector)])
        alias=key in seen;seen.add(key)
        attempts.append({'config_id':f'joint_{j+1}','kind':'joint','vector':vector,
          'decoded_preregistration_hash':key,'decoded_alias_at_preregistration':alias})
    result={'schema':'g1-s5-preregistration953-v2','purpose':'G1 small-batch generatability, not G2',
       'pair':pair,'bundle_path':str(bundle),'seed':seed,'nominal_configuration_count':12,
       'registered_configuration_count':len(attempts),'nonreference_run_count':len(attempts)-1,
       'single_coordinate_names':[DIMS[i]['name'] for i in selected],
       'eligible_coordinate_names':[DIMS[i]['name'] for i in eligible],
       'ineligible_reasons':reasons,'selection_uses_metrics':False,
       'joint_method':'three seeded balanced discrete strata; aliases recorded, never resampled from outcomes',
       'reference_receipt_sha256':sha(bundle/'grouped35_reference_binding_after_windows.json'),
       'source_input_tree_hash':tree_hash(bundle/'input'),
       'source_pdk_tree_hash':tree_hash(bundle/'pdk'),
       'source_baseline_sha256':sha(bundle/'grouped35_native_baseline.json'),
       'runner_dependency_sha256':source_hashes(pair['pdk']),
       'runtime_identity':verify_runtime(),'contract_sha256':sha(CONTRACT_PATH),
       'attempts':attempts}
    path=Path(output)
    if path.exists():raise FileExistsError(path)
    atomic(path,result);return result


def requests_for_campaign(campaign,output_root):
    """Materialize requests, including aliases in the attempted denominator."""
    result=[]
    for action in campaign['attempts']:
        if action['kind']=='reference':continue
        request={k:campaign[k] for k in ['pair','bundle_path','source_input_tree_hash',
          'source_pdk_tree_hash','source_baseline_sha256','runner_dependency_sha256','contract_sha256']}
        request.update(config_id=action['config_id'],vector=action['vector'],
          output_directory=str(Path(output_root)/action['config_id']),
          preregistration_sha256=digest(campaign),kind=action['kind'],
          coordinate_1based=action.get('coordinate_1based'),
          decoded_preregistration_hash=action.get('decoded_preregistration_hash'))
        result.append(request)
    return result


def decoded_native_configuration(binding,masks,native_environment,identity):
    """Native object values plus applicable environments; inactive aliases kept."""
    coordinates=[];aliases=[];uncertain=[];native_applicable={}
    for row,trace in zip(binding['coordinates'],masks['coordinates']):
        i=row['index_0based'];slot=row['parameter_id']
        excluded=(row.get('object_mask') is False or row.get('choice_mask') is False
                  or trace.get('native_status')=='inapplicable')
        if excluded:
            aliases.append({'index_0based':i,'name':row['name'],'requested':row['requested'],
                            'reason':'absent/collapsed or proven native inapplicability'})
            coordinates.append(None)
        else:
            coordinates.append({o['object_id']:o['raw_value'] for o in row.get('objects',[])})
            if row.get('object_mask') is None or row.get('choice_mask') is None:
                uncertain.append(row['name'])
        if slot in ('R05','R06','R07','R09','W08','W09','W10'):native_applicable[slot]=not excluded
    prefixes={'R05':('ADAPT_R6_NATIVE_R05_',),'R06':('ADAPT_R6_NATIVE_R06_',),
      'R07':('ADAPT_R6_NATIVE_R07_',),'R09':('ADAPT_R6_NATIVE_R09_',),
      'W08':('ADAPT_R6_NATIVE_W08_',),'W09':('ADAPT_R6_NATIVE_W09_',),'W10':('ADAPT_R6_NATIVE_W10_',)}
    env={k:v for k,v in native_environment.items() if not any(
        k.startswith(prefix) and not native_applicable.get(slot,True)
        for slot,values in prefixes.items() for prefix in values)}
    value={'identity':identity,'coordinates':coordinates,'applicable_native_environment':env}
    return {'decoded_native_input_hash':digest(value),'canonical_native_configuration':value,
       'inactive_aliases':aliases,'unknown_object_or_choice_coordinates':uncertain,
       'hash_authority':'decoded native input only; does not establish operation-effective uniqueness',
       'requested_vector_hash':digest(binding['vector'])}


def trace_power_aliases(binding,power_receipt):
    """Observed post-trimming selections/windows, not pre-cap requested knobs.

    Alternative projections are same-trace counterfactuals. They show aliases
    on this fixed consumer context; they do not replace an actual rerun.
    """
    result=[None]*35
    for slot in ('W09','W10'):
        i=next(d['index_0based'] for d in DIMS if d['parameter_id']==slot)
        evidence=(power_receipt or {}).get('slots',{}).get(slot,{})
        if evidence.get('status')!='observed' or evidence.get('requested')!=binding['vector'][i]:
            result[i]={'slot':slot,'status':'unresolved','reason':'no fully audited actual power consumer receipt'}
            continue
        calls=[];alternatives={str(v):[] for v in DIMS[i]['allowed_values']}
        for ordinal,call in enumerate(evidence.get('calls',[])):
            if not call.get('exit'):continue
            fields=call['exit']['fields']
            identity={k:fields.get(k) for k in ('module','mode','net','pin','multi')}
            identity['call_ordinal']=ordinal
            if slot=='W09':
                selected=fields['selected_records'];count=fields['distance_map_records']
                actual={'selected_records':selected,'selected_unique_segments':fields['selected_unique_segments']}
                for v in DIMS[i]['allowed_values']:
                    n=min(v,count)
                    # We cannot invent the extra records beyond this run's
                    # actual selection. Count is all that is known there.
                    projection={'selected_record_count':n,'known_selected_prefix':selected[:n] if n<=len(selected) else None}
                    alternatives[str(v)].append({'call':identity,'projection':projection})
            else:
                actual={'clipped_window':fields['window']}
                box,pitch,extent=fields['source_target_bbox'],fields['margin_pitch'],fields['layout_extent']
                for v in DIMS[i]['allowed_values']:
                    clipped=[max(0,box[0]-v*pitch[0]),max(0,box[1]-v*pitch[1]),min(extent[0],box[2]+v*pitch[0]),min(extent[1],box[3]+v*pitch[1])]
                    alternatives[str(v)].append({'call':identity,'projection':{'clipped_window':clipped}})
            calls.append({'call':identity,'actual_consumer_projection':actual})
        requested=binding['vector'][i]
        projection=alternatives.get(str(requested))
        if projection is None:projection=next((v for k,v in alternatives.items() if float(k)==requested),None)
        aliases=[float(k) for k,v in alternatives.items() if projection is not None and digest(v)==digest(projection)]
        result[i]={'slot':slot,'status':'actual_consumer_projection_observed' if calls else 'unresolved',
          'actual_calls':calls,'actual_projection_hash':digest(calls) if calls else None,
          'same_reference_trace_alias_values':aliases,
          'alias_scope':'same observed source/target and distance-map context only; no hypothetical records or reruns invented',
          'precap_requested_value':requested}
    return result


def effective_configuration(binding,masks,native_environment,identity,*,binding_verified=False,power_receipt=None):
    """Separate decoded input identity from proof of meaningful distinctness.

    Initial accepted witnesses are intentionally just P01 and P04. P01 is
    checked against the executed placement CLI; P04 against native bias_Hgraph
    serialization under a verified complete binding audit. W09/W10 requested
    values are never sufficient witnesses because clipping may alias them.
    """
    result=decoded_native_configuration(binding,masks,native_environment,identity)
    witnesses=[None]*35
    for row,trace in zip(binding['coordinates'],masks['coordinates']):
        i=row['index_0based'];slot=row['parameter_id']
        if not binding_verified or row.get('object_mask') is not True or row.get('choice_mask') is not True:continue
        if slot=='P01' or (slot=='P04' and trace.get('serialized_binding_mask') is True):
            witnesses[i]={'coordinate':row['name'],'native_values':{o['object_id']:o['raw_value'] for o in row['objects']},
               'basis':'executed placement CLI lambda' if slot=='P01' else 'verified native bias_Hgraph distance per actual compiled module',
               'metric_effect_claimed':False}
    result.update({
        'schema':'g1-s5-decoded-input-and-distinctness-evidence-v2',
        'operation_effective_configuration_hash':None,
        'distinctness_witness35':witnesses,
        'trace_alias_information35':trace_power_aliases(binding,power_receipt),
        'distinctness_requires_pairwise_witness':True,
        'distinctness_policy':'A decoded hash mismatch alone does not establish an effective configuration. Count two successful runs as distinct only with a verified direct-consumer witness that differs. Current accepted witness families: P01/P04. Others remain pending richer consumer canonicalization.',
        'complete_operation_effective_identity_claimed':False,
    })
    return result


def compare_distinctness(a,b):
    """Conservative S5 pairwise proof, never metric-based or raw-hash-only."""
    if a.get('canonical_native_configuration',{}).get('identity')!=b.get('canonical_native_configuration',{}).get('identity'):
        return {'status':'incomparable_pair_or_input_identity','proven_distinct':False,'witnesses':[]}
    witnesses=[]
    aa=a.get('distinctness_witness35',[]);bb=b.get('distinctness_witness35',[])
    if len(aa)!=35 or len(bb)!=35:
        return {'status':'missing_35D_witness_arrays','proven_distinct':False,'witnesses':[]}
    for i,(x,y) in enumerate(zip(aa,bb)):
        if x and y and x['coordinate']==y['coordinate'] and digest(x['native_values'])!=digest(y['native_values']):
            witnesses.append({'index_0based':i,'coordinate':x['coordinate'],'a':x['native_values'],'b':y['native_values'],'basis':x['basis']})
    return {'status':'proven_distinct_consumer_inputs' if witnesses else 'not_proven_distinct',
       'proven_distinct':bool(witnesses),'witnesses':witnesses,
       'decoded_native_input_hash_differs':a.get('decoded_native_input_hash')!=b.get('decoded_native_input_hash')}


def reference_distinctness_evidence(bundle,pair):
    """Read-only reference witness, with the exact pre-action PDK tree hash."""
    bundle=Path(bundle);binding=read(bundle/'grouped35_reference_binding_after_windows.json')
    audit=read(bundle/'reference_binding_audit.json');baseline=read(bundle/'grouped35_native_baseline.json')
    # Match fresh attempt restoration byte-for-byte, without changing bundle.
    layer_bytes=(json.dumps(baseline['pdk'],indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
    files={str(p.relative_to(bundle/'pdk')):sha(p) for p in sorted((bundle/'pdk').rglob('*'))
      if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    files['layers.json']=hashlib.sha256(layer_bytes).hexdigest()
    masks=read(bundle/'actual35_masks.json')
    profile=bundle/masks['route_phase']/'mask_audit/POWER_native_consumer_receipt.json'
    if not profile.exists():profile=bundle/'runtime_mask_audit/POWER_native_consumer_receipt.json'
    return effective_configuration(binding,masks,read(bundle/'native_environment.json'),
      {'case_id':pair['case_id'],'pdk':pair['pdk'],'input_hash':tree_hash(bundle/'input'),
       'original_pdk_hash':digest(files),'runtime_sha256':NATIVE_SHA,'align_seed':1},
      binding_verified=audit.get('reference_binding_verified') is True,
      power_receipt=read(profile) if profile.exists() else None)


def gcl(validation,geometry,stage_records,binding_ok,masks_ok):
    from adapt.postlayout.geometry_metrics import compute_geometry_metrics
    from observer953_v2 import classify,verify_record
    metrics=compute_geometry_metrics(geometry,reference_widths_um=geometry['reference_widths_um'])
    values=[metrics.get(k,{}).get('value') for k in METRICS]
    finite=all(type(v) in (int,float) and math.isfinite(v) for v in values)
    finite &= all(metrics.get(k,{}).get('status')=='ok' for k in METRICS)
    checks=validation.get('checks',{});modules=checks.get('selected_module_checks',[])
    used=set(checks.get('selected_hierarchy',{}).get('used_modules',[]))
    counts=dict.fromkeys(['OPEN','SHORT','DRC','unknown','accepted_explained_diagnostics'],0)
    errors_ok=bool(used) and used=={m['module'] for m in modules}
    for m in modules:
        diagnostics=m.get('diagnostics',[]);path=Path(m['error_file']['path'])
        lines=[x for x in path.read_text().splitlines() if x.strip()] if path.is_file() else []
        errors_ok &= verify_record(m['error_file']) and verify_record(m['viewer'])
        errors_ok &= lines==[d.get('raw') for d in diagnostics] and len(lines)==m.get('raw_error_count')
        for d in diagnostics:
            kind=d.get('classification')
            key='accepted_explained_diagnostics' if d.get('accepted') and kind=='proven_rvt_marker_width_diagnostic' else {
               'open':'OPEN','short':'SHORT','drc_error':'DRC'}.get(kind,'unknown')
            counts[key]+=1
    required=checks.get('required_artifacts',{})
    gates={'all_five_phases_completed':all(s in stage_records and stage_records[s].get('status')=='completed'
            and stage_records[s].get('returncode')==0 for s in PHASES),
       'frozen_runtime953':all(s in stage_records and stage_records[s].get('runtime_module_sha256')==NATIVE_SHA for s in PHASES),
       'binding_verified':binding_ok,'postroute_masks_with_launch_identity':masks_ok,
       'required_artifacts_intact':len(required)>=5 and all(verify_record(v) for v in required.values()),
       'checker_selected_hierarchy_complete':errors_ok,
       'complete_owned_geometry':geometry.get('geometry_complete') is True and geometry.get('full_layout_geometry') is True
         and geometry.get('ownership_coverage',{}).get('ownership_complete') is True and geometry.get('metric_eligibility')=='eligible'
         and metrics.get('unknown_geometry_count')==0,
       'four_metrics_finite':finite,
       'explicit_power_and_ground':bool(checks.get('explicit_power_declarations',{}).get('power'))
           and bool(checks.get('explicit_power_declarations',{}).get('ground'))}
    return {**classify(gates,counts),'gates':gates,'connectivity_and_DRC':counts,
       'metrics4':values if all(gates.values()) else None,'diagnostic_arithmetic_metrics4':values,
       'high_quality_reward_eligible':bool(classify(gates,counts)['C']),
       'strict_validator_legal':validation.get('legal')}


class Attempt:
    def __init__(self,request):
        self.request=request;self.pair=request['pair'];self.top=self.pair['top']
        self.vector=list(request['vector']);self.bundle=Path(request['bundle_path']).resolve()
        self.out=Path(request['output_directory']).resolve();self.work=self.out/'work';self.pdk=self.out/'pdk'
        if not self.out.is_relative_to((HERE/'s5_runtime953').resolve()):raise ValueError('S5 output must stay under G1/s5_runtime953')
        self.current='prepare';self.native_env={};self.binding=None;self.base=None;self.stages={};self.created_output=False
        self.identity=install();self.started=time.time()
        self.result={'schema':'g1-s5-attempt953-v2','config_id':request['config_id'],'pair':self.pair,
          'request_sha256':digest(request),'requested35':self.vector,'status':'running','G':False,'C':False,'L':False}
        import run_qualification as admitted
        self.admitted=admitted
        name='_s5_dispatch_'+digest(str(self.out))[:16]
        self.gd=load(name,HERE/('sky130_dispatch953.py' if self.pair['pdk']=='SKY130' else 'grouped35_dispatch.py'))
        self.gd.validate_vector(self.vector)
        if self.pair['pdk']=='SKY130':
            from sky130_validation953 import validate_pair
        else:
            from qualification_validation import validate_pair
        self.validator=validate_pair
        self.baseline_reference=list(self.gd.REFERENCE)

    def bind(self,vector,signal_windows=None,power_window=None):
        return self.gd.bind_compiled(self.base['topology'],self.base['primitive_library'],self.base['pdk'],
          top=self.top,pdk_name=PDKS[self.pair['pdk']],vector=vector,
          signal_windows=signal_windows,power_window=power_window)

    def provisional(self,windows=None):
        v=list(self.vector);available=(windows or {}).get('signal_windows',{})
        modules,names=self.gd._reachable(self.base['topology'],self.top)
        for d in DIMS:
            if d['parameter_id'] not in ('R01','R02'):continue
            relevant=[n for n in names if ('ROOT' if n==self.top else 'DESCENDANT')==d['group'] and modules[n].get('instances')]
            if any(n not in available for n in relevant):v[d['index_0based']]=REFERENCE[d['index_0based']]
        return v

    def write_bound(self,result):
        atomic(self.work/'1_topology'/f'{self.top}.verilog.json',result['topology'])
        atomic(self.work/'1_topology/__primitives_library__.json',result['primitive_library'])
        atomic(self.pdk/'layers.json',result['pdk']);self.binding=result

    def launch_files(self):
        paths=[self.pdk/'layers.json',self.work/'1_topology'/f'{self.top}.verilog.json',
          self.work/'1_topology/__primitives_library__.json',self.work/'3_pnr/inputs/layers.json',
          self.work/'3_pnr/inputs'/f'{self.top}.verilog.json',self.work/'3_pnr/__placer_dump__.json']
        paths+=sorted((self.work/'3_pnr/inputs').glob('*.pnr.const.json'))
        return {str(p):sha(p) for p in paths if p.is_file()}

    def phase(self,name,flow):
        global ACTIVE_PROCESS
        self.current=name;identity=verify_runtime()
        if source_hashes(self.pair['pdk'])!=self.request['runner_dependency_sha256']:
            raise StageFailure(name,'Frozen S5 launcher/observer dependency changed')
        basephase=self.admitted.resource_phase(name)
        limit=int(self.request.get('stage_address_space_gib',{}).get(basephase,40))
        timeout=float(self.request.get('stage_timeouts',{}).get(basephase,1200))
        env=self.admitted.environment();env.update(self.native_env)
        env['PYTHONDONTWRITEBYTECODE']='1'
        cmd=[str(self.admitted.PYTHON),str(ROOT/'ALIGN-public/bin/schematic2layout.py'),str(self.out/'input'),
          '-p',str(self.pdk),'-w',str(self.work),'-s',self.top,'-n','1','-e','0','--nroutings','1',
          '--lambda_coeff',str(self.vector[0]),'--seed','1',*flow]
        execution=['/usr/bin/timeout','--signal=TERM','--kill-after=10s',f'{timeout}s',
           '/usr/bin/prlimit',f'--as={limit*1024**3}','--',*cmd]
        stdout=self.out/f'{name}.stdout.log';stderr=self.out/f'{name}.stderr.log'
        row={'phase':name,'status':'waiting_for_resource','command':cmd,'execution_command':execution,
          'runtime_pythonpath':str(RUNTIME),'runtime_module_sha256':NATIVE_SHA,
          'reference_sha256':sha(ROOT/'docs/param/reference_vector_35d.json'),
          'applied_vector':self.vector,'applied_vector_sha256':digest(self.vector),
          'consumer_files_at_launch':self.launch_files(),'native_environment_at_launch':dict(self.native_env),
          'binding_sha256':digest(self.binding['receipt']) if self.binding else None,
          'runtime_check':identity,'stdout':str(stdout),'stderr':str(stderr),
          'address_space_limit_gib':limit,'timeout_s':timeout,'resource_guard':'global_two_ALIGN_processes_v1',
          'runtime_python_source_sha256':{str(p):sha(p) for p in
            [RUNTIME/'align/pnr/placer.py',RUNTIME/'align/pnr/render_placement.py',RUNTIME/'align/pnr/public_payload_copy.py']}}
        atomic(self.out/'current_status.json',row)
        with self.admitted.phase_admission(limit) as inherited,stdout.open('w') as fo,stderr.open('w') as fe:
            row.update(status='running',start_epoch=time.time())
            proc=subprocess.Popen(execution,cwd=self.out,env=env,stdout=fo,stderr=fe,start_new_session=True,pass_fds=inherited)
            ACTIVE_PROCESS=proc;row['pid_in_launcher_namespace']=proc.pid
            atomic(self.out/'current_status.json',row)
            try:
                rc,memory=self.admitted.monitored_wait(proc,timeout+15)
                row.update(returncode=rc,status='completed' if rc==0 else 'timeout' if rc==124 else 'failed',memory=memory)
            except subprocess.TimeoutExpired:
                terminate(proc);row.update(returncode=proc.returncode,status='timeout')
            finally:ACTIVE_PROCESS=None
        row['duration_s']=time.time()-row['start_epoch']
        row['log_tail']=(stderr.read_text(errors='replace')+stdout.read_text(errors='replace'))[-5000:]
        atomic(self.out/f'{name}.json',row);atomic(self.out/'current_status.json',row);self.stages[name]=row
        print(self.pair['circuit_name'],self.pair['pdk'],self.request['config_id'],name,row['status'],flush=True)
        if row['status']!='completed':raise StageFailure(name,row['status']+': '+row['log_tail'][-1600:])
        return row

    def environment_config(self):
        from adapt.action_space.native_tuning_config import NativeTuningConfig
        from adapt.action_space.native_r089_consumer_receipt import freeze_r09_unit_r,detail_environment
        from adapt.action_space.native_power_consumer_receipt import freeze_power_pitch,power_environment
        frozen=self.out/'frozen_original_layers.json';atomic(frozen,self.base['pdk'])
        metals=[r['Layer'] for r in self.base['pdk']['Abstraction'] if r['Layer'].startswith('M')];di=self.base['pdk']['design_info']
        interval=lambda a,b:list(range(metals.index(di[a]),metals.index(di[b])+1))
        sig=freeze_r09_unit_r(frozen,interval('bottom_signal_routing_layer','top_signal_routing_layer'))
        power=freeze_power_pitch(frozen,interval('bottom_power_routing_layer','top_power_routing_layer'),
          resource_provenance={'policy':'frozen_original_PDK_design_info_power_hookup_interval','before_action':True})
        config=NativeTuningConfig.create(self.binding['receipt']['native_requests'])
        self.native_env={'ADAPT_R6_NATIVE_R05_ST_NUMBER':str(self.binding['receipt']['native_requests']['R05'])}
        self.native_env.update(config.router_environment(['R06','R07']))
        self.native_env.update(detail_environment(config,['R09'],sig))
        self.native_env.update(power_environment(config,['W08','W09','W10'],power))
        atomic(self.out/'native_environment.json',self.native_env);atomic(self.out/'native_resources.json',{'signal':sig,'power':power})

    def route_updates(self,windows):
        gd=self.gd;result=self.bind(self.vector,windows['signal_windows'],windows['power_window'])
        desired={m['name']:m for m in result['topology']['modules']}
        routes={name:{k:gd._one(desired[source].get('constraints',[]),'Route').get(k) for k in ('min_layer','max_layer')}
          for name,source in windows['prepared_to_original'].items()}
        updates={self.work/'3_pnr/inputs/layers.json':result['pdk'],self.pdk/'layers.json':result['pdk']}
        for name,route in routes.items():
            p=self.work/'3_pnr/inputs'/f'{name}.pnr.const.json';value=read(p)
            value['constraints']=[c for c in value['constraints'] if c.get('const_name')!='Route']+[{'const_name':'Route',**route,'customize':[]}]
            updates[p]=value
        def patch(value):
            for m in value['modules']:
                name=m.get('name',m.get('abstract_name'))
                if name in routes:
                    r=gd._one(m.get('constraints',[]),'Route');r.update(routes[name]);m['constraints']=gd._replace(m.get('constraints',[]),'Route',r)
            return value
        p=self.work/'3_pnr/inputs'/f'{self.top}.verilog.json';updates[p]=patch(read(p))
        p=self.work/'3_pnr/__placer_dump__.json';dump=read(p)
        for _,alt in dump[2]:patch(alt)
        updates[p]=dump;updates[self.work/'1_topology'/f'{self.top}.verilog.json']=result['topology']
        atomic(self.out/'route_preapply_snapshot.json',{str(p):read(p) for p in updates})
        for p,v in updates.items():atomic(p,v)
        atomic(self.out/'grouped35_reference_binding_after_windows.json',result['receipt'])
        atomic(self.out/'binding.json',result['receipt']);self.binding=result
        return result

    def containment(self,observed,windows):
        from adapt.action_space.shared32_layer_decoder import decode_layer_window
        metals=[r['Layer'] for r in self.base['pdk']['Abstraction'] if r['Layer'].startswith('M')];bad=[]
        for name,access in observed['pin_inventory'].items():
            # pin_inventory and signal_windows are keyed by original compiled
            # module, while prepared native PG clones are separate identities.
            source=name if name in windows['source_to_prepared'] else windows['prepared_to_original'][name]
            group='ROOT' if source==self.top else 'DESCENDANT'
            request={slot:self.vector[self.gd._index(slot,group)] for slot in ('R01','R02')}
            bounds=decode_layer_window(windows['signal_windows'][name],request)['raw_tuple']
            outside=[x for x in access['pin_layers'] if not metals.index(bounds[0])<=metals.index(x)<=metals.index(bounds[1])]
            if outside:bad.append({'module':name,'outside_signal':outside})
        if observed['power_window'] is None:bad.append({'power':'unresolved_after_final_route'})
        else:
            bounds=decode_layer_window(windows['power_window'],{'W03':self.vector[self.gd._index('W03')],'W04':1,'W05':0,'W06':1})['raw_tuple']
            outside=[x for x in observed['power_window']['context']['pin_access']['pin_layers'] if not metals.index(bounds[2])<=metals.index(x)<=metals.index(bounds[3])]
            if outside:bad.append({'outside_power':outside})
        return bad

    def run(self):
        if self.out.exists():raise StageFailure('prepare','Fresh output directory required; never overwrite or silently resume')
        self.out.mkdir(parents=True);self.created_output=True;self.work.mkdir()
        atomic(self.out/'request.json',self.request)
        if self.request.get('contract_sha256')!=sha(CONTRACT_PATH):raise StageFailure('prepare','Frozen Formal35 contract changed')
        if self.request.get('runner_dependency_sha256')!=source_hashes(self.pair['pdk']):
            raise StageFailure('prepare','Frozen S5 launcher/observer dependency changed or missing')
        for key,value in [('source_input_tree_hash',tree_hash(self.bundle/'input')),
                          ('source_pdk_tree_hash',tree_hash(self.bundle/'pdk')),
                          ('source_baseline_sha256',sha(self.bundle/'grouped35_native_baseline.json'))]:
            if self.request.get(key)!=value:raise StageFailure('prepare','Frozen source changed or expected hash missing: '+key)
        source_binding=read(self.bundle/'reference_binding_audit.json')
        if not source_binding.get('reference_binding_verified'):raise StageFailure('prepare','Source reference binding not verified')
        for name in ('input','pdk'):shutil.copytree(self.bundle/name,self.out/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        source_base=read(self.bundle/'grouped35_native_baseline.json');atomic(self.pdk/'layers.json',source_base['pdk'])
        self.input_hash=tree_hash(self.out/'input');self.pdk_hash=tree_hash(self.pdk)
        atomic(self.out/'launch_contract.json',{'runtime':self.identity,'requested35':self.vector,'requested_before_compile':True,
          'source_bundle':str(self.bundle),'input_hash':self.input_hash,'original_pdk_hash':self.pdk_hash,
          'source_baseline_sha256':sha(self.bundle/'grouped35_native_baseline.json'),'all_ALIGN_stages_fresh':True})
        self.phase('compile',['--flow_stop','1_topology'])
        tp=self.work/'1_topology'/f'{self.top}.verilog.json';lp=self.work/'1_topology/__primitives_library__.json'
        if not tp.is_file() or not lp.is_file():raise StageFailure('compile','Required compiler payload absent despite process completion')
        self.base={'top':self.top,'pdk_dir':str(self.pdk),'topology':read(tp),'primitive_library':read(lp),'pdk':read(self.pdk/'layers.json')}
        atomic(self.out/'grouped35_native_baseline.json',self.base)
        self.current='binding_before_primitives';initial=self.bind(self.provisional());self.write_bound(initial)
        atomic(self.out/'before_primitives_binding.json',initial['receipt'])
        self.phase('primitives',['--flow_start','2_primitives','--flow_stop','2_primitives'])
        if not (self.work/'2_primitives/__primitives__.json').is_file():raise StageFailure('primitives','Primitive registry absent')
        self.current='binding_after_primitives'
        stage=self.gd.collect_stage_windows(self.work,self.base['pdk'],self.base['topology'],top=self.top,ordinary_power_flow=True)
        atomic(self.out/'grouped35_stage_windows.json',stage)
        self.write_bound(self.bind(self.provisional(stage),stage['signal_windows'],stage['power_window']))
        atomic(self.out/'placement_binding.json',self.binding['receipt']);self.environment_config()
        self.phase('placement',['--flow_start','3_pnr:prep','--flow_stop','3_pnr:place'])
        if not (self.work/'3_pnr/__placer_dump__.json').is_file():raise StageFailure('placement','Native placement dump absent')
        self.phase('routing_bootstrap',['--flow_start','3_pnr:gui','--flow_stop','3_pnr:route'])
        self.current='binding_final_windows'
        windows=self.gd.collect_selected_windows(self.work,self.base,top=self.top,selected_id=self.top+'_0',ordinary_power_flow=True)
        atomic(self.out/'grouped35_postroute_reference_frozen.json',windows)
        if windows['blocked_signal_windows'] or windows['power_window'] is None:raise StageFailure(self.current,'Actual selected routed pin windows incomplete')
        final=self.route_updates(windows)
        pg_stable=all([(o['object_id'],o['raw_value']) for o in a['objects']]==[(o['object_id'],o['raw_value']) for o in b['objects']]
          for a,b in zip(initial['receipt']['coordinates'][:21],final['receipt']['coordinates'][:21]))
        if not pg_stable:raise StageFailure(self.current,'Final window binding changed already executed P/G requests')
        self.environment_config()
        row=self.phase('routing_reference_s5',['--flow_start','3_pnr:gui','--flow_stop','3_pnr:route'])
        self.current='binding_verification'
        observed=self.gd.collect_selected_windows(self.work,self.base,top=self.top,selected_id=self.top+'_0',ordinary_power_flow=True)
        atomic(self.out/'postroute_observed_windows.json',observed)
        containment=self.containment(observed,windows)
        collector=load('_s5_masks_'+digest(str(self.out))[:16],HERE/'audit/router45/grouped35_runtime_masks_router_v1.py')
        collector.REFERENCE=list(self.vector);collector._write_safe=atomic
        masks=collector.collect_runtime_masks(self.out,top=self.top,route_phase='routing_reference_s5',output_dir=self.out/'runtime_mask_audit')
        atomic(self.out/'actual35_masks.json',masks)
        native=[c for c in masks['coordinates'] if c['parameter_id'] in ('R05','R06','R07','R09','W08','W09','W10')]
        hash_checks={p:Path(p).is_file() and sha(p)==v for p,v in row['consumer_files_at_launch'].items()}
        required={str(p) for p in [self.pdk/'layers.json',self.work/'3_pnr/inputs/layers.json',
          self.work/'3_pnr/inputs'/f'{self.top}.verilog.json',self.work/'3_pnr/__placer_dump__.json',lp,tp]}
        required.update(str(self.work/'3_pnr/inputs'/f'{name}.pnr.const.json') for name in windows['prepared_to_original'])
        checks={'launch_input_hash_checks':hash_checks,'launch_inputs_unchanged':bool(hash_checks) and all(hash_checks.values()),
          'required_consumer_snapshot_complete':required.issubset(hash_checks),'required_consumer_paths':sorted(required),
          'native_environment_matches':row['native_environment_at_launch']==self.native_env,
          'native_events_verified':all(c.get('native_status') in ('observed','inapplicable') for c in native),
          'serialized_bindings_verified':all(c.get('serialized_binding_mask') is True for c in masks['coordinates'][1:25] if c['objects']),
          'primitive_library_hash_matches':self.gd.sha(read(lp))==final['receipt']['bound_primitive_library_sha256'],
          'PG_stable':pg_stable,'pin_containment_failures':containment,
          'applied_vector_exact_at_final_launch':row['applied_vector']==self.vector and row['applied_vector_sha256']==digest(self.vector),
          'lambda_matches_placement_CLI':float(self.stages['placement']['command'][self.stages['placement']['command'].index('--lambda_coeff')+1])==self.vector[0],
          'actual_final_route_phase':'routing_reference_s5'}
        booleans=['launch_inputs_unchanged','required_consumer_snapshot_complete','native_environment_matches','native_events_verified','serialized_bindings_verified',
          'primitive_library_hash_matches','PG_stable','applied_vector_exact_at_final_launch','lambda_matches_placement_CLI']
        checks['binding_verified']=all(checks[k] for k in booleans) and not containment
        atomic(self.out/'formal35_binding_audit.json',checks)
        effective=effective_configuration(final['receipt'],masks,self.native_env,{'case_id':self.pair['case_id'],
          'pdk':self.pair['pdk'],'input_hash':self.input_hash,'original_pdk_hash':self.pdk_hash,'runtime_sha256':NATIVE_SHA,'align_seed':1},
          binding_verified=checks['binding_verified'],power_receipt=read(self.out/'runtime_mask_audit/POWER_native_consumer_receipt.json'))
        atomic(self.out/'effective_configuration.json',effective)
        self.current='validation'
        valid=self.validator(self.work,self.top,self.pdk,self.out/'validation',align_python=self.admitted.PYTHON,pythonpath=RUNTIME,
          run_logs={'paths':[str(self.out/f'routing_reference_s5.{s}.log') for s in ('stdout','stderr')],'returncode':0,'power_profile':'explicit_pdn'},returncode=0)
        atomic(self.out/'validation_result.json',valid)
        geometry_path=self.out/'validation/qualification_full_layout_geometry.json'
        if not geometry_path.is_file():raise StageFailure('metrics','Complete geometry serializer output absent')
        mask_ok=all(masks.get('launch_identity',{}).get(k) is True for k in
           ('formal_phase','binary_sha_matches','reference_sha_matches','native_environment_matches'))
        mask_ok &= all(len(masks.get(k,[]))==35 for k in ['object_mask','decoded_choice_mask','runtime_operation_mask','serialized_binding_mask'])
        observation=gcl(valid,read(geometry_path),self.stages,checks['binding_verified'],mask_ok)
        atomic(self.out/'gcl_observation.json',observation)
        self.result.update(observation);self.result.update(status='G_complete' if observation['G'] else 'incomplete',
          decoded_native_input_hash=effective['decoded_native_input_hash'],effective_configuration=effective,
          masks={k:masks[k] for k in ['object_mask','decoded_choice_mask','runtime_operation_mask','serialized_binding_mask']})
        self.result['final_runtime_check']=verify_runtime()
        return self.result


def execute(request):
    attempt=Attempt(request)
    # Reject before execute/finally so an existing historical attempt is never
    # overwritten with a fresh failure record.
    if attempt.out.exists():raise FileExistsError(attempt.out)
    try:attempt.run()
    except StageFailure as exc:attempt.result.update(status='failed',failure_stage=exc.stage,failure_reason=exc.reason)
    except Exception as exc:attempt.result.update(status='failed',failure_stage=attempt.current,failure_reason=str(exc),traceback=traceback.format_exc())
    if not attempt.created_output:raise FileExistsError('Output was not created by this attempt: '+str(attempt.out))
    attempt.result.update(wall_time_s=time.time()-attempt.started,
       stages={k:{f:v.get(f) for f in ['status','returncode','duration_s','runtime_module_sha256']} for k,v in attempt.stages.items()})
    atomic(attempt.out/'result.json',attempt.result);return attempt.result


def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True)
    p=sub.add_parser('register');p.add_argument('--bundle',required=True,type=Path);p.add_argument('--pair',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    p=sub.add_parser('run');p.add_argument('--request',required=True,type=Path)
    args=ap.parse_args()
    if args.command=='register':
        result=preregister(args.bundle,read(args.pair),args.output)
        print(json.dumps({k:result[k] for k in ['registered_configuration_count','single_coordinate_names']}));return
    for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,interrupted)
    result=execute(read(args.request));print(json.dumps({k:result.get(k) for k in ['config_id','status','G','C','L','failure_stage','failure_reason']},indent=2))


if __name__=='__main__':main()
