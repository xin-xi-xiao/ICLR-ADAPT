"""Read-only S5 receipt verification for an independent geometry observation.

This does not execute runner.execute(), rewrite a result, or create an ALIGN
phase. A derived G is permitted only after the actual attempted vector, native
launch snapshots, selected validation and effective identity still agree.
"""
from pathlib import Path
import json
import sys

sys.dont_write_bytecode = True
import g1_s5_runner953_v2 as runner
import observer953_parameterized_v1 as observer


def evidence(path):
    return observer.evidence(Path(path))


def verify_s5(run, geometry):
    run = Path(run)
    request = runner.read(run / 'request.json')
    original = runner.read(run / 'result.json')
    launch = runner.read(run / 'launch_contract.json')
    assert request['pair']['pdk'] == 'SKY130'
    assert len(request['vector']) == 35
    assert original['request_sha256'] == runner.digest(request)
    assert request['vector'] == original['requested35'] == launch['requested35']
    assert Path(request['output_directory']).resolve() == run.resolve()
    assert Path(launch['source_bundle']).resolve() == Path(request['bundle_path']).resolve()
    assert launch['all_ALIGN_stages_fresh'] is True and launch['requested_before_compile'] is True
    assert runner.tree_hash(run / 'input') == launch['input_hash'] == request['source_input_tree_hash']
    receipts = {phase: runner.read(run / (phase + '.json')) for phase in runner.PHASES}
    assert all(r['status'] == 'completed' and r['returncode'] == 0 and r['runtime_module_sha256'] == runner.NATIVE_SHA
               for r in receipts.values())
    final = receipts['routing_reference_s5']
    assert final['applied_vector'] == request['vector']
    assert final['applied_vector_sha256'] == runner.digest(request['vector'])
    consumer_paths = final['consumer_files_at_launch']
    assert consumer_paths and all(Path(p).is_file() and runner.sha(p) == expected for p, expected in consumer_paths.items())
    binding_audit = runner.read(run / 'formal35_binding_audit.json')
    assert binding_audit['binding_verified'] is True
    assert binding_audit['actual_final_route_phase'] == 'routing_reference_s5'
    required_bools = ['launch_inputs_unchanged', 'required_consumer_snapshot_complete', 'native_environment_matches',
        'native_events_verified', 'serialized_bindings_verified', 'primitive_library_hash_matches', 'PG_stable',
        'applied_vector_exact_at_final_launch', 'lambda_matches_placement_CLI']
    assert all(binding_audit.get(k) is True for k in required_bools)
    assert not binding_audit['pin_containment_failures']
    assert set(binding_audit['required_consumer_paths']).issubset(consumer_paths)
    masks = runner.read(run / 'actual35_masks.json')
    assert masks['route_phase'] == 'routing_reference_s5'
    assert all(masks['launch_identity'].get(k) is True for k in
        ('formal_phase', 'binary_sha_matches', 'reference_sha_matches', 'native_environment_matches'))
    assert all(len(masks.get(k, [])) == 35 for k in
        ('object_mask', 'decoded_choice_mask', 'runtime_operation_mask', 'serialized_binding_mask'))
    environment = runner.read(run / 'native_environment.json')
    assert final['native_environment_at_launch'] == environment
    command = receipts['placement']['command']
    assert float(command[command.index('--lambda_coeff') + 1]) == request['vector'][0]
    identity = {'case_id': request['pair']['case_id'], 'pdk': 'SKY130',
        'input_hash': launch['input_hash'], 'original_pdk_hash': launch['original_pdk_hash'],
        'runtime_sha256': runner.NATIVE_SHA, 'align_seed': 1}
    power_path = run / 'runtime_mask_audit/POWER_native_consumer_receipt.json'
    effective = runner.effective_configuration(runner.read(run / 'binding.json'), masks, environment, identity,
        binding_verified=True, power_receipt=runner.read(power_path) if power_path.exists() else None)
    existing_effective = runner.read(run / 'effective_configuration.json')
    assert effective['decoded_native_input_hash'] == existing_effective['decoded_native_input_hash'] == original['decoded_native_input_hash']
    assert effective['distinctness_witness35'] == existing_effective['distinctness_witness35']
    validation = runner.read(run / 'validation_result.json')
    observed = runner.gcl(validation, geometry, receipts, True, True)
    assert observed['connectivity_and_DRC'] == original['connectivity_and_DRC']
    observed.update(schema='g1-s5-derived-geometry-observation-v1',
        case_id=request['pair']['case_id'], circuit_name=request['pair']['circuit_name'], pdk='SKY130',
        run_directory=str(run.resolve()), config_id=request['config_id'], source_bundle=request['bundle_path'],
        requested35=request['vector'], decoded_native_input_hash=effective['decoded_native_input_hash'],
        effective_configuration=effective, native_attempt_is_existing=True, native_runs_started=0,
        actual_final_route_phase='routing_reference_s5', original_result=evidence(run / 'result.json'),
        original_GCL={k: original[k] for k in ('G', 'C', 'L')},
        validation=evidence(run / 'validation_result.json'),
        runtime=runner.verify_runtime(),
        source_binding_proof={
            'request': evidence(run / 'request.json'), 'launch_contract': evidence(run / 'launch_contract.json'),
            'formal35_binding_audit': evidence(run / 'formal35_binding_audit.json'),
            'serialized_binding': evidence(run / 'binding.json'), 'masks': evidence(run / 'actual35_masks.json'),
            'effective_configuration': evidence(run / 'effective_configuration.json'),
            'native_environment': evidence(run / 'native_environment.json'),
            'phase_receipts': {p: evidence(run / (p + '.json')) for p in runner.PHASES},
            'final_consumer_snapshots_verified': dict(consumer_paths),
            'all35_requested_values_match_final_executed_phase': True,
            'effective_identity_and_distinctness_witness_unchanged': True})
    return observed
