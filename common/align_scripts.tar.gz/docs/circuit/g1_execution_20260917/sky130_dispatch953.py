"""Staged binding of formal grouped35 to actual ALIGN compiler artifacts.

Pure bind_compiled() never writes or imports ALIGN.  dispatch_files() writes
only below docs/circuit/selected, preserving immutable native input snapshots.
Masks concern actual compiled objects and distinct decoded inputs; no function
in this module claims runtime hits, successful routing or effective response.
"""
from __future__ import annotations
import argparse
import copy
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).absolute().parents[3]
# This copy is intentionally sandboxed under the G1 execution root.  The
# production dispatcher remains untouched; all writes are limited to HERE.
SELECTED = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
from adapt.action_space.placement_track_mapping import placement_track_values
from adapt.action_space.shared32_primitive_adapter import (
    _electrical, _capability, _generator, _legal_pair, resolve_height_mapping)
from adapt.action_space.shared32_compiled_net_broadcast import _native_values
from adapt.action_space.shared32_layer_decoder import (decode_layer_window, _lef_pin_layers,
    collect_baseline_pin_layers, build_signal_layer_windows, build_power_layer_windows)
from adapt.action_space.shared32_power_layer_decoder import declare_power_resources

from sky130_contract953 import sky_capability, sky_height_mapping

CONTRACT = json.loads((ROOT/'docs/param/adapt_formal_grouped_space_v1.json').read_text())
DIMS = CONTRACT['dimensions']
REFERENCE = CONTRACT['reference_vector']
GROUPS = CONTRACT['groups']
PDK_FAMILY = {'FinFET14nm_Mock_PDK': 'finfet', 'Bulk65nm_Mock_PDK': 'bulk',
              'Bulk45nm_Mock_PDK': 'bulk',
              # Isolated PDK adapter only.  SKY130's official ALIGN PDK uses
              # the bulk MOS generator protocol; shared ALIGN source is not
              # modified and the adapter's native consumer evidence remains
              # a separate qualification gate.
              'SKY130': 'bulk'}
UNSETS = ['ADAPT_R6_NATIVE_R04_GRID_TARGET', 'ADAPT_R6_NATIVE_SIGNAL_METALS',
          'ADAPT_R6_NATIVE_G05_MINVIAS', 'ADAPT_R6_NATIVE_R08_GRID_SCALE',
          'ADAPT_R6_NATIVE_W07_POWER_WIDTH']


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def validate_vector(vector=None):
    value = list(REFERENCE if vector is None else vector)
    if len(value) != 35:
        raise ValueError('exactly 35 numeric coordinates required')
    for d, v in zip(DIMS, value):
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v not in d['allowed_values']:
            raise ValueError(f"{d['name']}: {v!r} not in frozen domain {d['allowed_values']}")
    return value


def _index(slot, group=None):
    return next(d['index_0based'] for d in DIMS if d['parameter_id'] == slot and d['group'] == group)


def _one(constraints, kind):
    rows = [c for c in constraints if c.get('constraint') == kind]
    if len(rows) > 1:
        raise ValueError(f'ambiguous multiple hard {kind} constraints')
    return copy.deepcopy(rows[0]) if rows else {'constraint': kind}


def _replace(constraints, kind, row):
    return [c for c in constraints if c.get('constraint') != kind] + [row]


def _reachable(topology, top):
    modules = {m['name']: m for m in topology['modules']}
    if len(modules) != len(topology['modules']) or top not in modules:
        raise ValueError('unique compiled module definitions and exact top required')
    done, active, ordered = set(), set(), []
    def visit(name):
        if name in active:
            raise ValueError('recursive compiled hierarchy is unsupported')
        if name in done:
            return
        active.add(name); ordered.append(name)
        for inst in modules[name].get('instances', []):
            if inst['abstract_template_name'] in modules:
                visit(inst['abstract_template_name'])
        active.remove(name); done.add(name)
    visit(top)
    return modules, ordered


def _role_map(modules, names, top, spec):
    roles = {n: {'power': set(), 'ground': set()} for n in names}
    evidence = []
    for n in names:
        for c in modules[n].get('constraints', []):
            role = {'PowerPorts': 'power', 'GroundPorts': 'ground'}.get(c.get('constraint'))
            if role:
                roles[n][role].update(c['ports']); evidence.append({'module': n, 'constraint': copy.deepcopy(c)})
    if spec is not None:
        if spec.get('top', top) != top:
            raise ValueError('role specification top mismatch')
        declared = spec.get('top_exclusions', spec)
        for role in ('power', 'ground'):
            values = declared.get(role, [])
            if any(n not in modules[top]['parameters'] for n in values):
                raise ValueError('explicit supply role must name actual compiled top port')
            roles[top][role].update(values)
        evidence.append({'explicit_role_spec': copy.deepcopy(spec)})
    known = bool(roles[top]['power'] and roles[top]['ground'])
    changed = True
    while changed:
        changed = False
        for name in names:
            for inst in modules[name].get('instances', []):
                child = inst['abstract_template_name']
                if child not in roles:
                    continue
                for fa in inst['fa_map']:
                    for role in ('power', 'ground'):
                        if fa['actual'] in roles[name][role] and fa['formal'] not in roles[child][role]:
                            roles[child][role].add(fa['formal']); changed = True
    for name in names:
        if roles[name]['power'] & roles[name]['ground']:
            raise ValueError(f'{name}: conflicting supply roles')
        for inst in modules[name].get('instances', []):
            child = inst['abstract_template_name']
            if child not in roles:
                continue
            for fa in inst['fa_map']:
                for role in ('power', 'ground'):
                    if fa['formal'] in roles[child][role] and fa['actual'] not in roles[name][role]:
                        raise ValueError(f'{child}/{fa["formal"]}: inconsistent rail role across shared-master occurrences')
    return roles, known, evidence


def _net_groups(module, role):
    endpoints = {}
    for inst in module.get('instances', []):
        for fa in inst['fa_map']:
            endpoints.setdefault(fa['actual'], set()).add((inst['instance_name'], fa['formal']))
    parent = {n: n for n in endpoints}
    def find(n):
        parent.setdefault(n, n)
        if parent[n] != n:
            parent[n] = find(parent[n])
        return parent[n]
    for c in module.get('constraints', []):
        if c.get('constraint') == 'SymmetricNets':
            a, b = find(c['net1']), find(c['net2']); parent[a] = b
    components = {}
    for n in list(parent):
        components.setdefault(find(n), []).append(n)
    blocked = set(role['power']) | set(role['ground'])
    dnr = {n for c in module.get('constraints', []) if c.get('constraint') == 'DoNotRoute' for n in c['nets']}
    weights = _native_values(module.get('constraints', []), native=False)['P08']
    rows = []
    for component in components.values():
        ports = any(n in module['parameters'] for n in component)
        degree = max((len(endpoints.get(n, [])) for n in component), default=0)
        group = ('PORT_' if ports else 'INTERNAL_') + ('BRANCH' if degree >= 3 else 'LOW')
        reason = 'supply_component' if set(component) & blocked else 'DoNotRoute_component' if set(component) & dnr else None
        for net in sorted(component):
            count = len(endpoints.get(net, [])); baseline = weights.get(net, 1)
            rows.append({'module': module['name'], 'net': net, 'group': group,
                         'component': sorted(component), 'component_degree': degree,
                         'block_endpoint_count': count, 'baseline_weight': baseline,
                         'exclusion': reason or ('zero_block_endpoints' if count == 0 else None),
                         'choice_reason': 'baseline_weight_zero' if baseline == 0 else None})
    return rows


def _polarity(model, library):
    seen = []
    while model not in ('NMOS', 'PMOS'):
        if model in seen or model not in library or not library[model].get('base'):
            return None, seen + [model]
        seen.append(model); model = library[model]['base']
    return model[0], seen + [model]


def bind_compiled(topology, primitive_library, pdk, *, top, pdk_name,
                  vector=None, role_spec=None, signal_windows=None,
                  power_window=None, native_resources=None):
    """Return modified payloads + auditable masks without writing files.

    signal_windows: {compiled_module_name: frozen shared32 layer-window dict}.
    power_window: frozen shared32 power layer-window dict. Missing windows do
    not block reference P/G binding: R01/R02 0/1 preserve the native envelope;
    W03 remains pending until a genuine power resource/pin window is supplied.
    native_resources: optional independently frozen R09/W08 decoder receipts;
    returned requests are not activation/consumer evidence.
    """
    values = validate_vector(vector)
    t, lib, layers = copy.deepcopy(topology), copy.deepcopy(primitive_library), copy.deepcopy(pdk)
    modules, names = _reachable(t, top)
    original = {m['name']: m for m in topology['modules']}
    records = [{**copy.deepcopy(d), 'requested': values[d['index_0based']], 'objects': [],
                'excluded_objects': [], 'pending': [], 'reference_binding_status': 'not_bound',
                'runtime_hit_count': None, 'effective_mask': None,
                'consumer_evidence_status': 'unobserved'} for d in DIMS]
    def obj(slot, group, identity, raw, choices, **details):
        rec = records[_index(slot, group)]
        payload = {'object_id': identity, 'raw_value': raw,
                   'decoded_choices': choices, 'distinct_decoded_choice_count': len({sha(v) for v in choices.values()}) if choices is not None else None,
                   'runtime_hit_count': None, **details}
        rec['objects'].append(payload); rec['reference_binding_status'] = 'request_bound'
    def pending(slot, group, reason):
        records[_index(slot, group)]['pending'].append(reason)
    def requested(slot, group=None):
        return values[_index(slot, group)]
    obj('P01', None, 'run:placement_objective', requested('P01'), {str(v): v for v in DIMS[0]['allowed_values']}, binding='CLI --lambda_coeff')
    # Module-specific placement increments, preserving AR and horizontal halo.
    for name in names:
        m = modules[name]; group = 'ROOT' if name == top else 'DESCENDANT'
        baseline = copy.deepcopy(original[name].get('constraints', []))
        if not m.get('instances'):
            for slot in ('P04', 'P05', 'P07', 'R01', 'R02'):
                records[_index(slot, group)]['excluded_objects'].append({'object_id': name, 'reason': 'empty_compiled_module'})
            continue
        action = {'P04': requested('P04', group), 'P05': requested('P05', group), 'P06': 0, 'P07': requested('P07', group)}
        mapping = placement_track_values(baseline, pdk, action)
        for slot, kind in [('P04', 'HorizontalDistance'), ('P05', 'VerticalDistance'), ('P07', 'Boundary')]:
            coordinate = records[_index(slot, group)]
            choices = {}
            for val in coordinate['allowed_values']:
                altered = dict(action); altered[slot] = val
                detail = placement_track_values(baseline, pdk, altered)['slots'][slot]
                if slot == 'P07':
                    bound = _one(baseline, 'Boundary').get('max_height', 100000)
                    if bound is not None and 2 * detail['raw_value'] >= float(bound):
                        continue
                choices[str(val)] = detail['effective_native']
            raw = mapping['slots'][slot]['raw_value']
            if str(requested(slot, group)) not in choices:
                # int/float representation is not a dimension change.
                if not any(float(k) == requested(slot, group) for k in choices):
                    raise ValueError(f'{name}/{slot}: requested value violates hard Boundary')
            row = _one(baseline, kind)
            row['halo_vertical' if slot == 'P07' else 'abs_distance'] = raw
            m['constraints'] = _replace(m.get('constraints', []), kind, row)
            obj(slot, group, name, raw, choices, mapping=mapping['slots'][slot], binding='compiled_module_constraint')
        window = (signal_windows or {}).get(name)
        if window:
            request = {'R01': requested('R01', group), 'R02': requested('R02', group)}
            decoded = decode_layer_window(window, request)
            route = _one(baseline, 'Route')
            route.update(decoded['raw_values'])
            m['constraints'] = _replace(m.get('constraints', []), 'Route', route)
            for slot in ('R01', 'R02'):
                choices = {str(v): decode_layer_window(window, {**request, slot: v})['slot_raw_values'][slot]
                           for v in records[_index(slot, group)]['allowed_values']}
                obj(slot, group, name, decoded['slot_raw_values'][slot], choices,
                    frozen_window_sha256=window['frozen_sha256'], binding='compiled_Route', actual_pin_recheck_required=True)
        else:
            if requested('R01', group) != 0 or requested('R02', group) != 1:
                raise ValueError(f'{name}: nonreference route coordinates require frozen physical pin windows')
            route = _one(baseline, 'Route')
            for slot, field, native in [('R01', 'min_layer', 'bottom_signal_routing_layer'), ('R02', 'max_layer', 'top_signal_routing_layer')]:
                raw = route.get(field, pdk.get('design_info', {}).get(native))
                obj(slot, group, name, raw, None, binding='original_native_window_preserved', raw_resolution='native hard/default envelope; not a pin-qualified decoded window')
                records[_index(slot, group)]['reference_binding_status'] = 'native_reference_preserved_pending_pin_window'
                pending(slot, group, f'{name}: need primitive/child pin-layer evidence for conditional choices')
    # Exact logical net grouping. No name-based rail guessing or rank selection.
    roles, roles_known, role_evidence = _role_map(modules, names, top, role_spec)
    net_rows = []
    if not roles_known:
        for group in GROUPS['net']:
            if requested('P08', group) != 1:
                raise ValueError('nonreference net weight requires explicit power/ground intent')
            pending('P08', group, 'explicit top power and ground roles incomplete; original weights preserved')
    else:
        for name in names:
            m = modules[name]
            for row in _net_groups(original[name], roles[name]):
                net_rows.append(row); group = row['group']; identity = name + '/' + row['net']
                if row['exclusion']:
                    records[_index('P08', group)]['excluded_objects'].append({'object_id': identity, 'reason': row['exclusion']})
                    continue
                alpha = requested('P08', group); raw = row['baseline_weight'] * alpha
                if not float(raw).is_integer():
                    raise ValueError('NetPriority consumer requires integer priority')
                m.setdefault('constraints', []).append({'constraint': 'NetPriority', 'nets': [row['net']], 'weight': int(raw)})
                obj('P08', group, identity, int(raw), {str(v): row['baseline_weight'] * v for v in records[_index('P08', group)]['allowed_values']},
                    baseline_weight=row['baseline_weight'], component=row['component'], block_endpoint_count=row['block_endpoint_count'], binding='compiled_NetPriority')
    # MOS groups use the actual base chain, elements and generator capability.
    indexed = {p['name']: p for p in lib}
    used = {i['abstract_template_name'] for name in names for i in modules[name].get('instances', [])}
    primitive_rows = []
    family = PDK_FAMILY.get(pdk_name)
    for primitive in lib:
        name = primitive['name']
        if name not in used or (primitive.get('generator') or {}).get('name', '').upper() != 'MOS':
            continue
        elements = primitive.get('elements', [])
        polpaths = [_polarity(e['model'], indexed) for e in elements]
        pols = {pol for pol, path in polpaths}
        info = {'primitive': name, 'element_count': len(elements), 'base_chains': [p for _, p in polpaths]}
        primitive_rows.append(info)
        if len(pols) != 1 or None in pols or not elements:
            info['status'] = 'blocked_unknown_or_mixed_model_base'; continue
        pol = next(iter(pols)); group = pol + ('_SINGLE' if len(elements) == 1 else '_MULTI')
        info['group'] = group
        try:
            if family is None:
                raise ValueError('PDK MOS adapter protocol unavailable')
            _, params = _generator(primitive)
            # Current bulk source requires even NF, matching FinFET.
            if any(int(e['parameters']['NF']) % 2 for e in elements):
                raise ValueError('native MOS requires even NF')
            electrical = _electrical(primitive, family, pdk)
            height = sky_height_mapping(params, electrical['fin'], pdk) if pdk_name == 'SKY130' else resolve_height_mapping(params, electrical['fin'], pdk)
            caps = sky_capability(primitive, params, electrical) if pdk_name == 'SKY130' else _capability(primitive, params, electrical)
            info.update(electrical=electrical, capabilities=caps, height_mapping=height)
        except Exception as exc:
            info.update(status='blocked_static_capability', reason=str(exc))
            for slot in ('G01', 'G02'):
                records[_index(slot, group)]['excluded_objects'].append({'object_id': name, 'reason': str(exc)})
            continue
        info['status'] = 'compiled_capability_resolved'
        changed = copy.deepcopy(params)
        for slot in ('G01', 'G02', 'G04'):
            g = group if slot != 'G04' else pol + '_EQUAL_COMMON_SOURCE_PAIR'
            if caps[slot]['status'] != 'eligible':
                records[_index(slot, g)]['excluded_objects'].append({'object_id': name, **caps[slot]})
                continue
            dim = records[_index(slot, g)]
            if slot == 'G01':
                choices = {str(v): height['reference_height'] + int(v) * height['legal_increment'] for v in dim['allowed_values']}
                raw = height['reference_height'] + int(requested(slot, g)) * height['legal_increment']
                changed['height'] = raw
            elif slot == 'G02':
                product = electrical['factor_product']
                pairs = {(x, product // x) for x in range(1, math.isqrt(product) + 1) if product % x == 0}
                pairs |= {(y, x) for x, y in pairs}
                pairs = sorted((pair for pair in pairs if _legal_pair(pair, params.get('legal_sizes'))), key=lambda xy: (Fraction(*xy), *xy))
                if not pairs:
                    raise ValueError(f'{name}: original hard legal_sizes leaves no feasible factor pair')
                choices = {str(v): [{'x': pairs[math.floor(v * (len(pairs) - 1) + .5)][0], 'y': pairs[math.floor(v * (len(pairs) - 1) + .5)][1]}] for v in dim['allowed_values']}
                xy = pairs[math.floor(requested(slot, g) * (len(pairs) - 1) + .5)]
                raw = [{'x': xy[0], 'y': xy[1]}]; changed['legal_sizes'] = raw
                info['pure_input_factor_pairs'] = [list(pair) for pair in pairs]
            else:
                choices = {str(v): v for v in dim['allowed_values']}; raw = requested(slot, g); changed['shared_diff'] = raw
            obj(slot, g, name, raw, choices, binding='compiled_Generator.parameters',
                capability_basis='actual compiled electrical elements + audited native source protocol',
                generated_artifact_confirmation='pending', pdk_protocol='bulk_same_gen_param_electrical_mapping_pending_physical_validation' if pdk_name == 'Bulk45nm_Mock_PDK' else family)
        for constraint in primitive['constraints']:
            if constraint.get('constraint') == 'Generator':
                constraint['parameters'] = changed
    # Native stage requests: joint binary activation is caller-owned.
    native_requests = {slot: requested(slot) for slot in ('R05', 'R06', 'R07', 'R09', 'W08', 'W09', 'W10')}
    native_conditions = {'R05': 'global-router Steiner candidate routine invoked',
        'R06': 'UpdateEdgeWeight is invoked on used graph edges',
        'R07': 'AdjustPlateEdgeCapacity executes at least one applicable plate operation',
        'R09': 'signal symmetry-reference A* invoked with frozen unit_R resource decoder',
        'W08': 'ordinary power-hookup A* invoked with frozen pitch decoder',
        'W09': 'power SetSrcDest candidate construction invoked',
        'W10': 'power SetSrcDest window construction invoked'}
    for slot, val in native_requests.items():
        rec = records[_index(slot)]
        obj(slot, None, 'native_stage:' + slot, val, {str(v): v for v in rec['allowed_values']},
            binding='request_only_caller_must_set_joint_binary_environment', consumer_condition=native_conditions[slot],
            normalized_not_raw=slot in ('R09', 'W08'))
        rec['reference_binding_status'] = 'native_request_exported_not_activated'
        pending(slot, None, native_conditions[slot])
    design = layers.setdefault('design_info', {})
    power_known = roles_known and len(roles[top]['power']) == len(roles[top]['ground']) == 1
    for slot, field in [('W01', 'h_skip_factor'), ('W02', 'v_skip_factor')]:
        if power_known:
            design[field] = requested(slot)
            obj(slot, None, 'ordinary_top_PDN:' + top, requested(slot), {str(v): v for v in records[_index(slot)]['allowed_values']}, binding='PDK_copy.design_info', consumer_condition='ordinary top power grid enabled')
        else:
            pending(slot, None, 'single supply-pair ordinary PDN scope not established; source field preserved')
    if power_window is not None:
        q = {'W03': requested('W03'), 'W04': 1, 'W05': 0, 'W06': 1}
        decoded = decode_layer_window(power_window, q)
        design.update(decoded['raw_values'])
        choices = {str(v): decode_layer_window(power_window, {**q, 'W03': v})['raw_tuple'] for v in DIMS[_index('W03')]['allowed_values']}
        obj('W03', None, 'ordinary_top_PDN:' + top, decoded['raw_tuple'], choices,
            binding='PDK_copy.design_info_four_layer_tuple', frozen_window_sha256=power_window['frozen_sha256'],
            fixed_nontunable_quantiles={'W04': 1, 'W05': 0, 'W06': 1})
    else:
        pending('W03', None, 'power layer reference (.5,1,0,1) still needs actual frozen power resource/pin window; source fields preserved')
    for rec in records:
        objects = rec['objects']; rec['object_mask'] = True if objects else None if rec['pending'] else False
        counts = [o['distinct_decoded_choice_count'] for o in objects]
        rec['choice_mask'] = True if any(c is not None and c >= 2 for c in counts) else None if any(c is None for c in counts) or rec['pending'] else False
        rec['request_write_count'] = sum(o.get('binding') not in ('original_native_window_preserved', 'request_only_caller_must_set_joint_binary_environment', 'CLI --lambda_coeff') for o in objects)
    report = {'schema': 'adapt-grouped35-compiled-dispatch-v1', 'top': top, 'pdk_name': pdk_name,
        'vector': values, 'dimension_count': 35, 'contract_sha256': sha(CONTRACT),
        'baseline_topology_sha256': sha(topology), 'baseline_primitive_library_sha256': sha(primitive_library), 'baseline_pdk_sha256': sha(pdk),
        'bound_topology_sha256': sha(t), 'bound_primitive_library_sha256': sha(lib), 'bound_pdk_sha256': sha(layers),
        'reachable_modules': names, 'unreachable_modules_preserved': sorted(set(modules) - set(names)),
        'role_evidence': role_evidence, 'roles': {n: {k: sorted(v) for k, v in r.items()} for n, r in roles.items()},
        'net_objects': net_rows, 'primitive_objects': primitive_rows, 'coordinates': records,
        'object_mask': [r['object_mask'] for r in records], 'choice_mask': [r['choice_mask'] for r in records],
        'runtime_effective_mask': [None] * 35, 'mask_authority': 'compiled object / decoded input choices only, NOT observed native hits or legal final layout',
        'lambda_coeff': requested('P01'), 'native_requests': native_requests, 'native_resources': copy.deepcopy(native_resources),
        'required_environment_unsets': UNSETS, 'power_scope_single_supply_pair': power_known,
        'pending_coordinates': [r['name'] for r in records if r['pending']],
        'formal_reference_binding_complete': not any(r['pending'] for r in records),
        'physical_qualification_status': 'unobserved'}
    return {'topology': t, 'primitive_library': lib, 'pdk': layers, 'receipt': report}


def _write_safe(path, data):
    path = Path(path).absolute()
    if not path.resolve().is_relative_to(SELECTED.resolve()):
        raise ValueError('dispatcher writes are restricted to docs/circuit/selected')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


def collect_stage_windows(workdir, pdk, topology, *, top, role_spec=None,
                          module_pin_evidence=None, ordinary_power_flow=False):
    """Freeze from actual generated LEF/JSON; never relabel child proxies.

    The caller explicitly declares ordinary_power_flow when configuring the
    native ordinary-PDN branch. This declaration is configuration evidence,
    not a claim that PowerRouter has executed. Parent module interfaces need
    actual routed child exports and can remain pending after primitive stage.
    """
    modules, names = _reachable(topology, top)
    roles, known, evidence = _role_map(modules, names, top, role_spec)
    pins = collect_baseline_pin_layers(workdir, top, module_pin_evidence=module_pin_evidence)
    signals, blocked = {}, {}
    for name in names:
        access = pins.get('modules', {}).get(name, {})
        window = build_signal_layer_windows(pdk, module_name=name,
            constraints=modules[name].get('constraints', []), pin_access=access,
            resource_policy='design_info_bounds_and_hard_route', provenance={'authority': 'actual generated LEF and JSON crosscheck'})
        if window.get('status') == 'ready_static':
            signals[name] = window
        else:
            blocked[name] = window
    power = None; power_reason = None
    access = pins.get('modules', {}).get(top, {})
    endpoints = [e for e in access.get('endpoints', []) if e.get('actual') in roles[top]['power'] | roles[top]['ground']]
    verified = bool(endpoints) and all(e.get('pin_layers') and e.get('evidence_kind') != 'unverified_recursive_leaf_proxy' for e in endpoints)
    if known and verified and ordinary_power_flow:
        pp = {'module_name': top, 'complete': True,
              'pin_layers': sorted({layer for e in endpoints for layer in e['pin_layers']}),
              'provenance': {'method': 'actual compiled supply endpoints matched to generated LEF/JSON',
                             'endpoints': endpoints, 'artifacts': pins.get('artifacts', [])}}
        pe = {'complete': True, 'power_profile': 'explicit_pdn', 'ordinary_power_flow': True,
              'power_ports': sorted(roles[top]['power']), 'ground_ports': sorted(roles[top]['ground']),
              'provenance': {'authority': 'caller configured ordinary PDN; actual execution unobserved', 'source_roles': evidence}}
        declaration = declare_power_resources(pdk)
        candidate = build_power_layer_windows(pdk, top=top, pin_access=pp, power_evidence=pe,
            grid_allowed_layers=declaration['grid_allowed_layers'],
            routing_allowed_layers=declaration['routing_allowed_layers'],
            resource_policy='explicit', provenance={**pp['provenance'], 'resource_declaration': declaration})
        if candidate.get('status') == 'ready_static':
            power = candidate
        else:
            power_reason = candidate
    else:
        power_reason = {'reason': 'ordinary PDN identity or actual supply endpoint pin layers incomplete',
                        'known_roles': known, 'verified_supply_endpoints': verified,
                        'ordinary_power_flow_configured': ordinary_power_flow}
    return {'signal_windows': signals, 'power_window': power, 'pin_inventory': pins,
            'blocked_signal_windows': blocked, 'blocked_power_window': power_reason}


def dispatch_files(workdir, pdk_dir, *, top, output_dir, vector=None, role_spec=None,
                   signal_windows=None, power_window=None, apply=False,
                   pdk_name=None, stage='before_primitives', module_pin_evidence=None,
                   ordinary_power_flow=False):
    work, pdk_dir, out = Path(workdir).absolute(), Path(pdk_dir).absolute(), Path(output_dir).absolute()
    tp = work/'1_topology'/f'{top}.verilog.json'; lp = work/'1_topology/__primitives_library__.json'; pp = pdk_dir/'layers.json'
    cache = out/'grouped35_native_baseline.json'
    if cache.exists():
        base = json.loads(cache.read_text())
        if base['top'] != top or base['pdk_dir'] != str(pdk_dir):
            raise ValueError('baseline cache belongs to another top/PDK')
    else:
        base = {'top': top, 'pdk_dir': str(pdk_dir), 'topology': json.loads(tp.read_text()),
                'primitive_library': json.loads(lp.read_text()), 'pdk': json.loads(pp.read_text())}
        _write_safe(cache, base)
    frozen_stage = None
    if stage == 'after_primitives':
        frozen_stage = collect_stage_windows(work, base['pdk'], base['topology'], top=top,
            role_spec=role_spec, module_pin_evidence=module_pin_evidence,
            ordinary_power_flow=ordinary_power_flow)
        if signal_windows is None:
            signal_windows = frozen_stage['signal_windows']
        if power_window is None:
            power_window = frozen_stage['power_window']
        _write_safe(out/'grouped35_stage_windows.json', frozen_stage)
    elif stage != 'before_primitives':
        raise ValueError('stage must be before_primitives or after_primitives')
    result = bind_compiled(base['topology'], base['primitive_library'], base['pdk'], top=top,
        pdk_name=pdk_name or base['pdk'].get('grouped35_source_pdk_name', pdk_dir.name), vector=vector,
        role_spec=role_spec, signal_windows=signal_windows, power_window=power_window)
    result['receipt']['stage'] = stage
    result['receipt']['ordinary_power_flow_configured'] = ordinary_power_flow
    if frozen_stage is not None:
        result['receipt']['stage_window_summary'] = {'ready_signal_modules': list(frozen_stage['signal_windows']),
            'blocked_signal_modules': list(frozen_stage['blocked_signal_windows']),
            'power_window_ready': frozen_stage['power_window'] is not None}
    _write_safe(out/'grouped35_dispatch_receipt.json', result['receipt'])
    _write_safe(out/'binding.json', result['receipt'])
    _write_safe(out/'grouped35_bound_topology.json', result['topology'])
    _write_safe(out/'grouped35_bound_primitive_library.json', result['primitive_library'])
    _write_safe(out/'grouped35_bound_layers.json', result['pdk'])
    if apply:
        _write_safe(tp, result['topology']); _write_safe(lp, result['primitive_library']); _write_safe(pp, result['pdk'])
    return result


def collect_selected_windows(workdir, baseline, *, top, selected_id, ordinary_power_flow):
    """Use real selected prepared modules, including native PG clones.

    Routing completion and electrical/layout validity are deliberately separate
    from the evidence that these physical pin contacts existed. Parent/child
    identity is paired by instance paths against compiler output, not a suffix
    heuristic. Selected native child LEF is authoritative; primitive LEF and
    JSON must agree. Power pins use the selected top imported pin geometry.
    """
    work = Path(workdir).absolute(); pdk = baseline['pdk']; artifacts = {}
    def read(path, as_json=True):
        raw = path.read_bytes(); artifacts[str(path)] = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()}
        return json.loads(raw) if as_json else raw.decode()
    if Path(selected_id).name != selected_id:
        raise ValueError('selected_id must be an exact local concrete top basename')
    prepared = read(work/'3_pnr/inputs'/f'{top}.verilog.json')
    placement = read(work/'3_pnr/Results'/f'{selected_id}.scaled_placement_verilog.json')
    routed = read(work/'3_pnr'/f'{selected_id}.json')
    original, original_names = _reachable(baseline['topology'], top)
    prep, prep_names = _reachable(prepared, top)
    concrete = {m['concrete_name']: m for m in placement['modules']}
    leaves = {m['concrete_name']: m for m in placement['leaves']}
    if selected_id not in concrete or concrete[selected_id]['abstract_name'] != top:
        raise ValueError('exact selected concrete top missing')
    mapping = {}; source_to_prepared = {}
    def map_pair(source_name, prepared_name, ancestors=()):
        if (source_name, prepared_name) in ancestors:
            raise ValueError('recursive compiler/prep correspondence')
        if prepared_name in mapping:
            if mapping[prepared_name] != source_name:
                raise ValueError('one prepared module maps to contradictory compiler definitions')
            return
        mapping[prepared_name] = source_name
        source_to_prepared.setdefault(source_name, []).append(prepared_name)
        source_instances = {i['instance_name']: i for i in original[source_name]['instances']}
        target_instances = {i['instance_name']: i for i in prep[prepared_name]['instances']}
        if source_instances.keys() != target_instances.keys():
            raise ValueError('prep instance set differs from compiler; explicit correspondence required')
        for name, target in target_instances.items():
            source = source_instances[name]; a = source['abstract_template_name']; b = target['abstract_template_name']
            if a in original:
                if b not in prep:
                    raise ValueError('compiled module lost its prepared module identity')
                map_pair(a, b, (*ancestors, (source_name, prepared_name)))
            elif a != b:
                raise ValueError('primitive abstract template changed during prep')
    map_pair(top, top)
    metal_order = {r['Layer']: i for i, r in enumerate(pdk['Abstraction']) if r['Layer'].startswith('M')}
    rails = {x['actual'] for x in prepared.get('global_signals', []) if x['formal'] in ('supply0', 'supply1')}
    inventory = {}; cache = {}; visited = set(); cap_sources = {}; cap_evidence = {}
    cap_manifest_path = work/'3_pnr/__cap_map__.json'
    if cap_manifest_path.exists():
        for abstract, gds in read(cap_manifest_path):
            source = (work/'3_pnr'/gds).resolve()
            if not source.is_relative_to((work/'3_pnr').resolve()):
                raise ValueError('capgen map must identify a local PnR artifact')
            if source.stem in cap_sources:
                raise ValueError('ambiguous concrete capgen source')
            cap_sources[source.stem] = {'abstract': abstract, 'gds_source': source}
    def leaf_pins(name):
        if name in cache: return cache[name]
        if name in cap_sources:
            # CC caps are generated by 3_pnr cap_placer, not 2_primitives.
            # Its viewer JSON legitimately labels every shape as drawing;
            # exported native LEF contacts remain the pin authority.
            source=cap_sources[name]['gds_source']
            geometry=read(source.with_suffix('.json'))
            native=_lef_pin_layers(read(source.with_suffix('.lef'), False),name)
            drawing_layers={}
            for row in geometry['terminals']:
                if row.get('layer') in metal_order and row.get('netName') in native:
                    rect=row.get('rect')
                    if not isinstance(rect,list) or len(rect)!=4 or rect[0]>=rect[2] or rect[1]>=rect[3]:
                        raise ValueError(f'{name}: capgen conductor geometry invalid')
                    drawing_layers.setdefault(row['netName'],set()).add(row['layer'])
            if any(not layers or not layers.issubset(drawing_layers.get(pin,set())) for pin,layers in native.items()):
                raise ValueError(f'{name}: capgen exported LEF contacts have no same-net/layer generated conductors')
            cap_evidence[name]={'authority':'native capgen LEF PIN/PORT',
                'abstract_name':cap_sources[name]['abstract'],'source_json':str(source.with_suffix('.json')),
                'source_lef':str(source.with_suffix('.lef')),
                'crosscheck':'same-net same-layer positive metal geometry in actual capgen JSON; drawing is not relabeled pin',
                'native_ports':{pin:sorted(layers) for pin,layers in native.items()},
                'source_code':'ALIGN-public/align/pnr/cap_placer.py:36-51; main.py:285-299'}
            cache[name]=native;return native
        geometry = read(work/'2_primitives'/f'{name}.json')
        native = _lef_pin_layers(read(work/'2_primitives'/f'{name}.lef', False), name)
        viewer = {}
        for row in geometry['terminals']:
            if row.get('netType') == 'pin':
                viewer.setdefault(row['netName'], set())
                if row['layer'].startswith('M'): viewer[row['netName']].add(row['layer'])
        if viewer != native:
            raise ValueError(f'{name}: primitive LEF/JSON pin mismatch')
        cache[name] = native; return native
    def exported_pins(name):
        if name in cache: return cache[name]
        m = concrete[name]; native = _lef_pin_layers(read(work/'3_pnr/Results'/f'{name}.lef', False), m['abstract_name'])
        geometry = read(work/'3_pnr'/f'{name}.json')
        for formal in m['parameters']:
            if not native.get(formal): raise ValueError(f'{name}/{formal}: missing real native exported contact')
        for row in geometry['terminals']:
            if row.get('netType') == 'pin' and row.get('netName') in m['parameters'] and row.get('layer', '').startswith('M'):
                if row['layer'] not in native.get(row['netName'], set()):
                    raise ValueError(f'{name}: viewer exported pin inconsistent with native LEF')
        cache[name] = native; return native
    def visit(name, ancestors=()):
        if name in ancestors: raise ValueError('selected placement hierarchy cycle')
        if name in visited: return
        visited.add(name); module = concrete[name]; abstract = module['abstract_name']
        if abstract not in mapping or module['parameters'] != prep[abstract]['parameters']:
            raise ValueError('selected placement does not match prepared module ports')
        rows = []
        for inst in module['instances']:
            target = inst['concrete_template_name']
            if target in concrete:
                visit(target, (*ancestors, name)); contacts = exported_pins(target); kind = 'selected_routed_child_native_LEF'
            elif target in leaves:
                contacts = leaf_pins(target); kind = 'selected_capgen_native_LEF_and_generated_conductors' if target in cap_sources else 'selected_primitive_LEF_JSON'
            else: raise ValueError(f'{target}: selected concrete instance unaccounted')
            for fa in inst['fa_map']:
                formal, actual = fa['formal'], fa['actual']
                layers = contacts.get(formal, set())
                if not layers or not layers.issubset(metal_order):
                    raise ValueError(f'{name}/{inst["instance_name"]}/{formal}: no verified known metal contact')
                # Keep all connected instance formals conservatively, consistent
                # with the existing baseline layer decoder, including leaf rails.
                rows.append({'instance_name': inst['instance_name'], 'concrete_template_name': target,
                    'formal': formal, 'actual': actual, 'pin_layers': sorted(layers, key=metal_order.get),
                    'evidence_kind': kind, 'global_supply': actual in rails})
        entry = inventory.setdefault(mapping[abstract], {'module_name': mapping[abstract], 'complete': True,
            'pin_layers': [], 'prepared_modules': [], 'concrete_modules': [], 'endpoints': []})
        entry['prepared_modules'] = sorted(set(entry['prepared_modules']) | {abstract})
        entry['concrete_modules'].append(name); entry['endpoints'].extend(rows)
        entry['pin_layers'] = sorted(set(entry['pin_layers']) | {l for r in rows for l in r['pin_layers']}, key=metal_order.get)
    visit(selected_id)
    signals = {}; blocked = {}
    for name in original_names:
        access = inventory.get(name, {'module_name': name, 'complete': False, 'pin_layers': []})
        access['provenance'] = {'method': 'selected concrete placement + native exported child LEF and primitive LEF/JSON',
            'artifacts': list(artifacts.values()), 'selected_id': selected_id,
            'quality_status': 'independent_not_implied_by_pin_evidence'}
        window = build_signal_layer_windows(pdk, module_name=name, constraints=original[name].get('constraints', []),
            pin_access=access, resource_policy='design_info_bounds_and_hard_route', provenance=access['provenance'])
        (signals if window.get('status') == 'ready_static' else blocked)[name] = window
    globals_by_role = {role: [r['actual'] for r in prepared.get('global_signals', []) if r['formal'] == formal]
        for role, formal in [('power', 'supply1'), ('ground', 'supply0')]}
    supply = {rail: [] for names in globals_by_role.values() for rail in names}
    for row in routed.get('terminals', []):
        if row.get('netType') == 'pin' and row.get('netName') in supply and row.get('layer') in metal_order:
            rect = row.get('rect')
            if not isinstance(rect, list) or len(rect) != 4 or rect[0] >= rect[2] or rect[1] >= rect[3]:
                raise ValueError('actual selected imported power pin has invalid geometry')
            supply[row['netName']].append({'layer': row['layer'], 'rect': rect})
    power = None; power_blocked = None; declaration = declare_power_resources(pdk)
    if ordinary_power_flow and all(len(x) == 1 for x in globals_by_role.values()) and supply and all(supply.values()):
        pp = {'module_name': top, 'complete': True, 'pin_layers': sorted({r['layer'] for v in supply.values() for r in v}, key=metal_order.get),
            'provenance': {'method': 'selected top imported actual pin contacts; not PDN drawing records',
                'selected_id': selected_id, 'rails': globals_by_role, 'contact_counts': {k: len(v) for k,v in supply.items()}, 'artifacts': list(artifacts.values())}}
        pe = {'complete': True, 'power_profile': 'explicit_pdn', 'ordinary_power_flow': True,
            'power_ports': globals_by_role['power'], 'ground_ports': globals_by_role['ground'],
            'provenance': {'configured_branch': 'ordinary top power grid and hookup; no PDN_mode override'}}
        candidate = build_power_layer_windows(pdk, top=top, pin_access=pp, power_evidence=pe,
            grid_allowed_layers=declaration['grid_allowed_layers'], routing_allowed_layers=declaration['routing_allowed_layers'],
            resource_policy='explicit', provenance={'resource_declaration': declaration, 'pin_access': pp['provenance']})
        if candidate.get('status') == 'ready_static': power = candidate
        else: power_blocked = candidate
    else:
        power_blocked = {'reason': 'ordinary power configuration, exact rail identity, or real selected supply contacts missing',
            'globals_by_role': globals_by_role, 'contact_counts': {k: len(v) for k,v in supply.items()}}
    return {'signal_windows': signals, 'power_window': power, 'blocked_signal_windows': blocked,
        'blocked_power_window': power_blocked, 'pin_inventory': inventory, 'prepared_to_original': mapping,
        'source_to_prepared': source_to_prepared, 'power_resource_declaration': declaration,
        'selected_capgen_pin_evidence':cap_evidence,
        'artifacts': list(artifacts.values()), 'selected_id': selected_id,
        'physical_qualification_status': 'not_inferred_from_pin_artifacts'}


def postroute_reference_check(workdir, pdk_dir, *, top, output_dir, selected_id, pdk_name,
                              ordinary_power_flow=True, apply=False):
    """Freeze true windows and prepare a route-only reference correction.

    Call apply=True only after the preceding ALIGN process has exited. Exact
    raw input equality is necessary but does not itself certify native hooks,
    final geometry legality or electrical signoff. Frozen windows are retained
    across reference rerouting; rerouting does not redefine its own decoder.
    """
    work, pdk_dir, out = map(lambda p: Path(p).absolute(), (workdir, pdk_dir, output_dir))
    baseline = json.loads((out/'grouped35_native_baseline.json').read_text())
    frozen_path = out/'grouped35_postroute_reference_frozen.json'
    observed = collect_selected_windows(work, baseline, top=top, selected_id=selected_id,
                                       ordinary_power_flow=ordinary_power_flow)
    if frozen_path.exists():
        frozen = json.loads(frozen_path.read_text())
    else:
        frozen = observed
        if not frozen['blocked_signal_windows'] and frozen['power_window'] is not None:
            _write_safe(frozen_path, frozen)
    if frozen['blocked_signal_windows'] or frozen['power_window'] is None:
        report = {'status': 'blocked_reference_windows', 'requires_reroute': None, 'windows': observed}
        _write_safe(out/'grouped35_postroute_reference_check.json', report); return report
    result = bind_compiled(baseline['topology'], baseline['primitive_library'], baseline['pdk'], top=top,
        pdk_name=pdk_name, signal_windows=frozen['signal_windows'], power_window=frozen['power_window'])
    desired_modules = {m['name']: m for m in result['topology']['modules']}
    raw_routes = {name: {key: _one(desired_modules[source].get('constraints', []), 'Route').get(key)
                       for key in ('min_layer', 'max_layer')}
                  for name, source in observed['prepared_to_original'].items()}
    differences = []; updates = {}
    pdk_input = work/'3_pnr/inputs/layers.json'
    actual_pdk = json.loads(pdk_input.read_text())
    fields = ('bottom_power_grid_layer', 'top_power_grid_layer', 'bottom_power_routing_layer', 'top_power_routing_layer',
              'h_skip_factor', 'v_skip_factor')
    for field in fields:
        actual = actual_pdk['design_info'].get(field); expected = result['pdk']['design_info'].get(field)
        if actual != expected: differences.append({'file': str(pdk_input), 'field': 'design_info.'+field, 'executed': actual, 'reference': expected})
    updates[str(pdk_input)] = result['pdk']; updates[str(pdk_dir/'layers.json')] = result['pdk']
    for name, expected in raw_routes.items():
        path = work/'3_pnr/inputs'/f'{name}.pnr.const.json'; payload = json.loads(path.read_text())
        actual = {key: actual_pdk['design_info']['bottom_signal_routing_layer' if key == 'min_layer' else 'top_signal_routing_layer'] for key in expected}
        for c in payload['constraints']:
            if c.get('const_name') == 'Route':
                for key in expected:
                    if c.get(key) is not None: actual[key] = c[key]
        if actual != expected: differences.append({'file': str(path), 'field': 'Route', 'executed': actual, 'reference': expected})
        payload['constraints'] = [c for c in payload['constraints'] if c.get('const_name') != 'Route'] + [{'const_name': 'Route', **expected, 'customize': []}]
        updates[str(path)] = payload
    def patch_modules(payload):
        for m in payload['modules']:
            name = m.get('name', m.get('abstract_name'))
            if name in raw_routes:
                route = _one(m.get('constraints', []), 'Route'); route.update(raw_routes[name])
                m['constraints'] = _replace(m.get('constraints', []), 'Route', route)
        return payload
    topology_path = work/'3_pnr/inputs'/f'{top}.verilog.json'
    updates[str(topology_path)] = patch_modules(json.loads(topology_path.read_text()))
    dump_path = work/'3_pnr/__placer_dump__.json'; dump = json.loads(dump_path.read_text())
    for _, alternative in dump[2]: patch_modules(alternative)
    updates[str(dump_path)] = dump
    updates[str(work/'1_topology'/f'{top}.verilog.json')] = result['topology']
    containment = []
    metal_names = [r['Layer'] for r in baseline['pdk']['Abstraction'] if r['Layer'].startswith('M')]
    for name, access in observed['pin_inventory'].items():
        raw = decode_layer_window(frozen['signal_windows'][name], (0, 1))['raw_tuple']
        outside = [layer for layer in access['pin_layers'] if not metal_names.index(raw[0]) <= metal_names.index(layer) <= metal_names.index(raw[1])]
        if outside: containment.append({'module': name, 'current_pin_layers_outside_frozen_reference': outside})
    if observed['power_window'] is None:
        containment.append({'module':top,'power_pin_recheck_blocked':observed['blocked_power_window']})
    else:
        raw=decode_layer_window(frozen['power_window'],(.5,1,0,1))['raw_tuple']
        actual_pins=observed['power_window']['context']['pin_access']['pin_layers']
        outside=[layer for layer in actual_pins if not metal_names.index(raw[2]) <= metal_names.index(layer) <= metal_names.index(raw[3])]
        if outside:containment.append({'module':top,'current_power_pin_layers_outside_frozen_hookup_reference':outside})
    report = {'status': 'reference_inputs_match' if not differences and not containment else 'requires_route_only_correction' if differences else 'frozen_reference_pin_containment_failed',
        'requires_reroute': bool(differences), 'current_consumer_inputs_match_formal_reference_raw': not differences,
        'executed_matches_formal_reference_raw': None,
        'execution_identity_note': 'Current input equality alone is not execution proof. Require the runner phase prelaunch input hashes, completed invocation and native argument receipts.',
        'raw_differences': differences, 'reference_raw_routes': raw_routes,
        'reference_power_raw': {f: result['pdk']['design_info'][f] for f in fields},
        'current_pin_containment_blockers': containment,
        'consumer_update_paths': list(updates), 'apply_performed': apply,
        'frozen_window_file': str(frozen_path), 'reference_vector': REFERENCE,
        'physical_qualification_status': 'requires_separate_completed_run_native_hooks_and_geometry_validation',
        'route_resume_required': '3_pnr:route; reuse placement coordinates, not original placement optimization',
        'source_evidence': ['ALIGN-public/align/pnr/main.py:364-366', 'ALIGN-public/align/pnr/router.py:32-65,351-404',
                            'ALIGN-public/align/pnr/manipulate_hierarchy.py:29-67,79-112']}
    _write_safe(out/'grouped35_route_only_updates.json', updates)
    _write_safe(out/'grouped35_postroute_reference_check.json', report)
    _write_safe(out/'grouped35_postroute_observed_windows.json', observed)
    _write_safe(out/'grouped35_reference_binding_after_windows.json', result['receipt'])
    if apply:
        _write_safe(out/'grouped35_route_only_preapply_inputs.json', {path: json.loads(Path(path).read_text()) for path in updates})
        for path, payload in updates.items(): _write_safe(path, payload)
        _write_safe(out/'binding.json', result['receipt'])
        _write_safe(out/'grouped35_dispatch_receipt.json', result['receipt'])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workdir', type=Path, required=True); parser.add_argument('--pdk-dir', type=Path, required=True)
    parser.add_argument('--top', required=True); parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--pdk-name', choices=tuple(PDK_FAMILY))
    parser.add_argument('--stage', choices=('before_primitives', 'after_primitives', 'postroute_reference'), default='before_primitives')
    parser.add_argument('--selected-id')
    parser.add_argument('--ordinary-pdn', action='store_true')
    for name in ('vector', 'role-spec', 'signal-windows', 'power-window', 'module-pin-evidence'):
        parser.add_argument('--' + name, type=Path)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    if args.stage == 'postroute_reference':
        if not args.selected_id or not args.pdk_name:
            parser.error('postroute_reference requires --selected-id and --pdk-name')
        result = postroute_reference_check(args.workdir, args.pdk_dir, top=args.top, output_dir=args.output_dir,
            selected_id=args.selected_id, pdk_name=args.pdk_name, ordinary_power_flow=args.ordinary_pdn, apply=args.apply)
        print(json.dumps(result, ensure_ascii=False, indent=2)); return
    load = lambda p: json.loads(p.read_text()) if p else None
    result = dispatch_files(args.workdir, args.pdk_dir, top=args.top, output_dir=args.output_dir,
        vector=load(args.vector), role_spec=load(args.role_spec), signal_windows=load(args.signal_windows),
        power_window=load(args.power_window), apply=args.apply, pdk_name=args.pdk_name, stage=args.stage,
        module_pin_evidence=load(args.module_pin_evidence), ordinary_power_flow=args.ordinary_pdn)
    print(json.dumps({k: result['receipt'][k] for k in ('dimension_count', 'object_mask', 'choice_mask', 'pending_coordinates')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
