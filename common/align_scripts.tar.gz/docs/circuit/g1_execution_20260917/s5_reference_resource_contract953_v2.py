"""Receipt-backed S5 resource contract V2 (private G1 adapter).

This module is standard-library only and deliberately does not import ALIGN.
It extends the older stack64-only contract to actual per-phase timeout/AS
receipts, including references which retain the host/default stack while a
placement timeout is explicitly extended.  It never edits an existing receipt
or infers a resource from a different run.
"""
from pathlib import Path
import copy
import hashlib
import json

HERE = Path(__file__).resolve().parent
NATIVE = '953242f473f836d0c4317a01a767f96fe3c44e7bbb351e9f4aaa0c8647fd7e52'
STACK = 64 * 1024**2
BASE_PHASES = ('compile', 'primitives', 'placement', 'routing')
REFERENCE_PHASES = ('compile', 'primitives', 'placement', 'routing', 'routing_reference_v1')
S5_PHASES = ('compile', 'primitives', 'placement', 'routing_bootstrap', 'routing_reference_s5')


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def ev(path):
    path = Path(path)
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def require(test, reason):
    if not test:
        raise ValueError(reason)


def base_phase(phase):
    if phase.startswith('routing'):
        return 'routing'
    require(phase in BASE_PHASES, 'Unknown resource phase: ' + str(phase))
    return phase


def _number(value, name):
    require(type(value) in (int, float) and value > 0, 'Invalid ' + name)
    return value


def _profile_data(profile):
    # Two historical private wrappers used either a flat profile or a nested
    # `profile` object.  Keep both forms receipt-visible; never normalize by
    # editing the original file.
    nested = profile.get('profile')
    return nested if isinstance(nested, dict) else profile


def _command_has_as(command, gib):
    return any(str(x) == '--as=' + str(int(gib) * 1024**3) for x in (command or []))


def _runtime_sha(stage, profile):
    p = _profile_data(profile)
    return (stage.get('runtime_module_sha256') or
            profile.get('runtime', {}).get('native_sha256') or
            p.get('runtime', {}).get('native_sha256'))


def _declared_timeout(manifest, base):
    declared = manifest.get('_stage_timeouts', {})
    if base in declared:
        return declared[base], 'manifest_override'
    return 1200, 'default_1200'


def _profile_timeout(profile, base):
    p = _profile_data(profile)
    mapping = p.get('stage_timeouts')
    if isinstance(mapping, dict) and base in mapping:
        return mapping[base], 'profile_stage_timeouts'
    # A flat resource profile describes the stage which produced it.
    if profile.get('resource_stage') == base and profile.get('applied_timeout_s') is not None:
        return profile['applied_timeout_s'], 'profile_applied_timeout'
    if profile.get('phase') == base and profile.get('timeout_s') is not None:
        return profile['timeout_s'], 'profile_timeout'
    return None, 'not_recorded'


def _profile_as(profile, base):
    p = _profile_data(profile)
    mapping = p.get('stage_address_space_gib')
    if isinstance(mapping, dict) and base in mapping:
        return mapping[base], 'profile_stage_address_space'
    for key in ('AS_GiB', 'address_space_limit_gib'):
        if profile.get(key) is not None:
            return profile[key], 'profile_flat_address_space'
        if p.get(key) is not None:
            return p[key], 'profile_nested_address_space'
    return None, 'not_recorded'


def _stack_evidence(manifest, profile, phase):
    declared = manifest.get('_stack_soft_limit_bytes')
    if declared is not None:
        require(type(declared) is int and declared > 0, 'Invalid declared stack soft limit')
        require(profile.get('stack_soft_bytes') == declared,
                'Explicit stack reference lacks matching stack receipt: ' + phase)
        probe = profile.get('child_inheritance_probe')
        require(isinstance(probe, list) and probe and probe[0] == declared,
                'Explicit stack reference lacks child inheritance evidence: ' + phase)
        return {'mode': 'explicit_soft_limit', 'soft_bytes': declared,
                'hard_bytes': profile.get('stack_hard_bytes'),
                'child_inheritance_probe': probe,
                'evidence_kind': profile.get('stack_evidence_kind', 'recorded_child_inheritance')}
    # A default-stack reference may still carry an explicit placement/routing
    # timeout.  No numeric stack value is invented.  The absence itself is a
    # contract fact and future S5 receipts must report their observed probe.
    require('_stack_soft_limit_bytes' not in manifest,
            'Unexpected stack declaration')
    require(profile.get('stack_soft_bytes') is None and
            profile.get('child_inheritance_probe') is None,
            'Default-stack contract cannot hide a conflicting explicit stack receipt: ' + phase)
    return {'mode': 'default_unmodified', 'soft_bytes': None,
            'hard_bytes': None, 'child_inheritance_probe': None,
            'evidence_kind': 'reference_did_not_override_stack_limit'}


def reference_contract(bundle, require_full=True):
    bundle = Path(bundle).resolve()
    require(bundle.is_relative_to(HERE), 'Reference must stay in private G1 workspace')
    manifest_path = bundle / 'input_manifest.json'
    require(manifest_path.is_file(), 'Missing input manifest')
    manifest = read(manifest_path)
    profiles = {}
    stages = {}
    phase_resources = {}
    # Every phase has to be an actual native receipt; bootstrap-only or a
    # declaration-only profile cannot create a resource contract.
    for phase in REFERENCE_PHASES:
        stage_path = bundle / (phase + '.json')
        profile_path = bundle / 'resource_profiles' / (phase + '.json')
        require(stage_path.is_file() and profile_path.is_file(),
                'Missing actual reference stage/profile: ' + phase)
        stage, profile = read(stage_path), read(profile_path)
        stages[phase], profiles[phase] = stage, profile
        base = base_phase(phase)
        require(stage.get('phase') == phase and stage.get('status') == 'completed' and stage.get('returncode') == 0,
                'Reference phase not actually completed: ' + phase)
        require(stage.get('start_epoch') is not None, 'Reference phase has no launch timestamp: ' + phase)
        require(_runtime_sha(stage, profile) == NATIVE, 'Reference runtime mismatch: ' + phase)
        as_gib = stage.get('address_space_limit_gib')
        require(type(as_gib) is int and as_gib > 0, 'Reference AS missing from native receipt: ' + phase)
        require(_command_has_as(stage.get('execution_command'), as_gib),
                'Reference execution command does not show declared AS: ' + phase)
        timeout = stage.get('timeout_s')
        _number(timeout, 'reference timeout')
        declared, declared_kind = _declared_timeout(manifest, base)
        # An override must be honoured exactly.  For a default declaration,
        # permit a recorded extended timeout only when the profile explicitly
        # states that this phase was intentionally extended (e.g. placement7200).
        ptimeout, ptimeout_kind = _profile_timeout(profile, base)
        if declared_kind == 'manifest_override':
            require(timeout == declared, 'Actual timeout differs from manifest override: ' + phase)
        elif timeout != 1200:
            require(ptimeout == timeout and ptimeout_kind in ('profile_applied_timeout', 'profile_stage_timeouts'),
                    'Unstated extended timeout lacks profile provenance: ' + phase)
        require(ptimeout in (None, timeout), 'Profile timeout differs from native receipt: ' + phase)
        pas, _ = _profile_as(profile, base)
        if pas is not None:
            require(int(pas) == int(as_gib), 'Profile AS differs from native receipt: ' + phase)
        stack = _stack_evidence(manifest, profile, phase)
        current = {'timeout_s': timeout, 'address_space_gib': as_gib,
                   'timeout_source': ptimeout_kind if ptimeout is not None else declared_kind,
                   'stack': stack}
        if base in phase_resources:
            require(phase_resources[base] == current,
                    'Duplicate phase resource receipts differ: ' + base)
        else:
            phase_resources[base] = current
    # A phase may be represented twice by routing and routing_reference_v1;
    # the equality check above requires both actual receipts to agree.
    if manifest.get('_stage_address_space_gib') is not None:
        declared_as = manifest['_stage_address_space_gib']
        require(set(declared_as).issubset(BASE_PHASES), 'Unknown manifest AS phase')
        for p in BASE_PHASES:
            require(int(declared_as.get(p, manifest.get('_address_space_limit_gib', 0))) ==
                    phase_resources[p]['address_space_gib'], 'Manifest AS differs from receipt: ' + p)
    policy = manifest.get('_resource_policy')
    if not policy:
        # For default-stack placement extensions, the nested resource profile
        # is the provenance of the policy rather than a guessed label.
        for p in profiles.values():
            q = _profile_data(p).get('policy') or p.get('policy')
            if q:
                policy = q
                break
    policy = policy or 'default-stack-receipt-backed'
    signature = {'phase_resources': phase_resources, 'policy': policy,
                 'stack_mode': phase_resources['compile']['stack']['mode']}
    # Keep full-flow qualification separate from resource verification.  The
    # caller can require G using its authoritative validation/snapshot row.
    binding = bundle / 'reference_binding_audit.json'
    if require_full:
        require(binding.is_file() and read(binding).get('reference_binding_verified') is True,
                'Reference binding not completed')
    return {'schema': 'g1-s5-receipt-backed-resource-contract953-v2',
            'required': True, 'reference_run': str(bundle),
            'reference_manifest': ev(manifest_path), 'resource_policy': policy,
            'phase_resources': phase_resources, 'resource_signature': digest(signature),
            'reference_stage_resource_evidence': {
                phase: {'stage': ev(bundle / (phase + '.json')),
                        'resource_profile': ev(bundle / 'resource_profiles' / (phase + '.json'))}
                for phase in REFERENCE_PHASES},
            'implementation': ev(__file__),
            'qualification_not_inferred_from_resource_receipts': True,
            'native_input_identity_and_vector_unchanged': True,
            'stack_evidence_scope': phase_resources['compile']['stack'],
            'full_flow_receipts_verified': True}


def augment_request(request, contract):
    require(contract.get('required') and contract.get('full_flow_receipts_verified'), 'Invalid reference contract')
    out = copy.deepcopy(request)
    resources = contract['phase_resources']
    stage_timeouts = {p: resources[p]['timeout_s'] for p in BASE_PHASES}
    stage_as = {p: resources[p]['address_space_gib'] for p in BASE_PHASES}
    additions = {'stage_timeouts': stage_timeouts,
                 'stage_address_space_gib': stage_as,
                 'resource_policy': contract['resource_policy'],
                 'resource_contract': copy.deepcopy(contract)}
    stack = contract['stack_evidence_scope']
    if stack['mode'] == 'explicit_soft_limit':
        additions['stack_soft_limit_bytes'] = stack['soft_bytes']
    for key, val in additions.items():
        require(key not in request or request[key] == val,
                'Conflicting request resource field: ' + key)
        out[key] = copy.deepcopy(val)
    return out


def verify_request(request):
    contract = reference_contract(request['bundle_path'])
    require(request.get('resource_contract') == contract, 'Missing/stale V2 resource contract')
    expected = augment_request({k: request[k] for k in ('bundle_path',) if k in request}, contract)
    for key in ('stage_timeouts', 'stage_address_space_gib', 'resource_policy'):
        require(request.get(key) == expected[key], 'S5 request resource mismatch: ' + key)
    stack = contract['stack_evidence_scope']
    if stack['mode'] == 'explicit_soft_limit':
        require(request.get('stack_soft_limit_bytes') == stack['soft_bytes'], 'S5 stack mismatch')
    else:
        require('stack_soft_limit_bytes' not in request or request.get('stack_soft_limit_bytes') is None,
                'Default-stack request must not inject a stack override')
    return contract


def _verify_stage(run, phase, contract, request):
    stage_path = Path(run) / (phase + '.json')
    profile_path = Path(run) / 'resource_profiles' / (phase + '.json')
    require(stage_path.is_file() and profile_path.is_file(), 'Missing S5 receipt/profile: ' + phase)
    stage, profile = read(stage_path), read(profile_path)
    base = base_phase(phase)
    res = contract['phase_resources'][base]
    require(stage.get('phase') == phase and stage.get('status') == 'completed' and stage.get('returncode') == 0,
            'S5 phase incomplete: ' + phase)
    require(stage.get('runtime_module_sha256') == NATIVE and stage.get('start_epoch') is not None,
            'S5 runtime/launch missing: ' + phase)
    require(stage.get('timeout_s') == res['timeout_s'] and stage.get('address_space_limit_gib') == res['address_space_gib'],
            'S5 resource differs from reference: ' + phase)
    require(_command_has_as(stage.get('execution_command'), res['address_space_gib']),
            'S5 command AS differs from reference: ' + phase)
    if res['stack']['mode'] == 'explicit_soft_limit':
        require(profile.get('stack_soft_bytes') == res['stack']['soft_bytes'], 'S5 explicit stack differs: ' + phase)
        probe = profile.get('child_inheritance_probe')
        require(isinstance(probe, list) and probe and probe[0] == res['stack']['soft_bytes'],
                'S5 explicit stack child proof missing: ' + phase)
    else:
        require(profile.get('stack_mode') == 'default_unmodified',
                'S5 default-stack mode not recorded: ' + phase)
        require(isinstance(profile.get('child_inheritance_probe'), list),
                'S5 default-stack child probe missing: ' + phase)
    require(profile.get('resource_signature') == contract['resource_signature'],
            'S5 resource signature differs: ' + phase)
    require(profile.get('reference_contract_sha256') == digest(contract),
            'S5 contract hash differs: ' + phase)
    require(profile.get('request_canonical_sha256') == digest(request),
            'S5 request identity differs: ' + phase)
    request_file = profile.get('request_file')
    require(request_file and sha(request_file) == profile.get('request_file_sha256') and read(request_file) == request,
            'S5 request file changed: ' + phase)
    return {'phase': phase, 'native_receipt': ev(stage_path), 'resource_profile': ev(profile_path)}


def matching_attempt(attempt, required):
    if not required.get('required'):
        return {'matches': True, 'scope': 'ordinary_reference_behavior_unchanged'}
    if not required.get('full_flow_receipts_verified'):
        return {'matches': False, 'reason': 'reference_resource_contract_not_verified'}
    try:
        request = read(Path(attempt['run_id']) / 'request.json')
        actual = verify_request(request)
        require(actual['reference_run'] == required['reference_run'] and
                actual['resource_signature'] == required['resource_signature'],
                'Attempt matched to a different reference resource contract')
        proof = [_verify_stage(attempt['run_id'], phase, actual, request) for phase in S5_PHASES]
        return {'matches': True, 'verified_stage_profiles': proof,
                'resource_signature': actual['resource_signature'],
                'scope': 'actual_reference_per_phase_timeout_AS_and_stack_inheritance_match_v2'}
    except Exception as exc:
        return {'matches': False, 'reason': 'actual_reference_S5_resource_mismatch_or_missing_proof_v2',
                'error': f'{type(exc).__name__}: {exc}'}


def summary_reference_profile(run):
    try:
        c = reference_contract(run)
        return {**c, 'contract_verified': True, 'policy': c['resource_policy']}
    except Exception as exc:
        return {'required': True, 'contract_verified': False, 'reference_run': str(run),
                'error': f'{type(exc).__name__}: {exc}',
                'cannot_assume_default_resources': True}
