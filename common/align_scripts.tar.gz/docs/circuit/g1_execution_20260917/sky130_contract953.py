"""SKY130 consumer-specific mapping. No ALIGN or physical-rule changes."""
import math
from adapt.action_space.shared32_primitive_adapter import _capability


def sky_capability(primitive, parameters, electrical):
    result = _capability(primitive, parameters, electrical)
    result['G02'] = {
        'status': 'inapplicable_native_consumer',
        'reason': 'This pinned SKY130 gen_param.py enumerates factor pairs and does not consume Generator.parameters.legal_sizes; dimension remains present but inactive.',
        'source': 'sky130_sources/pdk/gen_param.py:add_primitive',
    }
    return result


def sky_height_mapping(parameters, fin, pdk):
    rows = {x['Layer']: x for x in pdk['Abstraction']}
    pf, p2 = int(rows['Fin']['Pitch']), int(rows['M2']['Pitch'])
    if not isinstance(fin, int) or fin < 2:
        raise ValueError('SKY130 W/Fin_pitch must represent at least two width units')
    step = math.lcm(4, p2 // math.gcd(pf, p2))
    supplied = parameters.get('height', 28)
    if isinstance(supplied, bool) or int(supplied) != supplied or supplied < 0:
        raise ValueError('height must be a nonnegative integer')
    # SKY130 does not perform the mock-generator max(height, fin+16)
    # fallback. Supply that legal reference explicitly through the existing
    # Generator.height consumer in frozen ALIGN primitive/main.py.
    reference = math.ceil(max(28, fin + 16, supplied) / step) * step
    return {
        'fin': fin, 'fin_pitch': pf, 'm2_pitch': p2,
        'api_height': 28, 'original_height_raw': parameters.get('height'),
        'original_height_key_present': 'height' in parameters,
        'native_main_height_input': supplied,
        'native_baseline_effective_height': supplied,
        'native_baseline_height_legal': supplied % 4 == 0 and supplied * pf % p2 == 0 and (supplied-fin)//2 >= 8,
        'reference_height': reference, 'legal_increment': step,
        'reference_changes_native_height': reference != supplied,
        'raw_height_by_k': {str(k): reference + k*step for k in (0,1,2,4)},
        'electrical_width_authority': 'SKY130 gen_param W [m] * 1e9 / design_info.Fin_pitch; pre-existing NFIN is not authoritative',
        'consumer': 'frozen ALIGN primitive/main.py Generator.height -> SKY130 mos.py MOSGenerator.finDummy >= 8',
    }
