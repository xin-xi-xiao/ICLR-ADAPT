"""Private, cumulative ALIGN runtime for reference qualification; no shared edits."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PYTHON = ROOT / 'ALIGN-public/general/bin/python'
PYTHONPATH = HERE / 'runtime/pythonpath'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def setup():
    dest = PYTHONPATH / 'align'
    receipt = HERE / 'runtime/runtime_receipt.json'
    if receipt.exists():
        return json.loads(receipt.read_text())
    source = ROOT / 'ALIGN-public/general/lib/python3.12/site-packages/align'
    binary = ROOT / 'experiments/r6_pilot/native_build_power_v1/PnR.cpython-312-x86_64-linux-gnu.so'
    PYTHONPATH.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, dest, dirs_exist_ok=True)
    shutil.copy2(binary, dest / binary.name)
    patches = []
    for name in ['align_r6_power_route_observer_v1.patch', 'align_r6_empty_placement_guard_v1.patch']:
        patch = ROOT / 'experiments/r6_pilot/source_patches' / name
        result = subprocess.run(['patch', '-p1', '-i', str(patch)], cwd=PYTHONPATH, capture_output=True, text=True)
        patches.append({'path': str(patch), 'sha256': sha(patch), 'returncode': result.returncode,
                        'stdout': result.stdout, 'stderr': result.stderr})
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
    env = environment()
    probe = subprocess.run([str(PYTHON), '-c', 'import align, align.PnR; print(align.__file__); print(align.PnR.__file__)'],
                           cwd=HERE, env=env, capture_output=True, text=True, check=True)
    result = {'schema': 'grouped35-reference-runtime-v1', 'python': str(PYTHON),
              'pythonpath': str(PYTHONPATH), 'module_path': str(dest / binary.name),
              'module_sha256': sha(dest / binary.name), 'binary_source': str(binary),
              'inherited_native_profiles': ['ownership', 'R05', 'R0467', 'R089', 'W07-W10'],
              'patches': patches, 'runtime_import_probe': probe.stdout,
              'rvt_suppression_patch': False, 'shared_sources_changed': False}
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    return result

def environment():
    env = os.environ.copy()
    for k in list(env):
        if k.startswith('ADAPT_R6_'):
            del env[k]
    env.update(PYTHONPATH=os.pathsep.join(map(str, [PYTHONPATH, ROOT / 'src', HERE])),
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               PYTHONHASHSEED='1', ALIGN_HOME=str(ROOT / 'ALIGN-public'))
    return env

if __name__ == '__main__':
    print(json.dumps(setup(), indent=2))
