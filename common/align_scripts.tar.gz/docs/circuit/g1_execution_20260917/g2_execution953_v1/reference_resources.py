"""Read actual G1 phase receipts into a new G2 per-phase resource contract.

Does not rewrite historical receipts, invent stack measurements, qualify a
layout, or launch ALIGN. Unlike old S5 helpers, stages need not share routing
budgets and missing optional profile files do not erase actual command facts.
"""
from pathlib import Path
import copy
import hashlib
import json
import math

HERE = Path(__file__).resolve().parent
G = HERE.parent
NATIVE = '953242f473f836d0c4317a01a767f96fe3c44e7bbb351e9f4aaa0c8647fd7e52'
PHASE_MAP = {'compile': 'compile', 'primitives': 'primitives', 'placement': 'placement',
             'routing_bootstrap': 'routing', 'routing_reference_s5': 'routing_reference_v1'}


def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ev(path): return {'path': str(Path(path).resolve()), 'sha256': sha(path)}


def canonical(value):
    if isinstance(value, float):
        if not math.isfinite(value): raise ValueError('Nonfinite resource value')
        return int(value) if value.is_integer() else value
    if isinstance(value, dict): return {str(k): canonical(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)): return [canonical(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(canonical(value), sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def phase_facts(stage, *, source_phase, manifest, profile=None):
    if (stage.get('phase') != source_phase or stage.get('status') != 'completed'
            or stage.get('returncode') != 0 or stage.get('start_epoch') is None
            or stage.get('runtime_module_sha256') != NATIVE):
        raise ValueError('Not a completed, frozen actual reference phase: ' + source_phase)
    timeout, limit = stage.get('timeout_s'), stage.get('address_space_limit_gib')
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError('Actual reference timeout is unknown')
    if type(limit) is not int or limit not in (16, 40, 80):
        raise ValueError('Reference AS outside observed 16/40/80 GiB contracts')
    command = stage.get('execution_command', [])
    if not isinstance(command, list) or command.count('--as=' + str(limit*1024**3)) != 1:
        raise ValueError('Actual command does not confirm reference AS')
    declared_stack = manifest.get('_stack_soft_limit_bytes')
    profile = profile or {}
    actual_stack = profile.get('stack_soft_bytes')
    probe = profile.get('child_inheritance_probe')
    if declared_stack is not None or actual_stack is not None:
        if type(actual_stack) is not int or actual_stack <= 0 or (declared_stack is not None and declared_stack != actual_stack):
            raise ValueError('Explicit stack declaration lacks matching actual receipt')
        if not isinstance(probe, list) or len(probe) != 2 or probe[0] != actual_stack:
            raise ValueError('Explicit stack lacks actual child inheritance evidence')
        if profile.get('stack_hard_bytes') != probe[1]:
            raise ValueError('Explicit stack hard-limit receipt disagrees')
        stack = {'mode': 'explicit_soft_limit', 'soft_bytes': actual_stack, 'hard_bytes': probe[1],
                 'child_inheritance_probe': probe, 'reference_numeric_stack_known': True,
                 'evidence_kind': 'actual_reference_profile_and_child_probe'}
    else:
        if probe is not None:
            raise ValueError('Unexpected stack probe without explicit stack value')
        if any(str(arg).startswith('--stack=') for arg in command):
            raise ValueError('Undocumented stack override in actual execution command')
        stack = {'mode': 'default_unmodified', 'soft_bytes': None, 'hard_bytes': None,
                 'child_inheritance_probe': None, 'reference_numeric_stack_known': False,
                 'evidence_kind': 'reference_no_declared_override_numeric_history_unknown',
                 'G2_actual_inheritance_must_be_measured_before_exec': True}
    # Actual per-stage receipt is the authority; do not compare explanatory
    # timeout_source labels or collapse two routing stages into a shared entry.
    return {'timeout_s': timeout, 'address_space_gib': limit, 'stack': stack,
            'reference_phase': source_phase, 'budget_evidence': 'completed_actual_stage_receipt_and_execution_command'}


def reference_contract(bundle):
    bundle = Path(bundle).resolve()
    if not bundle.is_relative_to(G) or bundle == G:
        raise ValueError('A private G1 reference bundle is required')
    manifest_path = bundle/'input_manifest.json'
    manifest = read(manifest_path)
    phases, evidence = {}, {}
    for phase, source_phase in PHASE_MAP.items():
        stage_path = bundle/(source_phase+'.json')
        profile_path = bundle/'resource_profiles'/(source_phase+'.json')
        profile = read(profile_path) if profile_path.is_file() else None
        phases[phase] = phase_facts(read(stage_path), source_phase=source_phase, manifest=manifest, profile=profile)
        evidence[phase] = {'stage': ev(stage_path), 'resource_profile': ev(profile_path) if profile is not None else None,
                           'missing_optional_profile_not_reconstructed': profile is None}
    binding = bundle/'reference_binding_audit.json'
    if read(binding).get('reference_binding_verified') is not True:
        raise ValueError('Reference binding is not verified')
    physical = {k: {f: v[f] for f in ('timeout_s', 'address_space_gib', 'stack')} for k, v in phases.items()}
    return {'schema': 'g2-reference-resource-contract953-v1', 'required': True,
            'reference_run': str(bundle), 'reference_manifest': ev(manifest_path),
            'resource_policy': 'per-five-phase-actual-reference-receipts953-v1',
            'phase_resources': phases, 'resource_signature': digest(physical),
            'reference_stage_resource_evidence': evidence, 'reference_binding': ev(binding),
            'implementation': ev(__file__), 'full_flow_receipts_verified': True,
            'layout_qualification_inferred': False,
            'historical_numeric_stack_unknown_phases': [k for k, v in phases.items() if not v['stack']['reference_numeric_stack_known']],
            'same_seed_matched_G2_runs_require_equal_measured_stack': True,
            'old_S5_resource_contract_not_rewritten': True}


def augment_request(request, contract):
    if contract.get('schema') != 'g2-reference-resource-contract953-v1' or not contract.get('full_flow_receipts_verified'):
        raise ValueError('Invalid G2 reference contract')
    output = copy.deepcopy(request)
    additions = {'resource_contract': copy.deepcopy(contract), 'resource_policy': contract['resource_policy'],
                 'stage_timeouts': {k: v['timeout_s'] for k, v in contract['phase_resources'].items()},
                 'stage_address_space_gib': {k: v['address_space_gib'] for k, v in contract['phase_resources'].items()}}
    stack_values = {v['stack']['soft_bytes'] for v in contract['phase_resources'].values()}
    if len(stack_values) == 1:
        additions['stack_soft_limit_bytes'] = next(iter(stack_values))
    for key, value in additions.items():
        if key in output and output[key] != value:
            raise ValueError('Conflicting pre-existing request resource: ' + key)
        output[key] = copy.deepcopy(value)
    return output


def verify_request(request):
    contract = reference_contract(request['bundle_path'])
    if request.get('resource_contract') != contract:
        raise ValueError('Stale or missing G2 actual-reference contract')
    expected = augment_request({'bundle_path': request['bundle_path']}, contract)
    for key, value in expected.items():
        if key != 'bundle_path' and request.get(key) != value:
            raise ValueError('G2 per-phase resource mismatch: ' + key)
    return contract
