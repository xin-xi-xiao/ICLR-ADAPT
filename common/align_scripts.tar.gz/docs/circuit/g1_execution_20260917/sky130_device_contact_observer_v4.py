"""Derived observation only: disambiguate SKY130 device contact vs V4.

The official CAP emitter draws CapMIMContact as a Region and ordinary V4 as
a Via; both use GDS70/44. Only exact typed primitive metadata plus selected
hierarchy/GDS provenance may override the existing datatype-only mapping.
No geometry is changed, no checker decision waived, no native task launched.
"""
from pathlib import Path
from collections import Counter
import argparse
import copy
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'src'))
import observer953_parameterized_v1 as observer
from adapt.postlayout.geometry_metrics import compute_geometry_metrics


def load(path):
    return json.loads(Path(path).read_text())


def evidence(path):
    path = Path(path)
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')


def box(element):
    xy = element['xy']
    assert element['type'] == 'boundary' and len(xy) == 10 and xy[:2] == xy[-2:]
    xs, ys = xy[::2], xy[1::2]
    assert len(set(xs)) == len(set(ys)) == 2
    return (min(xs), min(ys), max(xs), max(ys))


def structure_map(gds):
    return {s['strname']: s for lib in gds['bgnlib'] for s in lib['bgnstr']}


def geometry_key(record):
    return record['layer'], tuple(record['rect']), record['net'], record['net_class']


def observe(run, output):
    run, output = run.resolve(), output.resolve()
    if HERE not in output.parents or output.exists():
        raise ValueError('Fresh derived output must be inside private G1 workspace')
    output.mkdir(parents=True)
    is_s5 = (run / 'request.json').exists() and (run / 'result.json').exists()
    manifest = load(run / 'request.json')['pair'] if is_s5 else load(run / 'input_manifest.json')
    historical_observation_path = run / ('result.json' if is_s5 else 'dataset_observation.json')
    if historical_observation_path.exists():
        previous = load(historical_observation_path)
    else:
        previous = observer.observe({**manifest, 'reference_directory': str(run), 'source_directory': str(run)}, True)
        historical_observation_path = output / 'source_observation_derived_readonly.json'
        write(historical_observation_path, previous)
    validation = load(run / 'validation_result.json')
    selected = validation['selected_id']
    prior_geometry_path = run / ('validation/qualification_full_layout_geometry.json' if is_s5 else 'validation_reference/qualification_full_layout_geometry.json')
    prior_geometry = load(prior_geometry_path)
    prior_normalization = run / 'sky130_datatype_observation953/normalization_receipt.json'
    normalization = load(prior_normalization)
    raw_path, normal_path = Path(normalization['source']), Path(normalization['destination'])
    assert evidence(raw_path)['sha256'] == normalization['source_sha256']
    assert evidence(normal_path)['sha256'] == normalization['destination_sha256']
    raw = load(raw_path)
    corrected = load(normal_path)
    raw_structures, new_structures = structure_map(raw), structure_map(corrected)
    source_layers_path = run / 'pdk/layers.json'
    source_layers = {x['Layer']: x for x in load(source_layers_path)['Abstraction']}
    normalized_layers_path = run / 'sky130_datatype_observation953/layers.json'
    normalized_layers = load(normalized_layers_path)
    uid = {x['Layer']: x['GdsLayerNo'] for x in normalized_layers['Abstraction']}
    contact, via = source_layers['CapMIMContact'], source_layers['V4']
    assert contact['GdsLayerNo'] == via['GdsLayerNo']
    assert contact['GdsDatatype']['Draw'] == via['GdsDatatype']['Draw']
    assert 'Stack' not in contact and via['Stack'] == ['M4', 'M5']
    cap_source_path = run / 'pdk/cap.py'
    cap_source = cap_source_path.read_text()
    assert "Region( 'CapMIMC', 'CapMIMContact'" in cap_source
    assert "Via( 'v4_x', 'V4'" in cap_source
    assert 'self.addRegion( self.CapMIMC, None,' in cap_source
    assert "self.addVia( self.v4_x, 'MINUS'" in cap_source
    library_path = run / 'work/1_topology/__primitives_library__.json'
    cap_templates = {p['name'] for p in load(library_path) if (p.get('generator') or {}).get('name') == 'CAP'}
    registry_path = run / 'work/2_primitives/__primitives__.json'
    registry = load(registry_path)
    caps = {name for name, row in registry.items() if row.get('abstract_template_name') in cap_templates}
    selected_visits = [x for x in prior_geometry['hierarchy_instances'] if x['concrete_template'] in caps]
    selected_structure_names = {x['structure'] for x in selected_visits}
    assert all(x['instance_binding_verified'] for x in selected_visits)
    if not selected_visits and not is_s5:
        raise ValueError('No selected CAP; reference repair is not applicable')
    final_viewer_path = run / 'work/3_pnr' / (selected + '.json')
    final_viewer = load(final_viewer_path)
    viewer_rects = Counter((t['layer'], tuple(t['rect'])) for t in final_viewer['terminals'])
    records = []
    for name in sorted(selected_structure_names):
        visits = [v for v in selected_visits if v['structure'] == name]
        concrete_names = {v['concrete_template'] for v in visits}
        assert len(concrete_names) == 1
        concrete = next(iter(concrete_names))
        primitive_path = run / 'work/2_primitives' / (concrete + '.json')
        primitive_gds_path = run / 'work/2_primitives' / (concrete + '.gds.json')
        primitive = load(primitive_path)
        typed_contact = {tuple(t['rect']) for t in primitive['terminals'] if t['layer'] == 'CapMIMContact'}
        typed_via = {tuple(t['rect']) for t in primitive['terminals'] if t['layer'] == 'V4'}
        assert typed_contact and typed_via and not (typed_contact & typed_via)
        # Stronger than unequal coordinates: actual boxes have no positive-area
        # intersection, so one physical cut cannot be silently retyped twice.
        assert all(min(a[2], b[2]) <= max(a[0], b[0]) or min(a[3], b[3]) <= max(a[1], b[1])
                   for a in typed_contact for b in typed_via)
        primitive_gds = load(primitive_gds_path)
        primitive_cuts = Counter(tuple(e['xy']) for lib in primitive_gds['bgnlib'] for s in lib['bgnstr']
            for e in s['elements'] if e.get('type') == 'boundary' and e.get('layer') == contact['GdsLayerNo']
            and e.get('datatype') == contact['GdsDatatype']['Draw'])
        matched_contacts = set()
        kept_vias = set()
        for index, original in enumerate(raw_structures[name]['elements']):
            if original.get('type') != 'boundary' or original.get('layer') != contact['GdsLayerNo'] or original.get('datatype') != contact['GdsDatatype']['Draw']:
                continue
            rect = box(original)
            assert primitive_cuts[tuple(original['xy'])] > 0, 'Final hierarchy must match actual primitive GDS'
            target = new_structures[name]['elements'][index]
            assert target['xy'] == original['xy'] and target['layer'] == uid['V4']
            if rect in typed_via:
                kept_vias.add(rect)
                continue
            assert rect in typed_contact, 'Ambiguous resource without exact typed proof remains blocked'
            matched_contacts.add(rect)
            target['layer'] = uid['CapMIMContact']
            instances = []
            for visit in visits:
                from fractions import Fraction
                a, b, c, d, x, y = map(Fraction, visit['transform_nm_exact'])
                points = [(a*px+b*py+x, c*px+d*py+y) for px, py in
                    [(rect[0], rect[1]), (rect[0], rect[3]), (rect[2], rect[1]), (rect[2], rect[3])]]
                final_rect = tuple(int(v) for v in (min(p[0] for p in points), min(p[1] for p in points), max(p[0] for p in points), max(p[1] for p in points)))
                assert all(v.denominator == 1 for p in points for v in p)
                matching_old = [r for r in prior_geometry['geometry'] if r['layer'] == 'V4' and tuple(r['rect']) == final_rect and any(p.get('instance_path') == visit['instance_path'] and p.get('structure') == name and p.get('element_index') == index for p in r['provenance'])]
                assert len(matching_old) == 1, 'Selected final hierarchical GDS rectangle and transform witness required'
                instances.append({'instance_path': visit['instance_path'], 'transform_nm_exact': visit['transform_nm_exact'],
                    'final_rect_nm': final_rect, 'actual_final_viewer_typed_match': viewer_rects['CapMIMContact', final_rect] > 0,
                    'selected_final_hierarchical_GDS_rectangle_exact_match': True,
                    'old_serialized_record': matching_old[0]})
            records.append({'structure': name, 'element_index': index, 'concrete': concrete,
                'original_layer_datatype': [original['layer'], original['datatype']],
                'local_rect_nm': rect, 'raw_element': original, 'semantic_type': 'device_contact',
                'original_primitive_type': 'CapMIMContact', 'instance_evidence': instances,
                'primitive_JSON': evidence(primitive_path), 'primitive_GDS': evidence(primitive_gds_path),
                'same_primitive_true_V4_rectangles_preserved': sorted(typed_via)})
        assert matched_contacts == typed_contact and kept_vias == typed_via
    if not records and not is_s5:
        raise ValueError('No selected contact witness; do not claim a repair')
    derived_layers = output / 'observation_layers.json'
    derived_gds = output / raw_path.name
    write(derived_layers, normalized_layers)
    write(derived_gds, corrected)
    spec = importlib.util.spec_from_file_location('_g1_unchanged_owned_serializer_v1', HERE / 'audit/metric_repair/align_hierarchy_serializer_v2.py')
    serializer = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = serializer
    spec.loader.exec_module(serializer)
    geometry = serializer.serialize_hierarchical_final(derived_gds, final_viewer_path, derived_layers,
        workdir=run / 'work', top=manifest['top'])
    original_metals = Counter(geometry_key(r) for r in prior_geometry['geometry'] if r['kind'] == 'metal')
    current_metals = Counter(geometry_key(r) for r in geometry['geometry'] if r['kind'] == 'metal')
    assert current_metals == original_metals, 'No metal ownership or geometry may change'
    removed_rects = {tuple(i['final_rect_nm']) for r in records for i in r['instance_evidence']}
    previous_cuts = Counter(geometry_key(r) for r in prior_geometry['geometry'] if r['kind'] == 'cut' and not (r['layer'] == 'V4' and tuple(r['rect']) in removed_rects))
    current_cuts = Counter(geometry_key(r) for r in geometry['geometry'] if r['kind'] == 'cut')
    assert current_cuts == previous_cuts, 'All true intermetal cut geometry/net ownership must remain exact'
    geometry['device_contact_typed_provenance_sidecar'] = str(output / 'device_contact_provenance.json')
    geometry_path = output / 'qualification_full_layout_geometry.json'
    write(geometry_path, geometry)
    computed = compute_geometry_metrics(geometry, reference_widths_um=geometry['reference_widths_um'])
    write(output / 'geometry_metrics.json', computed)
    if is_s5:
        from sky130_s5_derived_observation_support_v1 import verify_s5
        derived = verify_s5(run, geometry)
    else:
        derived = observer.observe({**manifest, 'reference_directory': str(run), 'source_directory': str(run),
            'geometry_path': str(geometry_path)}, observer.runtime_identity()['matches_S0'])
    assert derived['connectivity_and_DRC'] == previous['connectivity_and_DRC']
    assert derived['validation']['sha256'] == evidence(run / 'validation_result.json')['sha256']
    if not is_s5:
        assert derived['validation'] == previous['validation']
    derived.update(derived_observation=True, postprocess_only=True,
        source_observation=evidence(historical_observation_path),
        source_observation_is_preexisting=(run / ('result.json' if is_s5 else 'dataset_observation.json')).exists(),
        observation_mode='S5_arbitrary_vector' if is_s5 else 'Formal35_reference',
        geometry=evidence(geometry_path),
        observation_action='typed_device_contact_reclassification' if records else 'verified_noop_no_selected_CAP',
        device_contact_provenance=str(output / 'device_contact_provenance.json'),
        high_quality_reward_allowed=derived['C'])
    write(output / 'dataset_observation.json', derived)
    proof = {'schema': 'sky130-device-contact-exact-primitive-observation-v4',
        'observation_mode': 'S5_arbitrary_vector' if is_s5 else 'Formal35_reference',
        'observation_action': 'typed_device_contact_reclassification' if records else 'verified_noop_no_selected_CAP',
        'proof_scope': 'Final viewer omits device-contact layers. Actual final hierarchical GDS, selected instance binding/transform, original primitive GDS and typed primitive JSON provide the evidence; no flattened-viewer ownership is assumed.',
        'run_directory': str(run), 'case_id': manifest['case_id'], 'native_runs_started': 0,
        'postprocessor': evidence(__file__), 'official_source_layers': evidence(source_layers_path),
        'CAP_emitter': evidence(cap_source_path), 'native_CAP_library': evidence(library_path),
        'native_primitive_registry': evidence(registry_path),
        'original_raw_GDS': evidence(raw_path), 'original_final_viewer': evidence(final_viewer_path),
        'prior_normalization': evidence(prior_normalization), 'old_geometry': evidence(prior_geometry_path),
        'original_selected_validation': evidence(run / 'validation_result.json'),
        'derived_geometry': evidence(geometry_path), 'derived_GDS': evidence(derived_gds),
        'contact_type_evidence': {'original_contact_layer': contact, 'true_intermetal_layer': via,
            'consumer_paths': ['cap.py:28 Region CapMIMContact -> cap.py:70 addRegion with net=None',
                               'cap.py:30 Via V4 -> cap.py:67 addVia MINUS',
                               'PDK V4.Stack=[M4,M5]; CapMIMContact has no ordinary-metal Stack'],
            'meaning': 'MiM device electrode contact, not a routing connection between two ordinary metal layers. Classified using exact emitter/primitive/selected-output provenance, not layer name alone.'},
        'reclassified_elements': records, 'reclassified_physical_contact_count': len(removed_rects),
        'same_exact_all_metals': True, 'same_exact_remaining_intermetal_cuts': True,
        'no_net_name_inferred_or_filled': True, 'checker_errors_unchanged': True,
        'old_ownership': prior_geometry['ownership_coverage'], 'new_ownership': geometry['ownership_coverage'],
        'old_GCL': {k: previous[k] for k in ('G', 'C', 'L')},
        'new_GCL': {k: derived[k] for k in ('G', 'C', 'L')},
        'old_diagnostic_metrics4': previous['diagnostic_arithmetic_metrics4'],
        'new_metrics4': derived['metrics4'], 'connectivity_and_DRC': derived['connectivity_and_DRC'],
        'historical_outputs_changed': False,
        'limits': ['Observation/metric-classification repair only; no physical short/open/DRC repaired.',
            'G-only results cannot receive high-quality reward or count as C/L.',
            'Reference-only observations still need two distinct effective full flows to meet pair sampling requirements.']}
    write(output / 'device_contact_provenance.json', proof)
    print(json.dumps({'case_id': manifest['case_id'], 'output': str(output),
        **{k: derived[k] for k in ('G', 'C', 'L', 'metrics4', 'connectivity_and_DRC')},
        'reclassified_device_contacts': len(removed_rects)}))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    observe(args.run, args.out)
