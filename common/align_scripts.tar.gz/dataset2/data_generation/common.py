"""Dataset2 local durable I/O. No ALIGN imports."""
import os,json,hashlib,uuid,datetime
from pathlib import Path
HERE=Path(__file__).resolve().parent
CSV=HERE.parent/'dataset_csv'
CAMPAIGN='dataset2_sobol64_v1'
RUNS=HERE/'runs'/CAMPAIGN
PYTHON=HERE.parents[1]/'ALIGN-public/general/bin/python'
# HERE is <repo>/dataset2/data_generation
PYTHON=HERE.parents[1]/'ALIGN-public/general/bin/python'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def atomic(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 t=p.with_name('.'+p.name+'.'+uuid.uuid4().hex)
 with t.open('x') as f:
  json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def atomic_text(p,s):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name('.'+p.name+'.'+uuid.uuid4().hex)
 with t.open('x') as f:f.write(s);f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def samples():return [json.loads(line) for line in (HERE/'manifest/samples.jsonl').read_text().splitlines() if line.strip()]
def proc_alive(pid,created=None):
 if not isinstance(pid,int) or pid<=0:return False
 import psutil
 try:
  p=psutil.Process(pid)
  return p.status()!=psutil.STATUS_ZOMBIE and (created is None or abs(p.create_time()-created)<.01)
 except psutil.Error:return False
