"""Dataset2 immutable two-block scrambled Sobol registration. No ALIGN imports/runs."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
from scipy.stats import qmc

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
G = ROOT / 'docs/circuit/g1_execution_20260917'
CATALOG = G / 'layout_catalog953_v1/20260918T213554867415Z/INDEX.json'
CONTRACT = ROOT / 'docs/param/adapt_formal_grouped_space_v1.json'
OLD_REQUESTS = G / 'g2_campaign953_v1/campaigns/panel_joint_20260918_v1/requests'
MANIFEST = HERE / 'manifest'
METHOD = 'dataset2-two-scrambled-sobol32-blocks-v1'
GLOBAL_SEED = 20260919
PDKS = ['14nm', '65nm', 'SKY130']
TEMPLATE_FIELDS = ('bundle_path', 'source_input_tree_hash', 'source_pdk_tree_hash',
    'source_baseline_sha256', 'runtime_sha256', 'runtime_manifest_sha256',
    'contract_sha256', 'runner_dependency_sha256', 'driver_dependency_sha256',
    'resource_contract', 'resource_policy', 'stage_timeouts', 'stage_address_space_gib',
    'stack_soft_limit_bytes', 'pair', 'source_artifacts', 'identity_resource_verification',
    'input_version', 'case_id', 'pdk', 'lineage_id', 'source_family', 'split',
    'g1_final_assembly_proof', 'g1_assembly_receipt', 'fixed_input_resource_identity_sha256')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write_immutable(path, value, *, raw=False):
    path = Path(path)
    content = value if raw else json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    if path.exists():
        if path.read_text() != content:
            raise ValueError('Refusing to overwrite a different frozen artifact: ' + str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation: a different registration can never silently replace this file.
    with path.open('x') as out:
        out.write(content)


def design_scramble_seed(lineage_id, global_seed=GLOBAL_SEED):
    payload = [METHOD, global_seed, 'design_specific', lineage_id]
    full = digest(payload)
    return int(full[:8], 16), payload, full


def sobol32(seed):
    # Legacy seed=int API is intentionally pinned to SciPy 1.13.1. Default bits=30 is explicit.
    return qmc.Sobol(d=35, scramble=True, bits=30, seed=seed).random_base2(m=5).tolist()


def discretize(point, dimensions):
    if len(point) != 35 or any(not 0 <= u < 1 for u in point):
        raise ValueError('Expected 35 finite coordinates in [0,1)')
    return [d['allowed_values'][math.floor(u * len(d['allowed_values']))]
            for u, d in zip(point, dimensions)]


def structural_masks(dispatch, dimensions):
    """Prove absence from invariant compiled structure/static native API, not observed hits."""
    empty, unsupported, proof = [False] * 35, [False] * 35, []
    primitive_rows = dispatch['primitive_objects']
    for i, rec in enumerate(dispatch['coordinates']):
        if rec['index_0based'] != i or rec['name'] != dimensions[i]['name']:
            raise ValueError('Compiled dispatch coordinate order mismatch')
        if rec['objects'] or rec['pending'] or rec['object_mask'] is not False:
            continue
        family, group = rec['parameter_id'], rec['group']
        reason = None
        if group == 'DESCENDANT' and family in ('P04', 'P05', 'P07', 'R01', 'R02'):
            if len(dispatch['reachable_modules']) == 1:
                empty[i] = True
                reason = 'Frozen compiled topology has ROOT only; no reachable descendant module.'
        elif family == 'P08':
            rows = [r for r in dispatch['net_objects'] if r['group'] == group]
            if dispatch['roles'] and all(r['exclusion'] == 'supply_component' for r in rows):
                empty[i] = True
                reason = 'Exact compiled net group is empty after explicit fixed supply-component exclusion.'
        elif family in ('G01', 'G02'):
            rows = [r for r in primitive_rows if r.get('group') == group]
            unknown = [r for r in primitive_rows if not r.get('group')]
            if not rows and not unknown:
                empty[i] = True
                reason = 'No compiled MOS primitive belongs to this polarity/element-count group.'
            elif rows and not unknown and all(r.get('capabilities', {}).get(family, {}).get('status') == 'inapplicable_native_consumer' for r in rows):
                unsupported[i] = True
                reason = 'Pinned PDK generator does not consume this parameter for any object in the group.'
        elif family == 'G04':
            polarity = group.split('_')[0]
            rows = [r for r in primitive_rows if r.get('group', '').startswith(polarity + '_')]
            unknown = [r for r in primitive_rows if not r.get('group')]
            if not unknown and all(r.get('capabilities', {}).get('G04', {}).get('status') == 'inapplicable_electrical_structure' for r in rows):
                empty[i] = True
                reason = 'No frozen compiled equal-parameter common-source MOS pair of this polarity.'
        if empty[i] or unsupported[i]:
            proof.append({'index_1based': i + 1, 'name': rec['name'],
                          'kind': 'static_consumer_unsupported' if unsupported[i] else 'structural_empty',
                          'reason': reason, 'excluded_objects': rec['excluded_objects']})
    combined = [a or b for a, b in zip(empty, unsupported)]
    return {'structural_empty_mask': empty, 'static_consumer_unsupported_mask': unsupported,
            'structural_inactive_mask': combined, 'structural_inactive_evidence': proof,
            'policy': 'Only fixed compiled structural absence or pinned native-consumer absence; never freeze reference choice/operation/observer unknown.'}


def build(destination=MANIFEST):
    destination = Path(destination).resolve()
    if not destination.is_relative_to(HERE):
        raise ValueError('Registration writes must stay within Dataset2 data_generation')
    catalog, contract = read(CATALOG), read(CONTRACT)
    dims = contract['dimensions']
    if len(dims) != 35 or contract['reference_vector'] != [d['reference'] for d in dims]:
        raise ValueError('Invalid frozen Formal35 contract')
    rows = catalog['rows']
    cases = {r['case_id']: r['circuit_original'] for r in rows}
    if len(rows) != 120 or len(cases) != 40 or len({c['lineage_id'] for c in cases.values()}) != 40:
        raise ValueError('Expected exactly 40 distinct case IDs and lineages / 120 catalog pairs')
    if {(r['case_id'], r['pdk']) for r in rows} != {(cid, p) for cid in cases for p in PDKS}:
        raise ValueError('Catalog is not the exact 40 x 3 Cartesian product')
    names = [c['circuit_name'] for c in cases.values()]
    if len(set(names)) != 40:
        raise ValueError('Circuit names must be unique for CSV names')
    ordered = sorted(rows, key=lambda r: (r['display_size_rank'], r['case_id'], PDKS.index(r['pdk'])))
    global_block = sobol32(GLOBAL_SEED)
    design_blocks = {}
    lineage_seeds = {}
    for c in sorted(cases.values(), key=lambda c: c['case_id']):
        seed, payload, full = design_scramble_seed(c['lineage_id'])
        if seed == GLOBAL_SEED or seed in lineage_seeds.values():
            raise ValueError('Unexpected uint32 scramble-seed collision: do not silently choose a new seed')
        lineage_seeds[c['lineage_id']] = seed
        design_blocks[c['lineage_id']] = {'scramble_seed': seed, 'seed_payload': payload,
            'seed_sha256': full, 'u35': sobol32(seed)}
    pairs, samples = [], []
    for row in ordered:
        cid, pdk = row['case_id'], row['pdk']
        pair_id = cid + '__' + pdk
        circuit = row['circuit_original']
        prior_path = OLD_REQUESTS / (pair_id + '__joint_01_s1.json')
        old = read(prior_path)
        if old['pair']['case_id'] != cid or old['pair']['pdk'] != pdk or old['lineage_id'] != circuit['lineage_id']:
            raise ValueError('Input-template identity differs from authoritative catalog')
        template = {k: old[k] for k in TEMPLATE_FIELDS}
        template.update(schema='dataset2-input-identity-template-v1',
                        template_role='input_PDK_runtime_budget_only_no_historical_sample_or_admission',
                        template_provenance={'path': str(prior_path), 'sha256': sha(prior_path)})
        template_path = destination / 'input_templates' / (pair_id + '.json')
        write_immutable(template_path, template)
        dispatch_path = Path(row['pair_original']['reference_run']) / 'grouped35_dispatch_receipt.json'
        dispatch = read(dispatch_path)
        masks = structural_masks(dispatch, dims)
        pair = {'pair_id': pair_id, 'case_id': cid, 'circuit': row['circuit_name'],
                'circuit_name': row['circuit_name'], 'pdk': pdk, 'lineage_id': circuit['lineage_id'],
                'source': circuit['source_family'], 'source_type': circuit['source_type'],
                'source_path': circuit['source_path'], 'split': circuit['split'],
                'rank': row['display_size_rank'], 'csv_filename': row['circuit_name'] + '__' + pdk + '.csv',
                'request_template_path': str(template_path), 'request_template_sha256': sha(template_path),
                'source_request': str(prior_path), 'source_request_sha256': sha(prior_path),
                'reference_evidence': {'run_directory': row['pair_original']['reference_run'],
                    'reuse_status': 'not_admitted_requires_full_runtime_input_seed_budget_native_identity'},
                'source_scale': {k: v for k, v in circuit.items() if k.startswith('source_') and isinstance(v, (int, float))},
                'structural_dispatch_evidence': {'path': str(dispatch_path), 'sha256': sha(dispatch_path),
                    'baseline_topology_sha256': dispatch['baseline_topology_sha256'],
                    'baseline_primitive_library_sha256': dispatch['baseline_primitive_library_sha256'],
                    'compile_precedes_PG_binding': {'path': str(G / 'g1_s5_runner953_v2.py'),
                        'sha256': sha(G / 'g1_s5_runner953_v2.py'), 'line_start': 538, 'line_end': 544},
                    'static_consumer_sources': ([{'path': str(G / 'sky130_contract953.py'),
                        'sha256': sha(G / 'sky130_contract953.py'), 'line_start': 6, 'line_end': 13},
                        {'path': str(Path(old['bundle_path']) / 'pdk/gen_param.py'),
                         'sha256': sha(Path(old['bundle_path']) / 'pdk/gen_param.py'),
                         'scope': 'add_primitive enumerates integer factor pairs, no legal_sizes or height-dependent enable branch'}]
                         if pdk == 'SKY130' else [])}, **masks}
        pairs.append(pair)
        design = design_blocks[circuit['lineage_id']]
        for block, points, seed in [('global_shared', global_block, GLOBAL_SEED),
                                    ('design_specific', design['u35'], design['scramble_seed'])]:
            for j, point in enumerate(points):
                index = j + 1 + (32 if block == 'design_specific' else 0)
                raw = discretize(point, dims)
                vector = [d['reference'] if off else v for d, off, v in zip(dims, masks['structural_inactive_mask'], raw)]
                samples.append({'schema': 'dataset2-fixed-slot-v1', 'sample_id': pair_id + '__d2_' + f'{index:03d}',
                    'pair_id': pair_id, 'case_id': cid, 'circuit': row['circuit_name'], 'circuit_name': row['circuit_name'],
                    'pdk': pdk, 'lineage_id': circuit['lineage_id'], 'source': circuit['source_family'],
                    'source_type': circuit['source_type'], 'source_path': circuit['source_path'], 'split': circuit['split'],
                    'sample_index': index, 'sample_index_1based': index, 'block': block, 'block_index': j + 1,
                    'block_index_1based': j + 1, 'global_sampling_seed': GLOBAL_SEED,
                    'sobol_scramble_seed': seed, 'align_seed': 1, 'u35': point, 'normalized35': point,
                    'requested35': raw, 'vector': vector,
                    'structural_inactive_mask': masks['structural_inactive_mask'],
                    'structural_empty_mask': masks['structural_empty_mask'],
                    'static_consumer_unsupported_mask': masks['static_consumer_unsupported_mask'],
                    'requested35_sha256': digest(raw), 'vector_sha256': digest(vector),
                    'request_template_path': str(template_path), 'request_template_sha256': sha(template_path),
                    'pair_evidence_path': str(destination / 'pairs.json'),
                    'requested_count_policy': 'fixed_64_no_replacements_or_outcome_adaptation',
                    'reference_or_historical_result_reuse': False})
    write_immutable(destination / 'contract.json', contract)
    write_immutable(destination / 'pairs.json', pairs)
    write_immutable(destination / 'global_block.json', {'seed': GLOBAL_SEED, 'u35': global_block})
    write_immutable(destination / 'design_blocks.json', design_blocks)
    write_immutable(destination / 'samples.jsonl', ''.join(canonical(s) + '\n' for s in samples), raw=True)
    write_immutable(destination / 'sample_index.json', {s['sample_id']: {
        'record_sha256': digest(s), 'pair_id': s['pair_id'], 'sample_index': s['sample_index']}
        for s in samples})
    plan = {'schema': METHOD, 'dataset': 'Dataset2', 'global_sampling_seed': GLOBAL_SEED,
            'align_seed': 1, 'circuits': 40, 'pairs': 120, 'requested_samples_per_pair': 64,
            'requested_slots': 7680, 'pdks': PDKS,
            'sampling': {'engine': 'scipy.stats.qmc.Sobol', 'd': 35, 'scramble': True, 'bits': 30,
                'call': 'Sobol(d=35,scramble=True,bits=30,seed=int).random_base2(m=5)',
                'composition': 'independent global32 plus lineage-specific32, NOT first64 of one sequence',
                'discretization': 'D_j[floor(u_j * len(D_j))], no interpolation or rounding',
                'design_seed': 'uint32(first 8 hex chars of SHA256(UTF8 canonical JSON [method, global_seed, design_specific, lineage_id]))',
                'canonical_JSON': 'ensure_ascii=False,sort_keys=True,separators=(comma,colon),allow_nan=False',
                'PDK_never_in_seed': True},
            'versions': {'python': platform.python_version(), 'python_executable': sys.executable,
                'numpy': np.__version__, 'scipy': scipy.__version__, 'sampling_script_sha256': sha(__file__)},
            'source_catalog': {'path': str(CATALOG), 'sha256': sha(CATALOG)},
            'formal35_contract': {'path': str(CONTRACT), 'sha256': sha(CONTRACT)},
            'files': {n: {'path': str(destination / n), 'sha256': sha(destination / n)}
                      for n in ('contract.json', 'pairs.json', 'global_block.json', 'design_blocks.json', 'samples.jsonl', 'sample_index.json')},
            'alias_policy': 'No cross-pair or historical joint reuse; only full Dataset2 run identity plus complete receipt can be reused, never counted as independent.',
            'reference_policy': 'Reference metadata separate; no historical reference automatically admitted.',
            'all_slots_frozen_before_native': True, 'history_results_imported': 0,
            'structural_mask_policy': 'Frozen compiled structural absence or static consumer absence only; contextual choice/operation unknown is not permanent inactivity.'}
    write_immutable(destination / 'plan.json', plan)
    result = audit(destination)
    write_immutable(destination / 'sampling_audit.json', result)
    return result


def audit(directory=MANIFEST):
    directory = Path(directory)
    plan = read(directory / 'plan.json')
    for item in plan['files'].values():
        if sha(item['path']) != item['sha256']:
            raise ValueError('Manifest SHA changed: ' + item['path'])
    pairs, contract = read(directory / 'pairs.json'), read(directory / 'contract.json')
    samples = [json.loads(line) for line in (directory / 'samples.jsonl').read_text().splitlines()]
    by_pair, by_case = defaultdict(list), defaultdict(list)
    for sample in samples:
        by_pair[sample['pair_id']].append(sample)
        by_case[sample['case_id']].append(sample)
        if discretize(sample['u35'], contract['dimensions']) != sample['requested35']:
            raise ValueError('Floor discretization mismatch')
        for i, value in enumerate(sample['vector']):
            expected = contract['reference_vector'][i] if sample['structural_inactive_mask'][i] else sample['requested35'][i]
            if value != expected:
                raise ValueError('Structural-mask reference application mismatch')
    if len(samples) != 7680 or len({s['sample_id'] for s in samples}) != 7680 or len(by_pair) != 120:
        raise ValueError('Slot identity count mismatch')
    frequencies, pair_duplicates = [], []
    global_raw = None
    all_design_raw = set()
    for pair in pairs:
        ss = sorted(by_pair[pair['pair_id']], key=lambda s: s['sample_index'])
        if [s['sample_index'] for s in ss] != list(range(1, 65)):
            raise ValueError('Pair has missing/duplicate sample index')
        raw = [s['requested35'] for s in ss]
        if global_raw is None:
            global_raw = raw[:32]
        if raw[:32] != global_raw:
            raise ValueError('Global raw block not aligned')
        all_design_raw.update(digest(v) for v in raw[32:])
        pair_duplicates.append({'pair_id': pair['pair_id'], 'raw_unique': len({digest(v) for v in raw}),
            'structural_vector_unique': len({s['vector_sha256'] for s in ss}),
            'native_effective_unique': None})
        for b, block in [('global_shared', ss[:32]), ('design_specific', ss[32:])]:
            counts = []
            for i, d in enumerate(contract['dimensions']):
                c = Counter(s['requested35'][i] for s in block)
                counts.append({'index_1based': i + 1, 'name': d['name'], 'domain': d['allowed_values'],
                               'counts': [c[v] for v in d['allowed_values']]})
            frequencies.append({'pair_id': pair['pair_id'], 'block': b, 'coordinate_counts': counts})
    for cid, ss in by_case.items():
        arrays = [[(s['u35'], s['requested35'], s['sobol_scramble_seed']) for s in sorted(ss, key=lambda s: s['sample_index']) if s['pdk'] == p] for p in PDKS]
        if not arrays[0] == arrays[1] == arrays[2]:
            raise ValueError('Cross-PDK raw action mismatch: ' + cid)
    write_immutable(directory / 'candidate_frequencies.json', frequencies)
    write_immutable(directory / 'duplicate_audit.json', pair_duplicates)
    return {'schema': 'dataset2-sampling-audit-v1', 'passed': True, 'registered_slots': len(samples),
            'pair_count': len(pairs), 'circuit_lineage_count': len(by_case), 'slots_per_pair': 64,
            'global32_shared_all120': True, 'design32_shared_three_PDKs': True,
            'all64_raw_aligned_across_PDKs': True, 'discrete_floor_exact': True,
            'all_ALIGN_seed1': all(s['align_seed'] == 1 for s in samples),
            'raw_unique_per_pair_min_max': [min(x['raw_unique'] for x in pair_duplicates), max(x['raw_unique'] for x in pair_duplicates)],
            'structural_vector_unique_per_pair_min_max': [min(x['structural_vector_unique'] for x in pair_duplicates), max(x['structural_vector_unique'] for x in pair_duplicates)],
            'unique_raw_vectors_global': len({s['requested35_sha256'] for s in samples}),
            'unique_design_specific_raw_vectors': len(all_design_raw),
            'structural_empty_pair_coordinates': sum(sum(p['structural_empty_mask']) for p in pairs),
            'static_consumer_unsupported_pair_coordinates': sum(sum(p['static_consumer_unsupported_mask']) for p in pairs),
            'structural_inactive_pair_coordinates': sum(sum(p['structural_inactive_mask']) for p in pairs),
            'native_effective_duplicates': 'unknown until complete identity/consumer evidence; raw equality alone never aliases',
            'frequency_file': str(directory / 'candidate_frequencies.json'),
            'duplicate_file': str(directory / 'duplicate_audit.json'),
            'history_results_imported': 0, 'native_runs_started': 0}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['build', 'audit'])
    parser.add_argument('--manifest-dir', type=Path, default=MANIFEST)
    args = parser.parse_args()
    print(json.dumps(build(args.manifest_dir) if args.command == 'build' else audit(args.manifest_dir), indent=2))
