"""Dataset2 isolated full-flow runner; native algorithms and qualification stay frozen.

One CLI process owns one preregistered logical slot / fresh attempt directory.
This module does not dispatch other samples, alias history, choose points, or retry.
"""
from __future__ import annotations

import argparse
import ast
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import types
import uuid

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
G = ROOT / "docs/circuit/g1_execution_20260917"
FROZEN = G / "g2_driver953_v1"
RUNS = HERE / "runs"
CAMPAIGN = "dataset2_sobol64_v1"
PYTHON = ROOT / "ALIGN-public/general/bin/python"
PHASES = ("compile", "primitives", "placement", "routing_bootstrap", "routing_reference_s5")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, dict):
        return {str(k): canonical(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [canonical(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(canonical(value), sort_keys=True,
                         separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def atomic(path, value):
    path = Path(path)
    require(path.resolve().is_relative_to(HERE), "Dataset2 write escaped data_generation")
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name("." + path.name + "." + uuid.uuid4().hex)
    with temp.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temp.replace(path)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_frozen_interfaces():
    """Only the output namespace changes in this process's private interface module."""
    contracts = load("contracts", FROZEN / "contracts.py")
    contracts.OUTPUT_ROOT = RUNS
    driver = load("_dataset2_frozen_g2_driver", FROZEN / "driver.py")
    driver.OUTPUT_ROOT = RUNS
    original_phase_plan = contracts.phase_plan

    def namespace_phase_plan(request, phase):
        plan = original_phase_plan(request, phase)
        original = str(FROZEN / "resource_wrapper.py")
        command = plan["execution_command"]
        require(command.count(original) == 1, "Frozen resource-wrapper CLI no longer uniquely matches")
        command[command.index(original)] = str(HERE / "resource_wrapper_adapter.py")
        return plan

    contracts.phase_plan = namespace_phase_plan
    driver.phase_plan = namespace_phase_plan
    return contracts, driver


def remap_observer_output_guard(source):
    """Change one directory guard, preserving every validation / physical AST node."""
    tree = ast.parse(source)
    replacements = []

    class Guard(ast.NodeTransformer):
        def visit_Compare(self, node):
            if (isinstance(node.left, ast.Name) and node.left.id == "HERE"
                    and len(node.ops) == 1 and isinstance(node.ops[0], ast.NotIn)
                    and len(node.comparators) == 1
                    and isinstance(node.comparators[0], ast.Attribute)
                    and isinstance(node.comparators[0].value, ast.Name)
                    and node.comparators[0].value.id == "output"
                    and node.comparators[0].attr == "parents"):
                replacements.append(node.lineno)
                node.left = ast.copy_location(ast.Name(id="DATASET2_OUTPUT_NAMESPACE", ctx=ast.Load()), node.left)
            return self.generic_visit(node)

    changed = Guard().visit(tree)
    require(len(replacements) == 1, "Frozen SKY observer directory guard no longer uniquely matches")
    ast.fix_missing_locations(changed)
    original = ast.parse(source)
    restored = copy.deepcopy(changed)
    for node in ast.walk(restored):
        if isinstance(node, ast.Name) and node.id == "DATASET2_OUTPUT_NAMESPACE":
            node.id = "HERE"
    require(ast.dump(original) == ast.dump(restored), "Unexpected physical / qualification AST alteration")
    return changed, {"frozen_guard": "HERE not in output.parents", "dataset2_guard":
                    "DATASET2_OUTPUT_NAMESPACE not in output.parents", "source_line": replacements[0],
                    "all_other_AST_nodes_identical": True,
                    "physical_geometry_checker_metrics_and_consumer_code_changed": False}


def typed_observer(run, output):
    contracts, _ = load_frozen_interfaces()
    adapter = load("_dataset2_frozen_typed_adapter", FROZEN / "typed_observer_adapter.py")
    original_load = adapter.load
    observer_path = G / "sky130_device_contact_observer_v4.py"
    proof = None

    def namespace_load(name, path):
        nonlocal proof
        if Path(path).resolve() != observer_path.resolve():
            return original_load(name, path)
        tree, proof = remap_observer_output_guard(observer_path.read_text())
        module = types.ModuleType(name)
        module.__file__ = str(observer_path)
        module.DATASET2_OUTPUT_NAMESPACE = HERE
        sys.modules[name] = module
        atomic(Path(run) / "typed_observer_namespace_adapter.json", {
            **proof, "source": str(observer_path), "source_sha256": sha(observer_path),
            "adapter_sha256": sha(__file__), "output_namespace": str(HERE),
            "source_file_not_modified": True})
        exec(compile(tree, str(observer_path), "exec"), module.__dict__)
        return module

    adapter.load = namespace_load
    adapter.observe(Path(run), Path(output))
    atomic(Path(output) / "dataset2_namespace_adapter_receipt.json", {
        **proof, "source": str(observer_path), "source_sha256": sha(observer_path),
        "adapter_sha256": sha(__file__), "read_only_source": True,
        "output_namespace": str(HERE)})


def make_request(sample, out, contract):
    contracts, driver = load_frozen_interfaces()
    template_path = Path(sample["request_template_path"]).resolve()
    require(template_path.is_relative_to(HERE / "manifest"), "Template must be frozen inside Dataset2 manifest")
    expected_hash = sample.get("request_template_sha256") or sample.get("input_template_sha256")
    if expected_hash:
        require(sha(template_path) == expected_hash, "Frozen input template changed")
    request = copy.deepcopy(read(template_path))
    for field in ("registration_receipt", "execution_release", "execution_release_token",
                  "matched_block_id", "alias_of", "release_receipt"):
        request.pop(field, None)
    pair = request["pair"]
    require(sample.get("align_seed") == 1, "All Dataset2 native runs must retain seed 1")
    require(pair["case_id"] == sample["case_id"] and pair["pdk"] == sample["pdk"], "Template pair differs from slot")
    require(sample["sample_id"] == out.parent.name, "Output path does not identify registered slot")
    require(out.is_relative_to(RUNS / CAMPAIGN), "Attempt must be under Dataset2 runs/campaign")
    require(out.name.startswith("attempt_") and out.name[8:].isdigit(), "Explicit attempt_NNN required")
    require(int(out.name[8:]) < contract["max_execution_attempts_per_logical_sample"], "Infrastructure retry cap exceeded")
    vector = sample.get("vector", sample.get("executed35"))
    requested = sample["requested35"]
    inactive = sample["structural_inactive_mask"]
    require(len(vector) == len(requested) == len(inactive) == 35, "35-dimensional vectors/mask required")
    formal = read(ROOT / "docs/param/adapt_formal_grouped_space_v1.json")
    for i, (raw, executed, is_inactive, dim) in enumerate(zip(requested, vector, inactive, formal["dimensions"])):
        require(type(is_inactive) is bool, "Structural inactivity must be proven Boolean")
        require(raw in dim["allowed_values"] and executed in dim["allowed_values"], "Value outside frozen candidate list")
        require(executed == (formal["reference_vector"][i] if is_inactive else raw),
                "Only structural inactive values may be reset to reference")
    request.update(schema=contracts.SCHEMA, dataset_version=contract.get("dataset_version", "Dataset2-sobol64-v1"), campaign_id=CAMPAIGN,
                   logical_sample_id=sample["sample_id"], execution_attempt_id=out.name,
                   config_id=sample["sample_id"], vector=list(vector), output_directory=str(out),
                   align_seed=1, sampling_seed=sample["global_sampling_seed"],
                   plan_only=False, execution_admitted=True, observation_protocol="frozen_GCL_plus_SKY_typed_v4",
                   execution_contract_sha256=sha(HERE / "execution_contract.json"),
                   dataset2_sample_sha256=digest(sample), dataset2_requested35=list(requested),
                   dataset2_structural_inactive_mask=inactive)
    contracts.validate_request(request)
    return request, contracts, driver


def verify_sample(sample, contract):
    """JSONL membership is content-addressed; no result-dependent sampling rewrite."""
    manifest_path = Path(contract["manifest_path"]).resolve()
    require(manifest_path.is_relative_to(HERE / "manifest"), "Manifest namespace mismatch")
    require(sha(manifest_path) == contract["manifest_sha256"], "Dataset2 manifest changed")
    manifest = read(manifest_path)
    samples_path = Path(manifest.get("samples_path", HERE / "manifest/samples.jsonl"))
    samples_sha = manifest.get("samples_sha256") or manifest.get("samples_jsonl_sha256")
    if samples_sha is None:
        files = manifest.get("files", {})
        if isinstance(files, dict):
            item = files.get("samples.jsonl", {})
            samples_sha = item.get("sha256") if isinstance(item, dict) else item
            if isinstance(item, dict) and item.get("path"):
                samples_path = Path(item["path"])
    require(samples_sha and sha(samples_path) == samples_sha, "Sampling JSONL absent from frozen identity")
    matches = []
    with samples_path.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row.get("sample_id") == sample["sample_id"]:
                matches.append(row)
    require(len(matches) == 1 and digest(matches[0]) == digest(sample), "Sample changed or not uniquely preregistered")
    return {"manifest_path": str(manifest_path), "manifest_sha256": sha(manifest_path),
            "samples_jsonl_sha256": samples_sha, "sample_sha256": digest(sample)}


def drc_summary(final, out):
    """Publish DRC counts only after actual selected-hierarchy checking is evidenced."""
    counts = final.get("connectivity_and_DRC")
    gate = (final.get("gates") or {}).get("checker_selected_hierarchy_complete") is True
    report = {"drc_checked": gate, "drc_total": None, "per_rule_DRC": None, "per_layer_DRC": None,
              "drc_scope": "selected routed hierarchy / frozen ALIGN checker; not foundry signoff"}
    if not gate or not isinstance(counts, dict) or type(counts.get("DRC")) is not int:
        return report
    report["drc_total"] = counts["DRC"]
    path = Path(out) / "validation_result.json"
    if not path.is_file():
        return report
    import collections
    counter = collections.Counter()
    layer_counter = collections.Counter()
    for module in read(path).get("checks", {}).get("selected_module_checks", []):
        for diagnostic in module.get("diagnostics", []):
            if diagnostic.get("classification") != "drc_error":
                continue
            raw = diagnostic.get("raw", "")
            # Exact-union errors contain an explicit frozen-checker rule code.
            # ast.literal_eval parses evidence, never executable source.
            rule, layer = "unparsed_drc_error", "unknown_layer"
            if raw.startswith("DRC ERROR EXACT_UNION "):
                try:
                    details = ast.literal_eval(raw[len("DRC ERROR EXACT_UNION "):])
                    if isinstance(details, dict):
                        rule = str(details.get("code", rule))
                        layer = str(details.get("layer", layer))
                except (SyntaxError, ValueError):
                    pass
            counter[rule] += 1
            layer_counter[layer] += 1
    if sum(counter.values()) == report["drc_total"]:
        report["per_rule_DRC"] = dict(sorted(counter.items()))
        report["per_layer_DRC"] = dict(sorted(layer_counter.items()))
    return report


def native_exec_evidence(stages, out):
    """A launcher request alone does not count as an actual native attempt."""
    rows = {}
    for phase, record in stages.items():
        path = Path(out) / "resource_profiles" / (phase + ".json")
        memory = record.get("memory") or {}
        sampled = memory.get("native_sample_count", 0) > 0
        profile = read(path) if path.is_file() else None
        prepared = bool(profile and profile.get("exec_failure") is None
                        and profile.get("prepared_native_exec_epoch") is not None
                        and profile.get("align_seed") == 1)
        rows[phase] = {"native_process_sampled": sampled,
                       "same_process_exec_profile_present": prepared,
                       "actual_native_attempt": sampled or prepared,
                       "exec_profile_path": str(path) if path.exists() else None,
                       "evidence_limit": "Prepared same-process exec is not native completion; stage receipts determine completion"}
    return rows


def run_observer(request, contract, resources, contracts, driver):
    out = Path(request["output_directory"])
    observer_cwd = out / "typed_observer_cwd"
    observer_cwd.mkdir()
    command = [str(PYTHON), "-B", str(Path(__file__).resolve()), "--observe", str(out),
               "--observer-output", str(out / "typed_observation")]
    receipt = {"schema": "dataset2-observer-admission-v1", "command": command,
               "status": "waiting", "start_epoch": None, "returncode": None}
    atomic(out / "typed_observer_admission.json", receipt)
    started = time.monotonic()
    try:
        with resources.admit_observer(request=request, execution_contract=contract) as (fds, metadata):
            receipt.update(status="running", start_epoch=time.time(), admission=metadata,
                           admission_wait_s=time.monotonic()-started)
            atomic(out / "typed_observer_admission.json", receipt)
            with (out / "typed_observer.stdout.log").open("x") as fo, (out / "typed_observer.stderr.log").open("x") as fe:
                process = subprocess.Popen(command, cwd=observer_cwd,
                    env=contracts.seed_environment(request, os.environ), stdout=fo, stderr=fe,
                    pass_fds=tuple(fds), start_new_session=True)
                receipt["pid"] = process.pid
                atomic(out / "typed_observer_admission.json", receipt)
                receipt["returncode"] = process.wait()
            require(receipt["returncode"] == 0, "Typed observer returned " + str(receipt["returncode"]))
            receipt["status"] = "completed"
            return read(out / "typed_observation/dataset_observation.json")
    except Exception as exc:
        receipt.update(status="unknown", error_type=type(exc).__name__, error=str(exc))
        raise
    finally:
        receipt.update(finished_epoch=time.time(), duration_s=time.monotonic()-started)
        atomic(out / "typed_observer_admission.json", receipt)


def execute(sample_path, attempt_dir):
    sample_path, out = Path(sample_path).resolve(), Path(attempt_dir).resolve()
    require(out.is_relative_to(RUNS / CAMPAIGN), "Attempt outside Dataset2 campaign")
    sample = read(sample_path)
    prior = out / "receipt.json"
    if prior.exists():
        result = read(prior)
        require(result["sample_sha256"] == digest(sample) and result["terminal"] is True,
                "Existing receipt differs; forbidden overwrite")
        require(result.get("runner_sha256") == sha(__file__) and result.get("execution_contract_sha256") == sha(HERE / "execution_contract.json"),
                "Existing receipt belongs to a different runner / execution contract; no mixing")
        return result
    require(not out.exists(), "Partial attempt already exists; reconcile process/claim and use next finite attempt")
    contract = read(HERE / "execution_contract.json")
    require(contract.get("schema") == "dataset2-execution-contract-v1", "Dataset2 execution contract required")
    require(contract.get("runner_sha256") == sha(__file__), "Dataset2 runner version changed")
    resources_path = HERE / "resources.py"
    require(contract.get("resource_module_sha256") == sha(resources_path), "Dataset2 resource policy changed")
    require(contract.get("resource_wrapper_adapter_sha256") == sha(HERE / "resource_wrapper_adapter.py"),
            "Dataset2 resource wrapper adapter version changed")
    identity = verify_sample(sample, contract)
    os.environ.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                      NUMEXPR_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1", BLIS_NUM_THREADS="1",
                      OMP_DYNAMIC="FALSE", PYTHONDONTWRITEBYTECODE="1")
    started = time.time()
    original_cwd = Path.cwd()
    attempt = frozen = None
    out.parent.mkdir(parents=True, exist_ok=True)
    import_cwd = out.parent / ("import_" + out.name)
    import_cwd.mkdir(exist_ok=True)
    os.chdir(import_cwd)
    final = None
    error = None
    native_started = False
    try:
        request, contracts, driver = make_request(sample, out, contract)
        driver.verify_g1_final(request)
        driver.verify_inputs(request)
        require(os.environ.get("PYTHONHASHSEED") == "1", "Python interpreter must start with seed 1")
        resources = load("_dataset2_resources", resources_path)
        attempt, frozen = driver.make_attempt(request, resources.admit, contract, sha(HERE / "execution_contract.json"))
        # The final serializer/checker also owns a unified resource token; no hidden two-observer queue.
        original_validator = attempt.validator

        def admitted_validator(*args, **kwargs):
            with resources.admit_observer(request=request, execution_contract=contract):
                return original_validator(*args, **kwargs)

        attempt.validator = admitted_validator
        try:
            attempt.run()
        except frozen.StageFailure as exc:
            attempt.result.update(status="failed", G=False, C=False, L=False, metrics4=None,
                failure_stage=exc.stage, failure_reason=exc.reason,
                failure_class="timeout" if exc.reason.startswith("timeout") else "native_or_binding_failure")
        except Exception as exc:
            error = exc
            attempt.result.update(status="failed", G=None, C=None, L=None, metrics4=None,
                failure_stage=attempt.current, failure_reason=str(exc),
                failure_class="infrastructure_or_interface", traceback=traceback.format_exc())
        raw = attempt.result
        raw.update(wall_time_s=time.time()-attempt.started,
                   stages={p: {k: row.get(k) for k in ("status", "returncode", "duration_s", "runtime_module_sha256", "memory")}
                           for p, row in attempt.stages.items()})
        require(attempt.created_output, "Frozen runner failed before creating output")
        atomic(out / "result.json", raw)
        raw_hash = sha(out / "result.json")
        observation_error = None
        derived = None
        if sample["pdk"] == "SKY130" and raw.get("status") in ("G_complete", "incomplete"):
            try:
                derived = run_observer(request, contract, resources, contracts, driver)
            except Exception as exc:
                observation_error = {"status": "typed_observation_unresolved", "error_type": type(exc).__name__, "error": str(exc)}
        require(sha(out / "result.json") == raw_hash, "Observer changed native raw result")
        final = driver.final_row(request, raw, derived)
        final.update(raw_result_sha256=raw_hash, observation_error=observation_error,
                     failure_reason=raw.get("failure_reason"), traceback=raw.get("traceback"))
        if observation_error:
            final.update(G=None, C=None, L=None, metrics4=None, geometry_training_eligible=False,
                         high_quality_reward_eligible=False, observation_source="unresolved_typed_observer")
        atomic(out / "final_observation.json", final)
        native_started = any(row["actual_native_attempt"] for row in native_exec_evidence(attempt.stages, out).values())
    except Exception as exc:
        error = exc
        if not out.exists():
            out.mkdir(parents=True)
        final = {"G": None, "C": None, "L": None, "metrics4": None, "status": "unknown",
                 "failure_stage": attempt.current if attempt else "identity",
                 "failure_class": "infrastructure_or_interface", "failure_reason": str(exc),
                 "traceback": traceback.format_exc(), "stage_status": attempt.stages if attempt else {},
                 "connectivity_and_DRC": None, "flow_complete": False, "geometry_complete": None,
                 "binding_verified": None, "geometry_training_eligible": False, "high_quality_reward_eligible": False}
        atomic(out / "final_observation.json", final)
    finally:
        os.chdir(original_cwd)
    status = ("completed" if final.get("G") is True else
              "timeout" if final.get("failure_class") == "timeout" else
              "failed" if final.get("status") == "failed" and final.get("failure_class") == "native_or_binding_failure" else "unknown")
    stages = attempt.stages if attempt else {}
    exec_evidence = native_exec_evidence(stages, out)
    native_started = any(row["actual_native_attempt"] for row in exec_evidence.values())
    retryable = isinstance(error, OSError) and error.errno in (errno.EIO, errno.ESTALE, errno.ENOSPC, errno.EMFILE, errno.ENFILE, errno.ENOMEM)
    receipt = {"schema": "dataset2-sample-receipt-v1", "sample_id": sample["sample_id"],
        "sample_sha256": digest(sample), "pair_id": sample["pair_id"], "case_id": sample["case_id"],
        "circuit": sample.get("circuit", sample.get("circuit_name")), "pdk": sample["pdk"],
        "lineage_id": sample["lineage_id"], "source": sample.get("source"),
        "attempt_id": out.name, "terminal": True, "status": status,
        "native_status": final.get("status"), "native_started": native_started,
        "native_phase_launch_count": sum(bool(v["actual_native_attempt"]) for v in exec_evidence.values()),
        "launcher_phase_count": sum(bool(v.get("native_launch_requested")) for v in stages.values()),
        "native_exec_evidence": exec_evidence,
        "actual": native_started, "alias": False, "alias_source": None,
        "infra_retryable": retryable, "started_epoch": started, "finished_epoch": time.time(),
        "elapsed_s": time.time()-started, "peak_rss_kib": final.get("sampled_native_peak_rss_kib"),
        "requested35": sample["requested35"], "executed35": sample["vector"],
        "normalized35": sample.get("normalized35", sample.get("u35")),
        "structural_inactive_mask": sample["structural_inactive_mask"],
        "G": final.get("G"), "C": final.get("C"), "L": final.get("L"), "metrics4": final.get("metrics4"),
        "masks35": final.get("masks35"), "failure_stage": final.get("failure_stage"),
        "failure_class": final.get("failure_class"), "failure_reason": final.get("failure_reason"),
        "observation_error": final.get("observation_error"),
        "flow_complete": final.get("flow_complete"), "geometry_complete": final.get("geometry_complete"),
        "binding_verified": final.get("binding_verified"), "connectivity_and_DRC": final.get("connectivity_and_DRC"),
        "geometry_training_eligible": final.get("geometry_training_eligible", False),
        "high_quality_reward_eligible": final.get("high_quality_reward_eligible", False),
        "execution_identity_sha256": final.get("execution_identity_sha256"),
        "runtime_hash": final.get("runtime_hash"), "adapted_input_hash": final.get("adapted_input_hash"),
        "original_pdk_source_hash": final.get("original_pdk_source_hash"),
        "stage_status": final.get("stage_status"),
        "effective_configuration": final.get("effective_configuration"),
        "final_observation_path": str(out / "final_observation.json"),
        "final_observation_sha256": sha(out / "final_observation.json"), "attempt_directory": str(out),
        "binding_path": str(out / "binding.json") if (out / "binding.json").exists() else None,
        "runtime_mask_path": str(out / "actual35_masks.json") if (out / "actual35_masks.json").exists() else None,
        "validation_path": str(out / "validation_result.json") if (out / "validation_result.json").exists() else None,
        "registration_identity": identity, "runner_sha256": sha(__file__),
        "resource_wrapper_adapter_sha256": sha(HERE / "resource_wrapper_adapter.py"),
        "execution_contract_sha256": sha(HERE / "execution_contract.json"),
        **drc_summary(final, out)}
    if status == "unknown" and not receipt["failure_stage"]:
        receipt["failure_stage"] = "binding_consumer_audit" if final.get("binding_verified") is False else "observation_or_qualification"
    atomic(out / "receipt.json", receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sample", type=Path)
    parser.add_argument("--attempt-dir", type=Path)
    parser.add_argument("--observe", type=Path)
    parser.add_argument("--observer-output", type=Path)
    args = parser.parse_args()
    if os.environ.get("PYTHONHASHSEED") != "1":
        env = dict(os.environ, PYTHONHASHSEED="1", PYTHONDONTWRITEBYTECODE="1")
        os.execvpe(sys.executable, [sys.executable, "-B", str(Path(__file__).resolve()), *sys.argv[1:]], env)
    if args.observe:
        require(args.observer_output is not None, "Observer output required")
        typed_observer(args.observe, args.observer_output)
        return 0
    require(args.sample is not None and args.attempt_dir is not None, "--sample and --attempt-dir required")
    result = execute(args.sample, args.attempt_dir)
    print(json.dumps({k: result.get(k) for k in ("sample_id", "attempt_id", "status", "G", "C", "L", "failure_stage")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
