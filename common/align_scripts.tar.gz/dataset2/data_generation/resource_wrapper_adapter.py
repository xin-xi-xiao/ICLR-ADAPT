"""Dataset2 path-only adapter for the unchanged frozen native resource wrapper.

This runs in the resource-wrapper subprocess, where the runner's module globals
are not inherited. Only OUTPUT_ROOT changes; exact AS/stack/seed/command checks
and same-process os.execvpe remain the frozen implementation.
"""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
FROZEN = ROOT / "docs/circuit/g1_execution_20260917/g2_driver953_v1"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    contracts = load("contracts", FROZEN / "contracts.py")
    contracts.OUTPUT_ROOT = HERE / "runs"
    wrapper = load("_dataset2_frozen_resource_wrapper", FROZEN / "resource_wrapper.py")
    return wrapper.main()


if __name__ == "__main__":
    raise SystemExit(main())
