"""Dataset2-only resource admission. No ALIGN imports, native policy mutation, or killing.

snapshot(previous=None) reads Linux host counters. decide(...) is pure and is used
by the single campaign scheduler. admit/admit_observer are inherited-fd leases
for phase launchers. Native/observer/validation share the same 24 slots, without
stage-specific caps. Run in the real host PID namespace, not a sandbox PID view.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import argparse
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import time

HERE = Path(__file__).resolve().parent
GIB = 1024 ** 3
THREAD_ENV = {name: '1' for name in (
    'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
    'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'BLIS_NUM_THREADS')}
THREAD_ENV.update({'OMP_DYNAMIC': 'FALSE', 'PYTHONDONTWRITEBYTECODE': '1'})
DEFAULT_POLICY = {
    'max_workers': 24, 'target_workers': 24, 'minimum_busy_target': 20,
    'memory_floor_gib': 16.0, 'disk_floor_gib': 100.0,
    'memory_psi_some_avg10_limit': 10.0, 'memory_psi_full_avg10_limit': 2.0,
    'sustained_swap_mib_s_limit': 4.0, 'sustained_swap_intervals': 2,
    'phase_peak_gib': {'compile': 1.0, 'primitive': 2.0, 'placement': 2.0,
                       'routing': 4.0, 'observer': 4.0, 'validation': 4.0},
    'no_stage_specific_caps': True,
}


def utc(): return datetime.now(timezone.utc).isoformat()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f'.{os.getpid()}.{time.time_ns()}.tmp')
    with temp.open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def _integer(path, default=None):
    try: return int(Path(path).read_text().strip())
    except (OSError, ValueError): return default


def _psi(kind):
    try:
        return {line.split()[0]: {k: float(v) for k, v in
                (item.split('=') for item in line.split()[1:])}
                for line in Path('/proc/pressure', kind).read_text().splitlines()}
    except (OSError, ValueError): return None


def process(pid):
    p = Path('/proc', str(pid))
    raw = (p / 'stat').read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    status = {}
    for line in (p / 'status').read_text().splitlines():
        if ':' in line: status[line.split(':')[0]] = line.split(':', 1)[1].strip()
    argv = [x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x]
    return {'pid': int(pid), 'ppid': int(fields[1]), 'state': fields[0],
            'start_ticks': int(fields[19]), 'cpu_ticks': int(fields[11])+int(fields[12]),
            'rss_bytes': int(status.get('VmRSS', '0 kB').split()[0])*1024,
            'hwm_bytes': int(status.get('VmHWM', '0 kB').split()[0])*1024,
            'threads': int(status.get('Threads', '0')), 'argv': argv}


def _classify(argv):
    # Inspect actual Python program, not strings embedded in `bash -c ...`.
    scripts = [Path(a).name for a in argv[1:6] if a.endswith('.py')]
    if 'schematic2layout.py' in scripts:
        return ('routing' if any(x.endswith(':route') for x in argv) else
                'placement' if any(x.endswith(':place') for x in argv) else
                'primitive' if '2_primitives' in argv else 'compile')
    if any('observer' in s or s.startswith('observe_') for s in scripts): return 'observer'
    if any(s == 'run_sample.py' for s in scripts):
        return 'observer' if '--observe' in argv else 'sample_worker'
    return None


def _temperatures():
    rows = []
    for p in sorted(Path('/sys/class/hwmon').glob('hwmon*/temp*_input')):
        val = _integer(p)
        if val is None: continue
        prefix = p.name[:-6]
        try: chip = (p.parent/'name').read_text().strip()
        except OSError: chip = None
        try: label = (p.parent/(prefix+'_label')).read_text().strip()
        except OSError: label = None
        critical = _integer(p.parent/(prefix+'_crit'))
        is_cpu = chip in ('coretemp', 'k10temp', 'zenpower', 'cpu_thermal')
        rows.append({'path': str(p), 'chip': chip, 'label': label,
                     'celsius': val/1000.0, 'critical_celsius': critical/1000 if critical else None,
                     'cpu_sensor': is_cpu})
    throttles = {str(p): v for p in Path('/sys/devices/system/cpu').glob(
        'cpu*/thermal_throttle/*_throttle_count') if (v := _integer(p)) is not None}
    return rows, throttles


def snapshot(previous=None, root=HERE, *, include_processes=True):
    """No sleeping or mutation. Rates require a prior snapshot from same host boot."""
    now = time.monotonic()
    mem = {line.split(':')[0]: int(line.split()[1])*1024
           for line in Path('/proc/meminfo').read_text().splitlines() if ':' in line}
    vm = {line.split()[0]: int(line.split()[1]) for line in
          Path('/proc/vmstat').read_text().splitlines() if line.startswith(('pswpin ', 'pswpout '))}
    cpu = [int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
    sensors, throttle = _temperatures()
    rows = []
    if include_processes:
        for p in Path('/proc').glob('[0-9]*/stat'):
            try:
                row = process(p.parent.name)
                if row['state'] == 'Z' or not row['argv']: continue
                row['phase_class'] = _classify(row['argv'])
                if row['phase_class'] or any('dataset2/data_generation' in x for x in row['argv']): rows.append(row)
            except (OSError, ValueError, IndexError): pass
    disk = shutil.disk_usage(root)
    pid1 = None
    try: pid1 = Path('/proc/1/comm').read_text().strip()
    except OSError: pass
    boot_id = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    result = {'schema': 'dataset2-resource-snapshot-v1', 'utc': utc(), 'monotonic_s': now,
              'boot_id': boot_id, 'pid_namespace_inode': os.stat('/proc/self/ns/pid').st_ino,
              'pid1_comm': pid1, 'host_pid_visibility': pid1 in ('systemd', 'init'),
              'cpu_count': os.cpu_count(), 'cpu_affinity_count': len(os.sched_getaffinity(0)),
              'load_average': list(os.getloadavg()), 'cpu_counters': cpu,
              'cpu_busy_pct': None, 'memory_total_gib': mem['MemTotal']/GIB,
              'memory_available_gib': mem['MemAvailable']/GIB,
              'swap_used_gib': (mem['SwapTotal']-mem['SwapFree'])/GIB,
              'swap_counters_pages': vm, 'swap_mib_s': None, 'swap_pressure_intervals': 0,
              'memory_psi': _psi('memory'), 'cpu_psi': _psi('cpu'), 'io_psi': _psi('io'),
              'disk_free_gib': disk.free/GIB, 'disk_total_gib': disk.total/GIB,
              'temperature_sensors': sensors, 'temperature_state': 'known' if sensors else 'unknown',
              'cpu_max_celsius': max((r['celsius'] for r in sensors if r['cpu_sensor']), default=None),
              'thermal_throttle_counters': throttle, 'throttle_delta_max': None,
              'serious_thermal_pressure': False,
              'processes': rows, 'native_process_count': sum(r['phase_class'] in ('compile','primitive','placement','routing') for r in rows),
              'observer_process_count': sum(r['phase_class']=='observer' for r in rows),
              'sample_worker_process_count': sum(r['phase_class']=='sample_worker' for r in rows),
              'known_process_rss_gib': sum(r['rss_bytes'] for r in rows)/GIB,
              'multithreaded_execution_processes': [r['pid'] for r in rows if r['phase_class'] not in (None,'sample_worker') and r['threads']>1]}
    if previous and previous.get('boot_id') == boot_id and now > previous.get('monotonic_s', now):
        dt = now-previous['monotonic_s']
        if dt >= 0.5:
            swap_delta = sum(max(0, vm[k]-previous.get('swap_counters_pages', {}).get(k,vm[k])) for k in vm)
            result['swap_mib_s'] = swap_delta*os.sysconf('SC_PAGE_SIZE')/1048576/dt
            result['swap_pressure_intervals'] = (previous.get('swap_pressure_intervals',0)+1 if result['swap_mib_s']>DEFAULT_POLICY['sustained_swap_mib_s_limit'] else 0)
            old = previous.get('cpu_counters', cpu)
            total_delta = sum(cpu)-sum(old)
            idle_delta = (cpu[3]+cpu[4])-(old[3]+old[4])
            if total_delta>0: result['cpu_busy_pct']=100*(1-idle_delta/total_delta)
            deltas=[max(0,v-previous.get('thermal_throttle_counters',{}).get(k,v)) for k,v in throttle.items()]
            result['throttle_delta_max']=max(deltas,default=None)
    # Historical nonzero throttle counters and warm CPUs alone do not halt work.
    hot = any(r['cpu_sensor'] and r['critical_celsius'] is not None and
              r['celsius'] >= r['critical_celsius']-1 for r in sensors)
    extreme = any(r['cpu_sensor'] and r['critical_celsius'] is not None and
                  r['celsius'] >= r['critical_celsius']+3 for r in sensors)
    result['serious_thermal_pressure'] = bool(extreme or (hot and (result['throttle_delta_max'] or 0)>0))
    return result


def decide(state, estimated_peak_gib, running_count, max_workers=24, *,
           reserved_growth_gib=0.0, policy=None):
    """Pure resource decision, no arbitrary CPU utilization or stage count caps.

`reserved_growth_gib` is *future additional* memory above resident RSS already
counted by MemAvailable, not the entire sum of running peak estimates again.
"""
    pol = {**DEFAULT_POLICY, **(policy or {})}
    if not 1 <= int(max_workers) <= 24: raise ValueError('Dataset2 ceiling must be between 1 and 24')
    if not math.isfinite(estimated_peak_gib) or estimated_peak_gib < 0: raise ValueError('Invalid peak estimate')
    if not math.isfinite(reserved_growth_gib) or reserved_growth_gib < 0: raise ValueError('Invalid growth estimate')
    reasons = []
    if not state.get('host_pid_visibility'): reasons.append('host_process_visibility_unknown')
    if running_count >= max_workers: reasons.append('unified_worker_ceiling')
    required = pol['memory_floor_gib']+reserved_growth_gib+estimated_peak_gib
    if state.get('memory_available_gib', -1)<required: reasons.append('memory_growth_reservation')
    psi = state.get('memory_psi')
    if psi is None: reasons.append('memory_pressure_unknown')
    else:
        if psi.get('some',{}).get('avg10',0)>pol['memory_psi_some_avg10_limit']: reasons.append('memory_some_pressure')
        if psi.get('full',{}).get('avg10',0)>pol['memory_psi_full_avg10_limit']: reasons.append('memory_full_pressure')
    if state.get('swap_pressure_intervals',0)>=pol['sustained_swap_intervals']: reasons.append('sustained_swap_activity')
    if state.get('disk_free_gib',-1)<pol['disk_floor_gib']: reasons.append('disk_reserve')
    if state.get('serious_thermal_pressure'): reasons.append('serious_thermal_throttling')
    return {'admit': not reasons, 'wait_reasons': reasons, 'running_count': running_count,
            'max_workers': max_workers, 'estimated_peak_gib': estimated_peak_gib,
            'reserved_growth_gib': reserved_growth_gib, 'required_available_gib': required,
            'memory_available_gib': state.get('memory_available_gib'),
            'stage_specific_cap': None, 'normal_running_processes_killed': False}


def phase_class(phase):
    if phase in ('typed_observer','observer'): return 'observer'
    if phase.startswith('routing'): return 'routing'
    if phase in ('primitive','primitives'): return 'primitive'
    if phase in ('compile','placement','validation'): return phase
    raise ValueError('Unrecognized phase '+phase)


def peak_estimate(request, phase, policy=None):
    """Estimate only for admission; never changes the execution AS/time budget."""
    policy={**DEFAULT_POLICY, **(policy or {})}
    kind=phase_class(phase)
    estimates=request.get('estimated_phase_peak_gib', {})
    if kind in estimates: return float(estimates[kind])
    history=HERE/'resources/historical_rss_preflight.json'
    if history.exists():
        nested=request.get('pair',{})
        pair=request.get('pair_id') or (str(request.get('case_id',nested.get('case_id','')))+'__'+str(request.get('pdk',nested.get('pdk',''))))
        vals=[r['peak_rss_gib'] for r in read(history)['rows'] if r['pair']==pair and phase_class(r['phase'])==kind]
        if vals:return max(1.0,1.15*max(vals)+.5)
    return float(policy['phase_peak_gib'][kind])


def _control(contract):
    control=Path(contract.get('resource_control_directory', HERE/'resources/leases')).resolve()
    if not control.is_relative_to(HERE/'resources'): raise ValueError('Dataset2 resource leases must be private')
    control.mkdir(parents=True,exist_ok=True)
    (control/'slots').mkdir(exist_ok=True)
    return control


def _contract_sha(contract, request):
    # Caller pins bytes, not Python repr; no mutation of the frozen contract.
    path=contract.get('execution_contract_path') or request.get('execution_contract_path')
    expected=request.get('execution_contract_sha256')
    if path:
        actual=sha(path)
        if expected and actual!=expected:raise ValueError('Execution contract SHA mismatch')
        return actual
    if expected:return expected
    raise ValueError('Pinned execution_contract_sha256 required')


@contextmanager
def admit(*,request,phase,resource,execution_contract):
    """Native+observer unified lease; caller must pass returned FDs to child.

Metadata remains atomically written after a crash. A slot is considered live
only while its flock is held by parent/descendants, so stale JSON cannot free a
live child or permanently block the queue. Never signal/kill other processes.
"""
    kind=phase_class(phase)
    control=_control(execution_contract)
    pol={**DEFAULT_POLICY, **execution_contract.get('resource_policy',{})}
    cap=int(pol['max_workers'])
    if not 1<=cap<=24:raise ValueError('Bad unified phase ceiling')
    out=Path(request['output_directory']).resolve()
    if not out.is_relative_to(HERE):raise ValueError('Dataset2-only attempt required')
    contract_sha=_contract_sha(execution_contract,request)
    peak=peak_estimate(request,phase,pol)
    start=time.monotonic();holder=None;event=None
    while holder is None:
        with (control/'mutex.lock').open('a+') as mutex:
            fcntl.flock(mutex,fcntl.LOCK_EX)
            previous=None
            try:previous=read(control/'last_snapshot.json')
            except (OSError,ValueError):pass
            snap=snapshot(previous)
            # Frequent admissions do not destroy the >=0.5s swap delta baseline.
            if not previous or snap['monotonic_s']-previous.get('monotonic_s',0)>=2:
                atomic_json(control/'last_snapshot.json',snap)
            held=[];free=[]
            try:
                for idx in range(cap):
                    h=(control/'slots'/f'{idx:02d}.lock').open('a+')
                    try:
                        fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB)
                        free.append((idx,h))
                    except BlockingIOError:
                        h.close()
                        try:held.append(read(control/'slots'/f'{idx:02d}.json'))
                        except (OSError,ValueError):held.append({'estimated_peak_gib':4.0,'output_directory':'__unknown__'})
                proc=snap['processes']
                covered=[x['output_directory'].rstrip('/')+'/' for x in held]
                matches=lambda p,prefix:any(prefix in arg for arg in p['argv'])
                native=[p for p in proc if p['phase_class'] in ('compile','primitive','placement','routing','observer')]
                external=[p for p in native if not any(matches(p,prefix) for prefix in covered)]
                growth=sum(max(0,x['estimated_peak_gib']-sum(p['rss_bytes'] for p in proc if matches(p,prefix))/GIB) for x,prefix in zip(held,covered))
                growth+=sum(max(0,pol['phase_peak_gib'][p['phase_class']]-p['rss_bytes']/GIB) for p in external)
                status=decide(snap,peak,len(held)+len(external),cap,reserved_growth_gib=growth,policy=pol)
                if status['admit'] and free:
                    idx,holder=free.pop(0)
                    event={'utc':utc(),'phase':phase,'phase_class':kind,'slot':idx,
                           'owner':process(os.getpid()),'output_directory':str(out),
                           'estimated_peak_gib':peak,'execution_contract_sha256':contract_sha,
                           'waiting_seconds':time.monotonic()-start,'resource':resource,
                           'host_pid_namespace_inode':snap['pid_namespace_inode'],**status}
                    atomic_json(control/'slots'/f'{idx:02d}.json',event)
                else:
                    atomic_json(out/'resource_wait.json',{'utc':utc(),'phase':phase,**status})
            finally:
                for _,h in free:h.close()
        if holder is None:time.sleep(2)
    try:
        yield (holder.fileno(),),event
    finally:
        holder.close()
        atomic_json(out/'resource_last_release.json',{'utc':utc(),'phase':phase,'slot':event['slot'],
                    'execution_contract_sha256':contract_sha,'lease_duration_s':time.monotonic()-start})


@contextmanager
def admit_observer(*,request,execution_contract):
    with admit(request=request,phase='typed_observer',resource={'observation_only':True},
               execution_contract=execution_contract) as value:
        yield value


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--interval',type=float,default=2.0)
    args=parser.parse_args()
    if not 0<=args.interval<=5:raise ValueError('Preflight interval must be 0–5s; not a benchmark')
    first=snapshot()
    if args.interval:
        time.sleep(args.interval)
        snap=snapshot(first)
    else:snap=first
    if args.output:
        out=args.output.resolve()
        if not out.is_relative_to(HERE/'resources') or out.exists():raise ValueError('Fresh private resource output required')
        with out.open('x') as f:json.dump(snap,f,indent=2)
    print(json.dumps({k:v for k,v in snap.items() if k not in ('processes','temperature_sensors','thermal_throttle_counters','cpu_counters')},indent=2))


if __name__=='__main__':main()
